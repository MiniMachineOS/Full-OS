/* host.c - runs the real GUI code on the build machine and dumps screenshots (raw BGRA) */
#ifdef HOST32
/* freestanding 32-bit build: no libc, raw Linux syscalls. Uses exactly the kernel's compiler flags. */
static long sys3(long n, long a, long b, long c) { long r; __asm__ volatile("int $0x80" : "=a"(r) : "0"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r; }
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static void say(const char *s) { sys3(4, 1, (long)s, slen(s)); }
static void exit_(int c) { sys3(1, c, 0, 0); for (;;) { } }
static void write_file(const char *p, const void *b, unsigned n) {
    long fd = sys3(5, (long)p, 0x241, 0644);
    const char *c = b;
    while (n) { long w = sys3(4, fd, (long)c, n > 65536 ? 65536 : n); if (w <= 0) break; c += w; n -= (unsigned)w; }
    sys3(6, fd, 0, 0);
}
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#endif
#include "../src/gui.h"
#include "../src/hw.h"
#include "../src/app.h"
#include "../src/klib.h"
#include "../src/net.h"
#include "../src/account.h"

static u32 fake_ms = 1000;
static int W = 1024, H = 768;
static u32 *scene, *screen;
static int mx, my;

u32 hw_ms(void) { return fake_ms; }
void hw_time(HwTime *t) { HwTime x = { 2026, 11, 4, 14, 32, 7, 3 }; *t = x; }
#ifdef HOST32
void hw_poweroff(void) { say("[poweroff]\n"); exit_(0); }
void hw_reboot(void) { say("[reboot]\n"); exit_(0); }
void hw_cpu_brand(char *o, int m) { k_strcpy(o, "QEMU Virtual CPU version 2.5+", m); }
#else
void hw_poweroff(void) { printf("[poweroff]\n"); exit(0); }
void hw_reboot(void) { printf("[reboot]\n"); exit(0); }
void hw_cpu_brand(char *o, int m) { snprintf(o, m, "QEMU Virtual CPU version 2.5+"); }
#endif
u32 hw_mem_kb(void) { return 131072; }

#ifdef HOST32
int hw_disk_init(u32 *n) { (void)n; return 0; }
int hw_disk_read(u32 l, int n, void *b) { (void)l; (void)n; (void)b; return 0; }
int hw_disk_write(u32 l, int n, const void *b) { (void)l; (void)n; (void)b; return 0; }
int hw_nic_init(u8 mac[6]) { (void)mac; return 0; }
int hw_nic_send(const u8 *f, int len) { (void)f; (void)len; return 0; }
int hw_nic_recv(u8 *b, int m) { (void)b; (void)m; return 0; }
const char *hw_nic_name(void) { return "none"; }
#else
static int disk_on, disk_fd = -1;
int hw_disk_init(u32 *n) {
    if (!disk_on) return 0;
    disk_fd = open("build/hostdisk.bin", O_RDWR | O_CREAT, 0644);
    if (disk_fd < 0) return 0;
    if (lseek(disk_fd, 0, SEEK_END) < 2097152) { if (ftruncate(disk_fd, 2097152)) return 0; }
    *n = 4096; return 1;
}
int hw_disk_read(u32 lba, int n, void *b) { return pread(disk_fd, b, (size_t)n * 512, (off_t)lba * 512) == (ssize_t)n * 512; }
int hw_disk_write(u32 lba, int n, const void *b) { return pwrite(disk_fd, b, (size_t)n * 512, (off_t)lba * 512) == (ssize_t)n * 512; }
static int nic_on, to_py = -1, from_py = -1;
static u8 inbuf[16384]; static int inlen;
int hw_nic_init(u8 mac[6]) {
    if (!nic_on) return 0;
    int a[2], b[2];
    if (pipe(a) || pipe(b)) return 0;
    if (fork() == 0) {
        dup2(a[0], 0); dup2(b[1], 1); close(a[1]); close(b[0]);
        execlp("python3", "python3", "tools/vnet.py", (char *)NULL); _exit(1);
    }
    close(a[0]); close(b[1]); to_py = a[1]; from_py = b[0];
    fcntl(from_py, F_SETFL, O_NONBLOCK);
    static const u8 m[6] = { 0x52, 0x54, 0x00, 0x12, 0x34, 0x56 }; memcpy(mac, m, 6);
    return 1;
}
int hw_nic_send(const u8 *f, int len) {
    unsigned short l = (unsigned short)len;
    if (write(to_py, &l, 2) != 2 || write(to_py, f, (size_t)len) != len) return 0;
    return 1;
}
int hw_nic_recv(u8 *buf, int max) {
    ssize_t n = read(from_py, inbuf + inlen, sizeof inbuf - (size_t)inlen);
    if (n > 0) inlen += (int)n;
    if (inlen >= 2) {
        int l = inbuf[0] | (inbuf[1] << 8);
        if (inlen >= 2 + l) { if (l > max) l = max; memcpy(buf, inbuf + 2, (size_t)l); int tot = 2 + (inbuf[0] | (inbuf[1] << 8)); memmove(inbuf, inbuf + tot, (size_t)(inlen - tot)); inlen -= tot; return l; }
    }
    return 0;
}
const char *hw_nic_name(void) { return "Intel e1000"; }
#endif

static void shot(const char *name) {
    gui_render();
#ifdef HOST32
    char p[128]; k_snprintf(p, sizeof p, "build/shots32/%s.raw", name);
    write_file(p, screen, (unsigned)W * H * 4);
    say("shot "); say(name); say("\n");
#else
    char p[128]; snprintf(p, sizeof p, "build/shots/%s.raw", name);
    FILE *f = fopen(p, "wb"); fwrite(screen, 4, (size_t)W * H, f); fclose(f);
    printf("shot %s\n", name);
#endif
}
static void step(int ms) { fake_ms += ms; net_poll(); gui_tick(fake_ms); gui_render(); }
static void move(int x, int y) { mx = x; my = y; gui_mouse(x, y, 0, 0); gui_render(); }
static void click(int x, int y) {
    gui_mouse(x, y, 0, 0); gui_mouse(x, y, 1, 0); gui_render(); step(60); gui_mouse(x, y, 0, 0); gui_render(); step(500);
    mx = x; my = y;
}
static void dbl(int x, int y) {
    gui_mouse(x, y, 0, 0); gui_mouse(x, y, 1, 0); step(40); gui_mouse(x, y, 0, 0); step(60);
    gui_mouse(x, y, 1, 0); gui_render(); step(40); gui_mouse(x, y, 0, 0); gui_render(); step(500);
    mx = x; my = y;
}
static void rclick(int x, int y) { gui_mouse(x, y, 0, 0); gui_mouse(x, y, 2, 0); gui_render(); gui_mouse(x, y, 0, 0); gui_render(); }
__attribute__((unused)) static void drag(int x0, int y0, int x1, int y1) {
    gui_mouse(x0, y0, 0, 0); gui_mouse(x0, y0, 1, 0);
    for (int i = 1; i <= 10; i++) { gui_mouse(x0 + (x1 - x0) * i / 10, y0 + (y1 - y0) * i / 10, 1, 0); gui_render(); }
    gui_mouse(x1, y1, 0, 0); gui_render(); mx = x1; my = y1;
}
static void type(const char *s) { for (; *s; s++) { gui_key(*s == '\n' ? KEY_ENTER : *s == '\t' ? KEY_TAB : (u8)*s, 0); gui_render(); } }

#ifdef HOST32
#define say_(x) say(x)
#else
#define say_(x) printf("%s", x)
#endif
#ifndef HOST32
static void disk_on_set(int v) { disk_on = v; }
static int wait_idle(int max_iters) {
    for (int i = 0; i < max_iters; i++) { step(10); usleep(1500); if (!browser_busy() && i > 3) return 1; }
    return 0;
}
static void go(const char *url) {
    gui_key('l', MOD_CTRL); type(url); type("\n");
    int ok = wait_idle(4000);
    printf("  -> %s : %s [%s]\n", url, browser_status(), ok ? "finished" : "TIMEOUT");
}
static int scenario3(void) {
    nic_on = 1;
    net_init();
    for (int i = 0; i < 600 && net_info()->status != NET_UP; i++) { step(10); usleep(1500); }
    printf("net status=%d\n", net_info()->status);
    shot("30_desktop_net");
    dbl(60, 140);                                   /* Browser icon (2nd) */
    shot("31_browser_home");
    go("web.test/");           shot("32_test_page");
    go("web.test/big");        shot("33_big_page");
    gui_key(KEY_END, 0); gui_render(); shot("34_big_end");
    go("web.test/old");        shot("35_redirect");
    go("web.test/text");       shot("36_text");
    go("web.test/chunked");    shot("37_chunked");
    go("alias.test/img.png");  shot("38_image_type");
    go("web.test/missing");    shot("39_404");
    go("nosuch.test/");        shot("40_dns_fail");
    go("refuse.test:81/");     shot("41_refused");
    go("https://secure.test/"); shot("42_https");
    go("about:home");
    gui_key(KEY_LEFT, MOD_ALT); gui_render(); wait_idle(2000);
    printf("  after back: %s\n", browser_status());
    /* click the first link on the test page */
    go("web.test/");
    click(160, 260); wait_idle(4000);
    printf("  after link click: %s\n", browser_status());
    shot("43_after_click");
    /* terminal: net + ping + browse */
    gui_key('t', MOD_CTRL | MOD_ALT); gui_render();
    type("net\nping web.test\n");
    for (int i = 0; i < 700; i++) { step(10); usleep(1000); }
    type("ping nosuch.test\n");
    for (int i = 0; i < 300; i++) { step(10); usleep(1000); }
    shot("44_terminal_net");
    dbl(60, 640); shot("45_settings_net");
    printf("done3\n");
    return 0;
}
static void winpos(int app, int *cx, int *cy, int *cw, int *ch) {
    int x, y, w, h;
    if (!gui_test_window(app, &x, &y, &w, &h)) { *cx = *cy = *cw = *ch = 0; return; }
    *cx = x + 1; *cy = y + 34; *cw = w - 2; *ch = h - 35;
}
static void clickc(int app, int rx, int ry) { int cx, cy, cw, ch; winpos(app, &cx, &cy, &cw, &ch); click(cx + rx, cy + ry); }
static void run_ms(int ms) { for (int i = 0; i < ms / 10; i++) step(10); }

static int scenario4(void) {                       /* first boot: account setup, store, games, persistence (phase A) */
    shot("50_setup");
    type("\n\n\n"); shot("51_setup_empty_err");
    type("alex\tsecret\twrong\n"); shot("52_mismatch");
    type("secret\n"); step(10);
    printf("account exists=%d name=%s disk=%d\n", acct_exists(), acct_name(), persist_disk());
    shot("53_desktop_first");
    dbl(60, 240);                                   /* App Store */
    shot("54_store");
    int cx, cy, cw, ch; winpos(APP_STORE, &cx, &cy, &cw, &ch);
    for (int r = 0; r < 5; r++) clickc(APP_STORE, cw - 20 - 96 + 48, 64 + r * 88 + 28 + 16);
    gui_mouse(cx + 400, cy + 300, 0, 3); gui_render();
    clickc(APP_STORE, cw - 20 - 96 + 48, 64 + 5 * 88 - 99 + 28 + 16);
    shot("55_store_installed");
    printf("installed: snake=%d mines=%d 2048=%d ttt=%d paint=%d clock=%d\n", app_installed(APP_SNAKE), app_installed(APP_MINES), app_installed(APP_2048), app_installed(APP_TTT), app_installed(APP_PAINT), app_installed(APP_CLOCK));
    gui_close_app(APP_STORE); gui_render();

    dbl(116, 140);                                  /* Snake */
    gui_key(KEY_RIGHT, 0); run_ms(500); gui_key(KEY_DOWN, 0); run_ms(400); gui_key(KEY_LEFT, 0); run_ms(300);
    shot("56_snake"); gui_close_app(APP_SNAKE);
    gui_close_app(APP_SNAKE); app_launch(APP_MINES, NULL); gui_render();
    winpos(APP_MINES, &cx, &cy, &cw, &ch);
    clickc(APP_MINES, (cw - 448) / 2 + 7 * 32 + 16, 60 + 5 * 32 + 16);
    rclick(cx + (cw - 448) / 2 + 1 * 32 + 16, cy + 60 + 1 * 32 + 16);
    shot("57_mines"); gui_close_app(APP_MINES);
    app_launch(APP_2048, NULL); gui_render();
    { static const int mv[] = { KEY_LEFT, KEY_UP, KEY_LEFT, KEY_DOWN, KEY_RIGHT, KEY_UP, KEY_LEFT, KEY_LEFT, KEY_UP, KEY_RIGHT };
      for (unsigned i = 0; i < sizeof mv / sizeof mv[0]; i++) { gui_key(mv[i], 0); gui_render(); } }
    shot("58_2048"); gui_close_app(APP_2048);
    app_launch(APP_TTT, NULL); gui_render();
    winpos(APP_TTT, &cx, &cy, &cw, &ch);
    { int bx = (cw - 300) / 2; clickc(APP_TTT, bx + 150, 110 + 150); clickc(APP_TTT, bx + 50, 110 + 250); clickc(APP_TTT, bx + 250, 110 + 50); }
    shot("59_ttt"); gui_close_app(APP_TTT);
    app_launch(APP_PAINT, NULL); gui_render();
    winpos(APP_PAINT, &cx, &cy, &cw, &ch);
    clickc(APP_PAINT, 8 + 16, 8 + 4 * 36 + 16);       /* red (index 8 = teal? pick a swatch) */
    drag(cx + 120, cy + 60, cx + 300, cy + 200);
    clickc(APP_PAINT, 8 + 36 + 16, 8 + 4 * 36 + 16); clickc(APP_PAINT, 8 + 36 + 16, 304 + 16);
    drag(cx + 200, cy + 300, cx + 520, cy + 120);
    shot("5a_paint"); gui_close_app(APP_PAINT);
    app_launch(APP_CLOCK, NULL); gui_render();
    shot("5b_clock");
    clickc(APP_CLOCK, 210 + 70, 28); clickc(APP_CLOCK, 210 - 70, 250); run_ms(2340);
    shot("5c_stopwatch"); gui_close_app(APP_CLOCK);

    dbl(16 + 44, 440);                              /* Editor: write + save a file */
    type("Saved from phase A"); gui_key('s', MOD_CTRL); gui_render();
    dbl(60, 640);                                   /* Settings: light theme + blue accent */
    clickc(APP_SETTINGS, 196, 100); clickc(APP_SETTINGS, 100, 192);
    run_ms(4000);
    printf("flushed: vfs_dirty=%d dark=%d accent=%d\n", vfs_dirty, cfg_dark, cfg_accent);
    shot("5d_desktop_final");
    return 0;
}

static int scenario5(void) {                       /* "reboot": same disk, new process (phase B) */
    shot("60_login");
    type("nope1\n"); shot("61_login_wrong");
    run_ms(5000);
    type("secret\n"); step(10);
    shot("62_desktop_back");
    printf("account=%s dark=%d accent=%d installed: snake=%d clock=%d\n", acct_name(), cfg_dark, cfg_accent, app_installed(APP_SNAKE), app_installed(APP_CLOCK));
    int n = vfs_resolve(0, "/home/alex/Untitled.txt"); int len = 0; const char *d = n > 0 ? vfs_data(n, &len) : "";
    printf("file persisted: node=%d len=%d content='%s'\n", n, len, d);
    dbl(60, 40); shot("63_files");
    gui_key('l', MOD_CTRL | MOD_ALT); gui_render(); shot("64_locked");
    type("secret\n"); step(10);
    printf("after relock: windows kept, files window pos ok=%d\n", ({ int x, y, w, h; gui_test_window(APP_FILES, &x, &y, &w, &h); }));
    click(55, 750); shot("65_start_menu");
    gui_mouse(200, 400, 0, 3); gui_render(); shot("66_start_scrolled");
    return 0;
}

#endif

static int scenario2(void) {
    shot("20_start");
    dbl(60, 440);                                  /* Editor */
    type("Hello from MiniMachineOS!\nThis is the text editor.\n\nLine three with a fairly long sentence that should wrap around nicely at the edge of the window.\n");
    gui_key('s', MOD_CTRL); gui_render();
    shot("21_editor");
    dbl(60, 540);                                  /* Calculator */
    type("12*3.5\n");
    shot("22_calc_result");
    type("/0\n");
    shot("22b_calc_div0");
    dbl(60, 640);                                  /* Settings */
    click(299, 238);                               /* Light theme */
    click(235, 330);                               /* Blue accent */
    click(321, 430);                               /* Dusk wallpaper */
    shot("23_settings_light");
    dbl(200, 120);                                 /* maximize via title double-click */
    shot("24_maximized");
    dbl(200, 15);                                  /* restore */
    dbl(116, 40);                                  /* System */
    shot("25_about");
    gui_key(KEY_TAB, MOD_ALT); gui_render();
    gui_key('t', MOD_CTRL | MOD_ALT); gui_render();
    type("ls\ntouch hello.txt\nls\nfoo\n");
    shot("26_term_more");
    say_("done2\n");
    return 0;
}

#ifdef HOST32
static u32 scene_buf[1024 * 768], screen_buf[1024 * 768];
static void disk_on_set(int v) { (void)v; }
static int run(int sc);
void _start(void) { exit_(run(SCEN)); }
static int run(int sc) {
    scene = scene_buf; screen = screen_buf;
#else
static int run(int sc);
int main(int argc, char **argv) {
    int sc = 1;
    if (argc > 2) { W = atoi(argv[1]); H = atoi(argv[2]); }
    if (argc > 3) sc = atoi(argv[3]);
    scene = calloc((size_t)W * H, 4); screen = calloc((size_t)W * H, 4);
    return run(sc);
}
static int run(int sc) {
#endif
    if (sc == 4 || sc == 5) disk_on_set(1);
    gui_init(scene, screen, W, H, W);
    gui_tick(fake_ms);
    if (sc <= 3) gui_autologin("user", "password");
    if (sc == 2) return scenario2();
#ifndef HOST32
    if (sc == 3) return scenario3();
    if (sc == 4) return scenario4();
    if (sc == 5) return scenario5();
#endif
    shot("01_desktop");
    move(500, 400); shot("01b_cursor");

    dbl(60, 40);                       /* Files icon */
    shot("02_files");
    click(700, 300);                   /* select something */
    dbl(66 + 0 + 168 + 8 + 40, 130);   /* open first item (Desktop folder?) */
    shot("03_files_nav");

    dbl(60, 340);                      /* Terminal icon */
    type("help\nneofetch\nls\ncat welcome.txt\ncd Documents\nls\n");
    shot("04_terminal");

    click(55, 750);                    /* start menu */
    shot("05_startmenu");
    type("calc");
    shot("05b_startsearch");
    type("\n");
    click(30, 400);
    click(512, 700);                   /* calc buttons are in client; just poke */
    shot("06_calc");

    click(940, 750);                   /* calendar */
    shot("07_calendar");
    click(300, 120);                   /* close popup on desktop */

    rclick(800, 300);
    move(820, 340);
    shot("08_context");
    click(900, 600);

    dbl(60, 640);                      /* Settings */
    shot("09_settings");
    say_("done\n");
    return 0;
}
