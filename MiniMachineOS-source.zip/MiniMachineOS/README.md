# MiniMachineOS - a bare-metal x86 desktop

Boots from a BIOS boot sector (disk image or CD), switches to a 32-bit VESA graphics mode and runs a desktop
environment written from scratch: login screen, taskbar + start menu, windows, desktop icons, a web browser, an app store
with games and apps, and a handful of built-in tools. No libc, no external libraries.

## Run it
    qemu-system-i386 -drive format=raw,file=MiniMachineOS.img -m 128 -vga std -nic user,model=e1000
    qemu-system-i386 -cdrom MiniMachineOS.iso               -m 128 -vga std -nic user,model=e1000
Click inside the QEMU window to capture the mouse (Ctrl+Alt+G releases it).
* `MiniMachineOS.img` - raw disk image: VMs, or `dd if=MiniMachineOS.img of=/dev/sdX` for a USB stick (erases it).
* `MiniMachineOS.iso` - El Torito bootable CD for VirtualBox/VMware/QEMU or a burned disc.
Needs BIOS (or UEFI with CSM/legacy mode) and a PS/2 or USB-legacy-emulated keyboard and mouse.

## Accounts, saving and the App Store
* **First boot:** you create a username and password. Later boots show a login screen (Menu -> Lock, or Ctrl+Alt+L, locks the session).
  Passwords are stored as a salted, iterated SHA-256 hash, never in plain text. This is a login gate, not disk encryption.
* **Saving:** when booted from `MiniMachineOS.img` on an IDE/ATA disk (the QEMU default), the account, theme, installed apps and
  your files are written to a reserved area of the image (sectors 2048-4095). From the ISO or a USB stick there is no writable
  disk the OS can see, so the setup screen warns that nothing will be remembered. NVMe/SATA-AHCI/USB disks are not supported yet.
* **Reset the account:** `dd if=/dev/zero of=MiniMachineOS.img bs=512 seek=2048 count=1 conv=notrunc`
* **App Store:** the apps and games are bundled in the kernel; the store adds/removes them from your Start menu and desktop.
  Games: Snake, Minesweeper, 2048, Tic-Tac-Toe. Apps: Paint, Clock (with stopwatch).

## Networking and the browser
* Driver: **Intel e1000** (QEMU default; VirtualBox: adapter type "Intel PRO/1000 MT Desktop"; VMware default).
* Stack: ARP, IPv4, ICMP, UDP, DHCP, DNS, TCP (written from scratch, polled, no interrupts).
* **No Wi-Fi.** Wi-Fi needs chipset-specific drivers, firmware blobs and WPA2; QEMU does not emulate Wi-Fi hardware.
  In a VM the host's Wi-Fi shows up to the guest as a normal wired e1000 card, so the browser works there.
* The browser is **HTTP only** (no TLS), no JavaScript/CSS/images. Plain-HTTP sites to try: info.cern.ch, example.com,
  neverssl.com. In QEMU the host machine is 10.0.2.2.
* Terminal: `net`, `ping <host>`, `browse <url>`.  Settings has a Network section with a "Renew address" button.

## Build
Needs gcc with `-m32`, binutils, make, python3 (Pillow only to regenerate fonts).

    make            # -> build/MiniMachineOS.img, build/MiniMachineOS.iso (+ build/boot.bin, the 512-byte boot sector)
    make run        # qemu, disk image          make run-iso   # qemu, CD
    make host       # run the real GUI code natively with scripted input -> build/shots/*.raw (+ ASAN/UBSan)
    make host32     # the exact 32-bit kernel build, checked pixel-identical to the native build
    ./build/host 1024 768 3    # network + browser scenario against tools/vnet.py (a virtual DHCP/DNS/TCP/HTTP network)
    rm -f build/hostdisk.bin; ./build/host 1024 768 4; ./build/host 1024 768 5   # first boot + 'reboot' persistence test

## Using it
* Double-click desktop icons, or open **Menu** (or press Super); type to search apps.
* Drag title bars, resize from the right/bottom edge, double-click a title bar to maximise.
* Right-click the desktop for a menu; click the clock for a calendar; the sliver at the far right shows the desktop.
* Ctrl+Alt+T terminal, Alt+Tab switch window, Alt+F4 close. Browser: Ctrl+L address bar, F5, Alt+Left/Right.

## Layout
    boot/stage1.S      512-byte boot sector (disk): loads stage 2 + kernel with BIOS LBA reads
    boot/stage1_iso.S  El Torito entry (CD): the BIOS preloads everything, we just jump
    boot/stage2.S      A20, RAM size, VESA 32-bpp mode (1024x768 -> 1280x720 -> 800x600 -> 640x480), protected mode
    kernel/            entry stub, linker script, hardware layer (PS/2, PIT, RTC, power), e1000 driver
    src/net.c          network stack            src/app_browser.c  HTTP loader + HTML layout + UI
    src/gfx.c          software renderer        src/gui.c          window manager, taskbar, start menu
    src/app_*.c        applications + games     src/vfs.c          in-memory filesystem (snapshotted to disk)
    src/account.c      account, settings, persistence   src/sha256.c  password hashing   kernel/ata.c  disk driver
    tools/             font generator, image/ISO builders, ISO checker, virtual network for tests
    host/host.c        test harness (screenshots + network tests without an emulator)

## Known limits
* Files live in RAM and are snapshotted to the boot disk (see above). No USB, sound or Wi-Fi drivers.
* Input is polled (no interrupts yet), so an emulator uses a full CPU core.
* Clock shows the BIOS/RTC time as-is (QEMU: UTC).
* Fonts: Instrument Sans and JetBrains Mono (SIL OFL, see fonts/).
