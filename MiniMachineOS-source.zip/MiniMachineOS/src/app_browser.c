/* app_browser.c - a small HTTP web browser: loader state machine + HTML layout + UI.
   HTTP only (no TLS), no CSS/JavaScript/images. Single instance (large static buffers). */
#include "app.h"
#include "klib.h"
#include "net.h"
#include "hw.h"

#define RESP_MAX (160 * 1024)
#define MAX_ITEMS 16000
#define POOL_MAX (256 * 1024)
#define MAX_LINKS 256
#define TOOL_H 46
#define STAT_H 26
#define MARGIN 26
#define SBW 12

enum { B_IDLE, B_DNS, B_CONNECT, B_RECV, B_DONE, B_ERROR };
enum { IF_UNDER = 1, IF_RULE = 2 };

static char resp[RESP_MAX + 2];
static int resp_len, hdr_len;
static char *body; static int body_len;
static char reqbuf[640]; static int req_len, req_sent;

typedef struct { int x, y; short w; u8 font, flags; u32 color; short link; int off; } Item;
static Item items[MAX_ITEMS]; static int n_items;
static char pool[POOL_MAX]; static int pool_len;
static char links[MAX_LINKS][160]; static int n_links;
static int page_h, page_plain, page_overflow;
static char page_title[64];
static const Font *fonts[6] = { &font_ui, &font_uib, &font_big, &font_h2, &font_mono, &font_sm };
enum { F_UI, F_UIB, F_BIG, F_H2, F_MONO, F_SM };

static struct { int code, clen, chunked, gzip; char loc[200], ctype[64]; } H;

#define PAGE_BG 0xFFFFFF
#define PAGE_FG 0x202124
#define PAGE_LINK 0x1558D6
#define PAGE_DIM 0x6B7075

/* ====================================================================== */
/*  URLs                                                                   */
/* ====================================================================== */
static char lc(char c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
static int isalpha_(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }
static int isalnum_(char c) { return isalpha_(c) || (c >= '0' && c <= '9'); }
static int starts_ci(const char *s, const char *p) { while (*p) { if (lc(*s) != lc(*p)) return 0; s++; p++; } return 1; }

typedef struct { int https; char host[64]; int port; char path[200]; } Url;

static int url_parse(const char *u, Url *o) {
    o->https = 0; o->port = 80;
    if (starts_ci(u, "http://")) u += 7;
    else if (starts_ci(u, "https://")) { u += 8; o->https = 1; o->port = 443; }
    else return 0;
    int i = 0;
    while (*u && *u != '/' && *u != ':' && *u != '?' && *u != '#') { if (i < 63) o->host[i++] = lc(*u); u++; }
    o->host[i] = 0;
    if (*u == ':') { u++; int p = 0; while (*u >= '0' && *u <= '9') { p = p * 10 + (*u - '0'); u++; } if (p > 0 && p < 65536) o->port = p; }
    int j = 0;
    if (*u == '?') o->path[j++] = '/';
    while (*u && *u != '#' && j < 199) o->path[j++] = *u++;
    if (j == 0) o->path[j++] = '/';
    o->path[j] = 0;
    return i > 0;
}

static void norm_path(char *p) {              /* collapse ./ and ../ segments in the path part (before any '?') */
    char *q = p; while (*q && *q != '?') q++;
    char tail[200]; k_strcpy(tail, q, sizeof tail); *q = 0;
    char out[200]; int n = 0; out[0] = 0;
    const char *s = p;
    while (*s) {
        while (*s == '/') s++;
        if (!*s) break;
        char seg[100]; int l = 0;
        while (*s && *s != '/') { if (l < 99) seg[l++] = *s; s++; }
        seg[l] = 0;
        if (!k_strcmp(seg, ".")) continue;
        if (!k_strcmp(seg, "..")) { while (n > 0 && out[n - 1] != '/') n--; if (n > 0) n--; out[n] = 0; continue; }
        if (n + l + 2 < 199) { out[n++] = '/'; for (int i = 0; i < l; i++) out[n++] = seg[i]; out[n] = 0; }
    }
    int trail = (p[0] && p[k_strlen(p) - 1] == '/');
    if (n == 0) { out[n++] = '/'; out[n] = 0; } else if (trail && n < 198) { out[n++] = '/'; out[n] = 0; }
    k_strcpy(p, out, 200); k_strcat(p, tail, 200);
}

/* resolve `href` against `base` into an absolute URL */
static void resolve(const char *base, const char *href, char *out, int max) {
    while (*href == ' ') href++;
    if (starts_ci(href, "http://") || starts_ci(href, "https://")) { k_strcpy(out, href, max); return; }
    Url b; int ok = url_parse(base, &b);
    if (href[0] == '/' && href[1] == '/') { k_snprintf(out, max, "http:%s", href); return; }
    if (!ok) { k_strcpy(out, href, max); return; }
    char auth[100];
    if (b.port == (b.https ? 443 : 80)) k_snprintf(auth, sizeof auth, "%s://%s", b.https ? "https" : "http", b.host);
    else k_snprintf(auth, sizeof auth, "%s://%s:%d", b.https ? "https" : "http", b.host, b.port);
    char path[200];
    if (href[0] == '#' || href[0] == 0) k_strcpy(path, b.path, sizeof path);
    else if (href[0] == '/') k_strcpy(path, href, sizeof path);
    else if (href[0] == '?') { k_strcpy(path, b.path, sizeof path); char *q = path; while (*q && *q != '?') q++; *q = 0; k_strcat(path, href, sizeof path); }
    else {
        k_strcpy(path, b.path, sizeof path);
        char *q = path; while (*q && *q != '?') q++; *q = 0;
        int l = k_strlen(path); while (l > 0 && path[l - 1] != '/') l--; path[l] = 0;
        k_strcat(path, href, sizeof path);
    }
    char *h = path; while (*h && *h != '#') h++; *h = 0;
    norm_path(path);
    k_snprintf(out, max, "%s%s", auth, path);
}

/* ====================================================================== */
/*  HTML layout                                                            */
/* ====================================================================== */
static struct {
    int x, y, left, right, lineh, line_has, need_space, gap;
    int bold, mono, pre, link, head, in_title, overflow;
    int depth, ltype[8], lcount[8];
    u32 color;
} L;

static const Font *curf(void) {
    int f = F_UI;
    if (L.head == 1) f = F_BIG; else if (L.head == 2) f = F_H2; else if (L.head >= 3) f = F_UIB;
    else if (L.pre || L.mono) f = F_MONO; else if (L.bold) f = F_UIB;
    return fonts[f];
}
static int curfi(void) {
    const Font *f = curf();
    for (int i = 0; i < 6; i++) if (fonts[i] == f) return i;
    return 0;
}
static int adv(const Font *f, char c) { unsigned u = (u8)c; if (u < 32 || u > 127) u = '?'; return f->g[u - 32].adv; }

static Item *new_item(void) { if (n_items >= MAX_ITEMS) { L.overflow = 1; return NULL; } return &items[n_items++]; }
static void end_line(void) { if (L.line_has) L.y += L.lineh; L.x = L.left; L.line_has = 0; L.lineh = 0; L.need_space = 0; }
static void block(int gap) { end_line(); if (gap > L.gap) L.gap = gap; }
static void apply_gap(void) { if (L.gap) { if (L.y > 0) L.y += L.gap; L.gap = 0; } }

static void emit(const char *s, int n, int w, int sp) {
    if (pool_len + n + 1 >= POOL_MAX) { L.overflow = 1; return; }
    Item *it = new_item(); if (!it) return;
    apply_gap();
    const Font *f = curf();
    it->x = L.x + sp; it->y = L.y; it->w = (short)w; it->font = (u8)curfi();
    it->color = L.link >= 0 ? PAGE_LINK : L.color; it->link = (short)L.link; it->flags = L.link >= 0 ? IF_UNDER : 0;
    it->off = pool_len; k_memcpy(pool + pool_len, s, (unsigned)n); pool_len += n; pool[pool_len++] = 0;
    L.x += sp + w; L.line_has = 1; L.need_space = 0;
    int lh = f->height + (f == &font_mono ? 0 : 3);
    if (lh > L.lineh) L.lineh = lh;
}

static void place_word(const char *s, int n) {
    const Font *f = curf();
    int spw = f->g[0].adv;
    int W = 0; for (int i = 0; i < n; i++) W += adv(f, s[i]);
    if (L.line_has && L.x + (L.need_space ? spw : 0) + W > L.right) end_line();
    while (n > 0 && !L.overflow) {
        int sp = (L.line_has && L.need_space) ? spw : 0;
        int room = L.right - (L.x + sp);
        int k = n, w = 0;
        for (int i = 0; i < n; i++) w += adv(f, s[i]);
        if (w > room) {
            k = 0; w = 0;
            while (k < n) {
                int a = adv(f, s[k]);
                if (w + a > room && (k > 0 || L.line_has)) break;
                w += a; k++;
            }
            if (k == 0) { end_line(); continue; }
        }
        emit(s, k, w, sp);
        s += k; n -= k;
        if (n > 0) end_line();
    }
}

static char wb[128]; static int wl;
static void flush_word(void) { if (wl) { place_word(wb, wl); wl = 0; } }

static const struct { const char *n, *r; } ents[] = {
    { "amp", "&" }, { "lt", "<" }, { "gt", ">" }, { "quot", "\"" }, { "apos", "'" }, { "nbsp", " " }, { "mdash", "-" },
    { "ndash", "-" }, { "hellip", "..." }, { "copy", "(c)" }, { "reg", "(R)" }, { "trade", "(TM)" }, { "rsquo", "'" },
    { "lsquo", "'" }, { "rdquo", "\"" }, { "ldquo", "\"" }, { "bull", "\x7f" }, { "middot", "." }, { "raquo", ">>" },
    { "laquo", "<<" }, { "times", "x" }, { "deg", "o" }, { "euro", "EUR" }, { "pound", "GBP" },
    { "eacute", "e" }, { "egrave", "e" }, { "ecirc", "e" }, { "euml", "e" }, { "aacute", "a" }, { "agrave", "a" }, { "acirc", "a" },
    { "auml", "a" }, { "aring", "a" }, { "iacute", "i" }, { "icirc", "i" }, { "iuml", "i" }, { "oacute", "o" }, { "ocirc", "o" },
    { "ouml", "o" }, { "uacute", "u" }, { "ucirc", "u" }, { "uuml", "u" }, { "ntilde", "n" }, { "ccedil", "c" }, { "szlig", "ss" },
    { "Eacute", "E" }, { "Aacute", "A" }, { "Ouml", "O" }, { "Uuml", "U" }, { "Auml", "A" }, { "iexcl", "!" }, { "iquest", "?" },
    { "rarr", "->" }, { "larr", "<-" }, { "hearts", "<3" }, { "sect", "S" }, { "para", "P" }, { "plusmn", "+/-" }, { "frac12", "1/2" },
};
static char one[2];
static const char *cp_str(unsigned cp) {
    if (cp >= 33 && cp <= 126) { one[0] = (char)cp; one[1] = 0; return one; }
    switch (cp) {
    case 0xA0: case 0x2009: case 0x200A: case 0x2002: case 0x2003: return " ";
    case 0x2018: case 0x2019: return "'";
    case 0x201C: case 0x201D: return "\"";
    case 0x2013: case 0x2014: return "-";
    case 0x2026: return "...";
    case 0x2022: return "\x7f";
    case 0xA9: return "(c)";
    case 0xAE: return "(R)";
    case 0xB7: return ".";
    case 0xD7: return "x";
    case 0x20AC: return "EUR";
    case 0xA3: return "GBP";
    case 0xE9: case 0xE8: case 0xEA: return "e";
    case 0xE0: case 0xE1: case 0xE2: case 0xE4: return "a";
    case 0xF6: case 0xF3: case 0xF4: return "o";
    case 0xFC: case 0xFA: return "u";
    case 0xF1: return "n";
    case 0xE7: return "c";
    case 0x2192: return "->";
    case 0x2190: return "<-";
    case 0x200B: case 0xFEFF: return "";
    }
    return "?";
}
static const char *entity(const char *s, const char *e, int *used) {
    const char *p = s + 1; int n = 0;
    while (p + n < e && n < 10 && p[n] != ';' && p[n] != ' ' && p[n] != '<') n++;
    if (p + n >= e || p[n] != ';') return NULL;
    if (p[0] == '#') {
        unsigned v = 0;
        if (p[1] == 'x' || p[1] == 'X') { for (int i = 2; i < n; i++) { char c = lc(p[i]); v = v * 16 + (unsigned)(c >= 'a' ? c - 'a' + 10 : c - '0'); } }
        else for (int i = 1; i < n; i++) v = v * 10 + (unsigned)(p[i] - '0');
        *used = n + 2; if (v == 32) return " ";
        return cp_str(v);
    }
    for (unsigned i = 0; i < sizeof ents / sizeof ents[0]; i++)
        if ((int)k_strlen(ents[i].n) == n && !k_strncmp(ents[i].n, p, n)) { *used = n + 2; return ents[i].r; }
    return NULL;
}

static void text_run(const char *s, const char *e) {
    while (s < e) {
        u8 c = (u8)*s;
        if (c == ' ' || c == '\n' || c == '\t' || c == '\r') { flush_word(); L.need_space = 1; s++; continue; }
        const char *rep = NULL; int used = 1;
        if (c == '&') { rep = entity(s, e, &used); if (!rep) { one[0] = '&'; one[1] = 0; rep = one; used = 1; } }
        else if (c >= 0xC0) {
            unsigned cp; int l;
            if (c >= 0xF0) { cp = c & 7; l = 4; } else if (c >= 0xE0) { cp = c & 15; l = 3; } else { cp = c & 31; l = 2; }
            int i = 1; for (; i < l && s + i < e && ((u8)s[i] & 0xC0) == 0x80; i++) cp = (cp << 6) | ((u8)s[i] & 63);
            used = i; rep = cp_str(cp);
        } else if (c >= 0x80) { rep = ""; }
        else if (c < 32) { rep = ""; }
        else { one[0] = (char)c; one[1] = 0; rep = one; }
        s += used;
        if (rep[0] == ' ' && rep[1] == 0) { flush_word(); L.need_space = 1; continue; }
        for (; *rep; rep++) { if (wl >= 100) flush_word(); wb[wl++] = *rep; }
    }
}

static void text_pre(const char *s, const char *e) {
    char line[200]; int n = 0;
    for (; s < e; s++) {
        char c = *s;
        if (c == '\r') continue;
        if (c == '\n') {
            if (n) { emit(line, n, n * font_mono.g[0].adv, 0); n = 0; }
            if (L.line_has) end_line(); else { apply_gap(); L.y += font_mono.height; L.x = L.left; }
            continue;
        }
        if (c == '\t') { for (int k = 0; k < 4 && n < 199; k++) line[n++] = ' '; }
        else if ((u8)c >= 32 && (u8)c < 127) line[n++] = c;
        else if ((u8)c >= 0xC0) line[n++] = '?';
        if (n >= 198) { emit(line, n, n * font_mono.g[0].adv, 0); n = 0; }
    }
    if (n) emit(line, n, n * font_mono.g[0].adv, 0);
}

static int get_attr(const char *a, const char *e, const char *name, char *out, int max) {
    int nl = k_strlen(name);
    while (a < e) {
        while (a < e && (*a == ' ' || *a == '\n' || *a == '\t' || *a == '\r' || *a == '/')) a++;
        const char *ns = a;
        while (a < e && *a != '=' && *a != ' ' && *a != '>' && *a != '\n' && *a != '\t' && *a != '/') a++;
        int l = (int)(a - ns);
        while (a < e && (*a == ' ')) a++;
        char val[200]; int vl = 0;
        if (a < e && *a == '=') {
            a++; while (a < e && *a == ' ') a++;
            if (a < e && (*a == '"' || *a == '\'')) { char q = *a++; while (a < e && *a != q) { if (vl < 199) val[vl++] = *a; a++; } if (a < e) a++; }
            else while (a < e && *a != ' ' && *a != '>' && *a != '\n' && *a != '\t') { if (vl < 199) val[vl++] = *a; a++; }
        }
        val[vl] = 0;
        if (l == nl && starts_ci(ns, name)) { k_strcpy(out, val, max); return 1; }
    }
    return 0;
}

static int tag_is(const char *n, const char *t) { return !k_strcmp(n, t); }
static int in_list(const char *n, const char *list) {          /* list: space separated names */
    int nl = k_strlen(n);
    for (const char *p = list; *p;) {
        const char *q = p; while (*q && *q != ' ') q++;
        if ((int)(q - p) == nl && !k_strncmp(p, n, nl)) return 1;
        p = *q ? q + 1 : q;
    }
    return 0;
}

static void li_marker(void) {
    int d = L.depth > 0 ? L.depth - 1 : 0;
    apply_gap();
    Item *it = new_item(); if (!it) return;
    char m[12];
    if (L.depth > 0 && L.ltype[d]) { L.lcount[d]++; k_snprintf(m, sizeof m, "%d.", L.lcount[d]); } else { m[0] = '\x7f'; m[1] = 0; }
    int w = gfx_text_w(&font_ui, m);
    if (pool_len + 12 >= POOL_MAX) { L.overflow = 1; return; }
    it->x = L.left - w - 6; it->y = L.y; it->w = (short)w; it->font = F_UI; it->color = L.color; it->link = -1; it->flags = 0;
    it->off = pool_len; k_strcpy(pool + pool_len, m, 12); pool_len += k_strlen(m) + 1;
    L.lineh = font_ui.height + 3;
}

static void handle_tag(const char *name, int closing, const char *a, const char *e) {
    if (in_list(name, "p")) { block(10); return; }
    if (in_list(name, "div section article header footer nav main form address figure fieldset details summary tr caption center")) { block(name[0] == 't' ? 0 : 2); return; }
    if (tag_is(name, "br")) {
        if (!L.line_has) { apply_gap(); L.y += curf()->height + 3; } else end_line();
        return;
    }
    if (name[0] == 'h' && name[1] >= '1' && name[1] <= '6' && !name[2]) {
        int n = name[1] - '0';
        if (!closing) { block(n == 1 ? 14 : n == 2 ? 12 : 10); L.head = n; } else { L.head = 0; block(8); }
        return;
    }
    if (in_list(name, "b strong th")) { if (!closing) L.bold++; else if (L.bold > 0) L.bold--; if (name[0] == 't' && !closing && L.line_has) { L.x += 18; L.need_space = 0; } return; }
    if (in_list(name, "code kbd samp tt")) { if (!closing) L.mono++; else if (L.mono > 0) L.mono--; return; }
    if (tag_is(name, "pre")) { if (!closing) { block(8); L.pre = 1; } else { L.pre = 0; block(8); } return; }
    if (in_list(name, "ul ol")) {
        if (!closing) { block(6); if (L.depth < 7) { L.ltype[L.depth] = name[0] == 'o'; L.lcount[L.depth] = 0; L.depth++; } L.left += 26; L.x = L.left; }
        else { if (L.depth > 0) L.depth--; L.left -= 26; if (L.left < MARGIN) L.left = MARGIN; block(6); }
        return;
    }
    if (tag_is(name, "li")) { if (!closing) { block(3); li_marker(); } return; }
    if (tag_is(name, "dt")) { block(6); return; }
    if (tag_is(name, "dd")) { if (!closing) { block(2); L.left += 26; L.x = L.left; } else { L.left -= 26; block(2); } return; }
    if (tag_is(name, "blockquote")) { if (!closing) { L.left += 28; block(8); L.x = L.left; } else { L.left -= 28; block(8); } return; }
    if (tag_is(name, "table")) { block(8); return; }
    if (tag_is(name, "td")) { if (!closing && L.line_has) { L.x += 22; L.need_space = 0; } return; }
    if (tag_is(name, "hr")) {
        block(8); apply_gap();
        Item *it = new_item(); if (!it) return;
        it->x = L.left; it->y = L.y + 4; it->w = (short)(L.right - L.left); it->flags = IF_RULE; it->link = -1; it->off = 0; it->font = 0; it->color = 0;
        L.y += 10; L.gap = 8; return;
    }
    if (tag_is(name, "a")) {
        if (closing) { L.link = -1; return; }
        char href[160];
        if (get_attr(a, e, "href", href, sizeof href) && n_links < MAX_LINKS) { k_strcpy(links[n_links], href, 160); L.link = n_links++; }
        else L.link = -1;
        return;
    }
    if (tag_is(name, "img")) {
        if (closing) return;
        char alt[80], txt[100];
        if (!get_attr(a, e, "alt", alt, sizeof alt) || !alt[0]) k_strcpy(alt, "image", sizeof alt);
        k_snprintf(txt, sizeof txt, "[%s]", alt);
        u32 sv = L.color; L.color = PAGE_DIM;
        text_run(txt, txt + k_strlen(txt)); flush_word();
        L.color = sv; L.need_space = 1;
        return;
    }
    if (tag_is(name, "title")) { L.in_title = !closing; return; }
    if (tag_is(name, "input") || tag_is(name, "button")) {
        if (closing) return;
        char ty[24] = "text", val[60] = "";
        get_attr(a, e, "type", ty, sizeof ty);
        if (starts_ci(ty, "hidden")) return;
        get_attr(a, e, "value", val, sizeof val);
        char txt[100]; k_snprintf(txt, sizeof txt, "[%s]", val[0] ? val : (starts_ci(ty, "submit") ? "Submit" : "input"));
        u32 sv = L.color; L.color = PAGE_DIM; text_run(txt, txt + k_strlen(txt)); flush_word(); L.color = sv; L.need_space = 1;
        return;
    }
}

static void layout(int width) {
    n_items = 0; pool_len = 0; n_links = 0; page_title[0] = 0;
    k_memset(&L, 0, sizeof L);
    L.left = MARGIN; L.right = width - MARGIN; if (L.right < L.left + 60) L.right = L.left + 60;
    L.x = L.left; L.link = -1; L.color = PAGE_FG; wl = 0;
    if (!body) { page_h = 0; return; }
    const char *p = body, *end = body + body_len;
    if (page_plain) { L.pre = 1; text_pre(p, end); end_line(); page_h = L.y + 40; return; }
    while (p < end && !L.overflow) {
        if (*p == '<') {
            if (p + 3 < end && !k_strncmp(p, "<!--", 4)) {
                const char *q = p + 4; while (q + 2 < end && k_strncmp(q, "-->", 3)) q++;
                p = (q + 2 < end) ? q + 3 : end; continue;
            }
            char c1 = p + 1 < end ? p[1] : 0;
            if (c1 == '!' || c1 == '?') { while (p < end && *p != '>') p++; if (p < end) p++; continue; }
            int closing = (c1 == '/');
            const char *q = p + 1 + closing;
            if (!isalpha_(*q)) { flush_word(); text_run("<", "<" + 1); p++; continue; }
            char name[16]; int nl = 0;
            while (q < end && isalnum_(*q)) { if (nl < 15) name[nl++] = lc(*q); q++; }
            name[nl] = 0;
            const char *attr = q;
            while (q < end && *q != '>') { if (*q == '"' || *q == '\'') { char qc = *q++; while (q < end && *q != qc) q++; } if (q < end) q++; }
            const char *attr_end = q < end ? q : end;
            p = q < end ? q + 1 : end;
            flush_word();
            handle_tag(name, closing, attr, attr_end);
            if (!closing && in_list(name, "script style noscript svg iframe template")) {
                int cl = k_strlen(name);
                while (p < end) {
                    if (p[0] == '<' && p[1] == '/' && p + 2 + cl <= end && starts_ci(p + 2, name)) { while (p < end && *p != '>') p++; if (p < end) p++; break; }
                    p++;
                }
            }
        } else {
            const char *t = p;
            while (p < end && *p != '<') p++;
            if (L.in_title) {
                int l = k_strlen(page_title);
                for (const char *c = t; c < p && l < 62; c++) { char ch = (*c == '\n' || *c == '\r' || *c == '\t') ? ' ' : *c; if ((u8)ch >= 32 && (u8)ch < 127 && !(ch == ' ' && (l == 0 || page_title[l - 1] == ' '))) page_title[l++] = ch; }
                page_title[l] = 0;
            } else if (L.pre) text_pre(t, p);
            else text_run(t, p);
        }
    }
    flush_word(); end_line();
    page_h = L.y + 40; page_overflow = L.overflow;
}

/* ====================================================================== */
/*  built-in pages                                                         */
/* ====================================================================== */
static const char home_html[] =
    "<h1>MiniMachineOS Browser</h1>"
    "<p>A tiny web browser written from scratch for MiniMachineOS. Type an address above and press <b>Enter</b>.</p>"
    "<h2>Pages to try</h2>"
    "<ul>"
    "<li><a href=\"http://info.cern.ch/\">info.cern.ch</a> - the first website ever made</li>"
    "<li><a href=\"http://example.com/\">example.com</a> - the classic example page</li>"
    "<li><a href=\"http://neverssl.com/\">neverssl.com</a> - a site that stays on plain HTTP</li>"
    "<li><a href=\"http://httpforever.com/\">httpforever.com</a> - another plain HTTP site</li>"
    "</ul>"
    "<h2>Good to know</h2>"
    "<ul>"
    "<li>Only <b>http://</b> is supported. HTTPS needs TLS encryption, which is not implemented yet, so most modern sites will not load.</li>"
    "<li>No JavaScript, CSS or images: pages are shown as plain formatted text with working links.</li>"
    "<li>Running in QEMU? Your own computer is reachable at <b>10.0.2.2</b>, for example <code>http://10.0.2.2:8000/</code> after running <code>python3 -m http.server</code>.</li>"
    "<li>Networking needs an Intel e1000 network card (the QEMU default). The globe icon next to the clock shows the status.</li>"
    "</ul><hr><p>Shortcuts: Ctrl+L address bar, F5 reload, Alt+Left back, Alt+Right forward.</p>";

static void set_page(const char *html, int plain) {
    int n = k_strlen(html); if (n > RESP_MAX) n = RESP_MAX;
    k_memcpy(resp, html, (unsigned)n); resp[n] = 0; resp_len = n; hdr_len = 0;
    body = resp; body_len = n; page_plain = plain;
}
static void esc_append(char *dst, const char *s, int max) {
    int l = k_strlen(dst);
    for (; *s && l < max - 7; s++) {
        if (*s == '<') { k_strcpy(dst + l, "&lt;", max - l); l += 4; }
        else if (*s == '>') { k_strcpy(dst + l, "&gt;", max - l); l += 4; }
        else if (*s == '&') { k_strcpy(dst + l, "&amp;", max - l); l += 5; }
        else { dst[l++] = *s; dst[l] = 0; }
    }
}

/* ====================================================================== */
/*  loader                                                                 */
/* ====================================================================== */

static void show_message(Window *w, const char *title, const char *text, const char *extra) {
    static char html[1400];
    html[0] = 0;
    k_strcat(html, "<h2>", sizeof html); esc_append(html, title, sizeof html); k_strcat(html, "</h2><p>", sizeof html);
    esc_append(html, text, sizeof html); k_strcat(html, "</p>", sizeof html);
    if (extra) k_strcat(html, extra, sizeof html);
    k_strcat(html, "<p><a href=\"about:home\">Go to the home page</a></p>", sizeof html);
    set_page(html, 0);
    BrowserState *b = &w->u.br; b->layout_w = -1; b->scroll = 0; b->st = B_ERROR;
    k_strcpy(page_title, title, sizeof page_title); k_strcpy(b->status, title, sizeof b->status);
    win_invalidate(w);
}
static void fail(Window *w, const char *title, const char *text) {
    BrowserState *b = &w->u.br;
    if (b->sock >= 0) { tcp_close(b->sock); b->sock = -1; }
    show_message(w, title, text, NULL);
    k_strcpy(b->status, title, sizeof b->status);
}

static void update_title(Window *w) {
    BrowserState *b = &w->u.br; char t[48];
    if (page_title[0]) k_snprintf(t, sizeof t, "%s - Browser", page_title);
    else k_strcpy(t, "Browser", sizeof t);
    (void)b; win_set_title(w, t);
}

static void nav(Window *w, const char *input, int mode);

static void abort_load(Window *w) {
    BrowserState *b = &w->u.br;
    if (b->sock >= 0) { tcp_close(b->sock); b->sock = -1; }
    if (b->st == B_DNS || b->st == B_CONNECT || b->st == B_RECV) { b->st = B_IDLE; k_strcpy(b->status, "Stopped", sizeof b->status); }
}

static void start_load(Window *w, const Url *u) {
    BrowserState *b = &w->u.br;
    k_strcpy(b->host, u->host, sizeof b->host); b->port = u->port; k_strcpy(b->path, u->path, sizeof b->path);
    resp_len = 0; hdr_len = -1; req_sent = 0; b->sock = -1;
    const NetInfo *ni = net_info();
    if (ni->status == NET_NO_NIC) {
        show_message(w, "No network adapter", "MiniMachineOS did not find a supported network card.",
            "<ul><li>Supported: Intel e1000 (Intel PRO/1000).</li><li>QEMU: start it with <code>-nic user,model=e1000</code> (this is the default).</li>"
            "<li>VirtualBox: set the adapter type to <b>Intel PRO/1000 MT Desktop</b>.</li></ul>");
        return;
    }
    if (ni->status != NET_UP) {
        show_message(w, "Waiting for network", "No IP address yet - DHCP has not answered. Wait a few seconds and press F5.", NULL);
        return;
    }
    b->st = B_DNS; b->t0 = b->tlast = gui_now();
    k_snprintf(b->status, sizeof b->status, "Looking up %s...", b->host);
    if (b->port == 80) k_snprintf(reqbuf, sizeof reqbuf, "GET %s HTTP/1.1\r\nHost: %s\r\n", b->path, b->host);
    else k_snprintf(reqbuf, sizeof reqbuf, "GET %s HTTP/1.1\r\nHost: %s:%d\r\n", b->path, b->host, b->port);
    k_strcat(reqbuf, "User-Agent: MiniMachineOS/" OS_VERSION " (MiniBrowser)\r\nAccept: text/html,text/plain;q=0.9,*/*;q=0.5\r\n"
                     "Accept-Encoding: identity\r\nConnection: close\r\n\r\n", sizeof reqbuf);
    req_len = k_strlen(reqbuf);
    win_invalidate(w);
}

static void nav(Window *w, const char *input, int mode) {
    BrowserState *b = &w->u.br;
    char full[200]; int n = 0;
    while (*input == ' ') input++;
    if (starts_ci(input, "about:") || starts_ci(input, "http://") || starts_ci(input, "https://")) k_strcpy(full, input, sizeof full);
    else k_snprintf(full, sizeof full, "http://%s", input);
    n = k_strlen(full); while (n > 0 && full[n - 1] == ' ') full[--n] = 0;
    if (mode == 0 || mode == 2) {
        if (mode == 2 && b->hcount > 0) k_strcpy(b->hist[b->hpos], full, 200);
        else {
            if (b->hpos < b->hcount - 1) b->hcount = b->hpos + 1;
            if (b->hcount == 12) { for (int i = 1; i < 12; i++) k_strcpy(b->hist[i - 1], b->hist[i], 200); b->hcount--; }
            k_strcpy(b->hist[b->hcount++], full, 200); b->hpos = b->hcount - 1;
        }
    }
    if (mode != 2) b->redirects = 0;
    if (b->sock >= 0) { tcp_close(b->sock); b->sock = -1; }
    k_strcpy(b->cur, full, sizeof b->cur); k_strcpy(b->url, full, sizeof b->url);
    b->ulen = k_strlen(b->url); b->ucur = b->ulen; b->usel = 0; b->ufocus = 0;
    b->scroll = 0; b->layout_w = -1; b->hover_link = -1;
    if (starts_ci(full, "about:")) {
        set_page(home_html, 0); b->st = B_DONE; k_strcpy(page_title, "Home", sizeof page_title);
        k_strcpy(b->status, "Home", sizeof b->status); update_title(w); win_invalidate(w); return;
    }
    Url u;
    if (!url_parse(full, &u)) { show_message(w, "Invalid address", "That does not look like a web address.", NULL); update_title(w); return; }
    if (u.https) {
        show_message(w, "HTTPS is not supported yet", "This browser cannot open https:// pages because TLS encryption is not implemented.",
            "<p>Try the plain-HTTP version of the address if the site offers one. Many sites redirect to HTTPS, so they cannot be opened.</p>");
        k_strcpy(b->status, "HTTPS not supported", sizeof b->status); update_title(w); return;
    }
    start_load(w, &u);
    update_title(w);
}

static int hexv(char c) { c = lc(c); return (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : -1; }
static int dechunk(char *d, int n) {
    char *r = d, *w = d, *end = d + n;
    while (r < end) {
        int sz = 0, any = 0;
        while (r < end && hexv(*r) >= 0) { sz = sz * 16 + hexv(*r++); any = 1; }
        while (r < end && *r != '\n') r++;
        if (r < end) r++;
        if (!any || sz == 0) break;
        if (sz > end - r) sz = (int)(end - r);
        k_memmove(w, r, (unsigned)sz); w += sz; r += sz;
        if (r < end && *r == '\r') r++;
        if (r < end && *r == '\n') r++;
    }
    return (int)(w - d);
}

static int find_hdr_end(void) {
    for (int i = 3; i < resp_len; i++) if (resp[i] == '\n' && resp[i - 1] == '\r' && resp[i - 2] == '\n' && resp[i - 3] == '\r') return i + 1;
    return -1;
}
static void parse_headers(int hl) {
    k_memset(&H, 0, sizeof H); H.clen = -1;
    int i = 0;
    if (hl > 12 && starts_ci(resp, "HTTP/")) { i = 0; while (i < hl && resp[i] != ' ') i++; H.code = k_atoi(resp + i); }
    while (i < hl && resp[i] != '\n') i++;
    i++;
    while (i < hl) {
        int ls = i; while (i < hl && resp[i] != '\r' && resp[i] != '\n') i++;
        const char *l = resp + ls; int ll = i - ls;
        while (i < hl && (resp[i] == '\r' || resp[i] == '\n')) i++;
        if (ll <= 0) break;
        const char *v = NULL; int vl = 0;
        for (int c = 0; c < ll; c++) if (l[c] == ':') { v = l + c + 1; vl = ll - c - 1; break; }
        if (!v) continue;
        while (vl > 0 && *v == ' ') { v++; vl--; }
        if (starts_ci(l, "content-length:")) H.clen = k_atoi(v);
        else if (starts_ci(l, "transfer-encoding:")) { char t[32]; int n = k_min(vl, 31); k_memcpy(t, v, (unsigned)n); t[n] = 0; if (k_stricmp_sub(t, "chunked")) H.chunked = 1; }
        else if (starts_ci(l, "content-encoding:")) { char t[32]; int n = k_min(vl, 31); k_memcpy(t, v, (unsigned)n); t[n] = 0; if (k_stricmp_sub(t, "gzip") || k_stricmp_sub(t, "deflate") || k_stricmp_sub(t, "br")) H.gzip = 1; }
        else if (starts_ci(l, "location:")) { int n = k_min(vl, 199); k_memcpy(H.loc, v, (unsigned)n); H.loc[n] = 0; }
        else if (starts_ci(l, "content-type:")) { int n = k_min(vl, 63); k_memcpy(H.ctype, v, (unsigned)n); H.ctype[n] = 0; }
    }
}

static void finish(Window *w, int partial) {
    BrowserState *b = &w->u.br;
    if (b->sock >= 0) { tcp_close(b->sock); b->sock = -1; }
    if (hdr_len < 0) hdr_len = find_hdr_end();
    if (hdr_len < 0) { fail(w, "Invalid response", "The server did not send a valid HTTP response."); return; }
    parse_headers(hdr_len);
    body = resp + hdr_len; body_len = resp_len - hdr_len;
    if (H.chunked) body_len = dechunk(body, body_len);
    else if (H.clen >= 0 && H.clen < body_len) body_len = H.clen;
    body[body_len] = 0;
    if (H.code >= 300 && H.code < 400 && H.loc[0]) {
        if (b->redirects >= 6) { fail(w, "Too many redirects", "The server keeps redirecting."); return; }
        char next[200]; resolve(b->cur, H.loc, next, sizeof next);
        b->redirects++;
        nav(w, next, 2);
        return;
    }
    if (H.gzip) { show_message(w, "Compressed content", "The server sent compressed data, which this browser cannot decode.", NULL); update_title(w); return; }
    int text = !H.ctype[0] || k_stricmp_sub(H.ctype, "text/") || k_stricmp_sub(H.ctype, "xhtml");
    if (!text) {
        char m[120]; k_snprintf(m, sizeof m, "Content type: %s (%d bytes). Only web pages and text can be shown.", H.ctype, body_len);
        show_message(w, "Cannot display this file", m, NULL); update_title(w); return;
    }
    page_plain = k_stricmp_sub(H.ctype, "text/plain");
    b->st = B_DONE; b->layout_w = -1; b->scroll = 0;
    char t[96];
    k_snprintf(t, sizeof t, "Done - HTTP %d - %d KB%s", H.code, (body_len + 512) / 1024, partial ? " (incomplete)" : "");
    k_strcpy(b->status, t, sizeof b->status);
    page_title[0] = 0;
    layout(500); if (!page_title[0]) k_strcpy(page_title, b->host, sizeof page_title);
    update_title(w);
    win_invalidate(w);
}

static void br_tick(Window *w, u32 ms) {
    BrowserState *b = &w->u.br;
    if (b->st == B_DNS) {
        u32 ip; int r = dns_lookup(b->host, &ip);
        if (r == 1) {
            b->sock = tcp_open(ip, (u16)b->port);
            if (b->sock < 0) { fail(w, "Connection failed", "No free network sockets."); return; }
            b->st = B_CONNECT; b->t0 = ms;
            char ips[20]; ip_to_str(ip, ips, sizeof ips);
            k_snprintf(b->status, sizeof b->status, "Connecting to %s...", ips); win_invalidate(w);
        } else if (r < 0) { char m[140]; m[0] = 0; k_strcat(m, "Could not find the server ", sizeof m); k_strcat(m, b->host, sizeof m); fail(w, "Server not found", m); }
        else if (ms - b->t0 > 12000) fail(w, "Server not found", "The DNS lookup timed out.");
    } else if (b->st == B_CONNECT) {
        int s = tcp_state(b->sock);
        if (s == TCP_OPEN || s == TCP_PEER_CLOSED) {
            if (!req_sent && tcp_send(b->sock, reqbuf, req_len) == req_len) req_sent = 1;
            if (req_sent) { b->st = B_RECV; b->tlast = ms; k_snprintf(b->status, sizeof b->status, "Waiting for %s...", b->host); win_invalidate(w); }
        } else if (s == TCP_ERROR || s == TCP_CLOSED) fail(w, "Connection failed", "The server refused the connection or could not be reached.");
        else if (ms - b->t0 > 15000) fail(w, "Connection timed out", "The server did not answer.");
    } else if (b->st == B_RECV) {
        int got = 0;
        for (int k = 0; k < 8; k++) {
            int space = RESP_MAX - resp_len;
            if (space <= 0) { finish(w, 1); return; }
            int n = tcp_recv(b->sock, resp + resp_len, space > 4096 ? 4096 : space);
            if (n <= 0) break;
            resp_len += n; got += n; b->tlast = ms;
        }
        if (got) {
            resp[resp_len] = 0;
            if (hdr_len < 0) { hdr_len = find_hdr_end(); if (hdr_len >= 0) parse_headers(hdr_len); }
            if (ms - b->t0 > 0 && (resp_len / 2048) != ((resp_len - got) / 2048)) { k_snprintf(b->status, sizeof b->status, "Receiving... %d KB", resp_len / 1024); win_invalidate(w); }
            if (hdr_len >= 0) {
                if (!H.chunked && H.clen >= 0 && resp_len - hdr_len >= H.clen) { finish(w, 0); return; }
                if (H.chunked && resp_len >= 5 && !k_strncmp(resp + resp_len - 5, "0\r\n\r\n", 5)) { finish(w, 0); return; }
            }
        }
        int s = tcp_state(b->sock);
        if (s == TCP_PEER_CLOSED && !got) { finish(w, 0); return; }
        if (s == TCP_ERROR || s == TCP_CLOSED) { if (resp_len > 0) finish(w, 1); else fail(w, "Connection lost", "The connection was closed before any data arrived."); return; }
        if (ms - b->tlast > 15000) { if (resp_len > 0) finish(w, 1); else fail(w, "No response", "The server did not answer in time."); }
    }
}

/* ====================================================================== */
/*  UI                                                                     */
/* ====================================================================== */
static Window *g_br;
int browser_busy(void) { return g_br && (g_br->u.br.st == B_DNS || g_br->u.br.st == B_CONNECT || g_br->u.br.st == B_RECV); }
const char *browser_status(void) { return g_br ? g_br->u.br.status : ""; }
static void br_init(Window *w, const char *arg) {
    BrowserState *b = &w->u.br; g_br = w;
    b->sock = -1; b->hover_link = -1; b->hot = -1; b->hcount = 0; b->hpos = 0; b->layout_w = -1;
    page_title[0] = 0; body = NULL; body_len = 0; n_items = 0;
    nav(w, (arg && arg[0]) ? arg : "about:home", 0);
}
static void br_reopen(Window *w, const char *arg) { if (arg && arg[0]) nav(w, arg, 0); }
static void br_close(Window *w) { abort_load(w); if (g_br == w) g_br = NULL; }

static int busy(BrowserState *b) { return b->st == B_DNS || b->st == B_CONNECT || b->st == B_RECV; }

static void content_rect(Window *w, int *cy, int *ch, int *cw) {
    *cw = w->w - 2; *cy = TOOL_H; *ch = w->h - TB_H - 1 - TOOL_H - STAT_H;
}
static int max_scroll(Window *w) { int cy, ch, cw; content_rect(w, &cy, &ch, &cw); return k_max(0, page_h - ch); }

static void go_hist(Window *w, int d) {
    BrowserState *b = &w->u.br;
    int np = b->hpos + d;
    if (np < 0 || np >= b->hcount) return;
    b->hpos = np;
    nav(w, b->hist[np], 1);
}

static int link_at(Window *w, int mx, int my) {
    BrowserState *b = &w->u.br;
    int cy, ch, cw; content_rect(w, &cy, &ch, &cw);
    if (my < cy || my >= cy + ch || mx >= cw - SBW) return -1;
    int py = my - cy + b->scroll;
    for (int i = 0; i < n_items; i++) {
        Item *it = &items[i];
        if (it->link < 0 || (it->flags & IF_RULE)) continue;
        if (py >= it->y && py < it->y + fonts[it->font]->height + 2 && mx >= it->x && mx < it->x + it->w) return it->link;
    }
    return -1;
}

static void url_edit_key(Window *w, int key, int mods) {
    BrowserState *b = &w->u.br;
    if (key == KEY_ENTER) { char u[200]; k_strcpy(u, b->url, sizeof u); if (u[0]) nav(w, u, 0); return; }
    if (key == KEY_ESC) { b->ufocus = 0; k_strcpy(b->url, b->cur, sizeof b->url); b->ulen = k_strlen(b->url); b->usel = 0; win_invalidate(w); return; }
    if (b->usel && (key == KEY_BACKSPACE || key == KEY_DEL || (key >= 32 && key < 127 && !(mods & (MOD_CTRL | MOD_ALT))))) { b->url[0] = 0; b->ulen = 0; b->ucur = 0; b->usel = 0; if (key == KEY_BACKSPACE || key == KEY_DEL) { win_invalidate(w); return; } }
    if (key == KEY_BACKSPACE) { if (b->ucur > 0) { k_memmove(b->url + b->ucur - 1, b->url + b->ucur, (unsigned)(b->ulen - b->ucur + 1)); b->ucur--; b->ulen--; } }
    else if (key == KEY_DEL) { if (b->ucur < b->ulen) { k_memmove(b->url + b->ucur, b->url + b->ucur + 1, (unsigned)(b->ulen - b->ucur)); b->ulen--; } }
    else if (key == KEY_LEFT) { b->usel = 0; if (b->ucur > 0) b->ucur--; }
    else if (key == KEY_RIGHT) { b->usel = 0; if (b->ucur < b->ulen) b->ucur++; }
    else if (key == KEY_HOME) { b->usel = 0; b->ucur = 0; }
    else if (key == KEY_END) { b->usel = 0; b->ucur = b->ulen; }
    else if (key >= 32 && key < 127 && !(mods & (MOD_CTRL | MOD_ALT))) {
        if (b->ulen < 190) { k_memmove(b->url + b->ucur + 1, b->url + b->ucur, (unsigned)(b->ulen - b->ucur + 1)); b->url[b->ucur++] = (char)key; b->ulen++; }
    } else return;
    win_invalidate(w);
}

static void br_key(Window *w, int key, int mods) {
    BrowserState *b = &w->u.br;
    if ((mods & MOD_CTRL) && key == 'l') { b->ufocus = 1; b->usel = 1; b->ucur = b->ulen; win_invalidate(w); return; }
    if (key == KEY_F5) { char u[200]; k_strcpy(u, b->cur, sizeof u); nav(w, u, 1); return; }
    if ((mods & MOD_ALT) && key == KEY_LEFT) { go_hist(w, -1); return; }
    if ((mods & MOD_ALT) && key == KEY_RIGHT) { go_hist(w, 1); return; }
    if (b->ufocus) { url_edit_key(w, key, mods); return; }
    if (key == KEY_ESC) { if (busy(b)) { abort_load(w); win_invalidate(w); } return; }
    int ms = max_scroll(w), cy, ch, cw; content_rect(w, &cy, &ch, &cw);
    int old = b->scroll;
    if (key == KEY_DOWN) b->scroll += 44; else if (key == KEY_UP) b->scroll -= 44;
    else if (key == KEY_PGDN || key == ' ') b->scroll += ch - 40; else if (key == KEY_PGUP) b->scroll -= ch - 40;
    else if (key == KEY_HOME) b->scroll = 0; else if (key == KEY_END) b->scroll = ms;
    else if (key == '/' || key == 'l') { b->ufocus = 1; b->usel = 1; }
    else return;
    b->scroll = k_clamp(b->scroll, 0, ms);
    if (b->scroll != old || b->ufocus) win_invalidate(w);
}

static void tool_rect(int i, int cw, int *x, int *y, int *w, int *h) {
    *y = 8; *h = 30; *w = 34;
    if (i < 3) *x = 8 + i * 38; else { *x = 8 + 3 * 38 + 4; *w = cw - *x - 10; }
}

static void br_mouse(Window *w, int x, int y, int ev, int clicks) {
    BrowserState *b = &w->u.br;
    int cy, ch, cw; content_rect(w, &cy, &ch, &cw);
    if (ev == EV_MOVE) {
        if (b->dragging) {
            int ms = max_scroll(w), track = ch - 8; if (track < 1) track = 1;
            b->scroll = k_clamp((y - cy - 4) * ms / track, 0, ms); win_invalidate(w); return;
        }
        int hot = -1;
        if (y >= 0 && y < TOOL_H) for (int i = 0; i < 3; i++) { int bx, by, bw, bh; tool_rect(i, cw, &bx, &by, &bw, &bh); if (ui_inside(x, y, bx, by, bw, bh)) hot = i; }
        int hl = link_at(w, x, y);
        if (hot != b->hot || hl != b->hover_link) { b->hot = hot; b->hover_link = hl; win_invalidate(w); }
    } else if (ev == EV_WHEEL) {
        int ms = max_scroll(w); b->scroll = k_clamp(b->scroll + clicks * 60, 0, ms); win_invalidate(w);
    } else if (ev == EV_UP) { b->dragging = 0; }
    else if (ev == EV_DOWN) {
        if (y < TOOL_H) {
            for (int i = 0; i < 3; i++) {
                int bx, by, bw, bh; tool_rect(i, cw, &bx, &by, &bw, &bh);
                if (ui_inside(x, y, bx, by, bw, bh)) {
                    if (i == 0) go_hist(w, -1); else if (i == 1) go_hist(w, 1);
                    else if (busy(b)) { abort_load(w); win_invalidate(w); }
                    else { char u[200]; k_strcpy(u, b->cur, sizeof u); nav(w, u, 1); }
                    return;
                }
            }
            int fx, fy, fw, fh; tool_rect(3, cw, &fx, &fy, &fw, &fh);
            if (ui_inside(x, y, fx, fy, fw, fh)) { b->ufocus = 1; b->usel = 1; b->ucur = b->ulen; win_invalidate(w); }
            else if (b->ufocus) { b->ufocus = 0; b->usel = 0; win_invalidate(w); }
            return;
        }
        if (b->ufocus) { b->ufocus = 0; b->usel = 0; win_invalidate(w); }
        if (y >= cy && y < cy + ch) {
            if (x >= cw - SBW - 2 && page_h > ch) {
                b->dragging = 1; int ms = max_scroll(w), track = ch - 8;
                b->scroll = k_clamp((y - cy - 4) * ms / (track > 0 ? track : 1), 0, ms); win_invalidate(w); return;
            }
            int l = link_at(w, x, y);
            if (l >= 0) { char u[200]; resolve(b->cur, links[l], u, sizeof u); if (u[0] && u[0] != '#') nav(w, u, 0); }
        }
        (void)clicks;
    }
}

static void br_draw(Window *w, int x, int y, int cw, int ch) {
    BrowserState *b = &w->u.br;
    /* toolbar */
    gfx_fill(x, y, cw, TOOL_H, theme.win_alt);
    gfx_fill(x, y + TOOL_H - 1, cw, 1, theme.border);
    for (int i = 0; i < 3; i++) {
        int bx, by, bw, bh; tool_rect(i, cw, &bx, &by, &bw, &bh);
        int en = (i == 0) ? b->hpos > 0 : (i == 1) ? b->hpos < b->hcount - 1 : 1;
        if (b->hot == i && en) gfx_round(x + bx, y + by, bw, bh, 6, CORNER_ALL, theme.hover, 255);
        u32 c = en ? theme.text : theme.dim;
        int cx = x + bx + bw / 2, cy = y + by + bh / 2;
        if (i == 0) { gfx_line(cx + 6, cy, cx - 6, cy, 30, c, 255); gfx_line(cx - 6, cy, cx - 1, cy - 5, 30, c, 255); gfx_line(cx - 6, cy, cx - 1, cy + 5, 30, c, 255); }
        else if (i == 1) { gfx_line(cx - 6, cy, cx + 6, cy, 30, c, 255); gfx_line(cx + 6, cy, cx + 1, cy - 5, 30, c, 255); gfx_line(cx + 6, cy, cx + 1, cy + 5, 30, c, 255); }
        else if (busy(b)) { gfx_line(cx - 5, cy - 5, cx + 5, cy + 5, 30, c, 255); gfx_line(cx - 5, cy + 5, cx + 5, cy - 5, 30, c, 255); }
        else {
            gfx_circle(cx, cy, 8, c, 255); gfx_circle(cx, cy, 6, b->hot == i ? theme.hover : theme.win_alt, 255);
            gfx_fill(cx + 1, cy - 9, 9, 6, b->hot == i ? theme.hover : theme.win_alt);
            gfx_line(cx + 2, cy - 7, cx + 8, cy - 7, 28, c, 255); gfx_line(cx + 8, cy - 7, cx + 8, cy - 1, 28, c, 255);
        }
    }
    { int fx, fy, fw, fh; tool_rect(3, cw, &fx, &fy, &fw, &fh);
      gfx_round_border(x + fx, y + fy, fw, fh, 8, theme.field, b->ufocus ? theme.accent : theme.border);
      Clip old = gfx_clip_push(x + fx + 6, y + fy, fw - 12, fh);
      int tx = x + fx + 12, ty = y + fy + (fh - font_ui.height) / 2;
      int tw = gfx_text_w(&font_ui, b->url);
      if (b->usel && b->ufocus) gfx_fill_a(tx - 2, ty, tw + 4, font_ui.height, theme.accent, 110);
      gfx_text(&font_ui, tx, ty, b->url, theme.text);
      if (b->ufocus && !b->usel && !g_blink) {
          char t[200]; k_strcpy(t, b->url, sizeof t); t[b->ucur] = 0;
          gfx_fill(tx + gfx_text_w(&font_ui, t), ty, 1, font_ui.height, theme.text);
      }
      gfx_clip_set(old); }
    /* page */
    int cy, chh, cww; content_rect(w, &cy, &chh, &cww);
    if (b->layout_w != cww) { layout(cww - SBW); b->layout_w = cww; if (page_title[0]) update_title(w); }
    int ms = k_max(0, page_h - chh); if (b->scroll > ms) b->scroll = ms;
    Clip old = gfx_clip_push(x, y + cy, cww, chh);
    gfx_fill(x, y + cy, cww, chh, PAGE_BG);
    for (int i = 0; i < n_items; i++) {
        Item *it = &items[i];
        int iy = y + cy + it->y - b->scroll;
        if (iy > y + cy + chh) break;
        if (iy + 40 < y + cy) { if (!(it->flags & IF_RULE) && it->y + 60 < b->scroll) continue; }
        if (it->flags & IF_RULE) { gfx_fill(x + it->x, iy, it->w, 1, 0xDADCE0); continue; }
        const Font *f = fonts[it->font];
        if (iy + f->height < y + cy) continue;
        gfx_text(f, x + it->x, iy, pool + it->off, it->color);
        if (it->flags & IF_UNDER) {
            int uw = it->w;
            if (i + 1 < n_items && items[i + 1].link == it->link && items[i + 1].y == it->y) uw = items[i + 1].x - it->x;
            gfx_fill(x + it->x, iy + f->ascent + 2, uw, 1, it->link == b->hover_link ? 0x0B3D91 : it->color);
        }
    }
    if (page_h > chh) {
        int track = chh - 8, th = k_max(30, track * chh / page_h), ty = y + cy + 4 + (ms ? (track - th) * b->scroll / ms : 0);
        gfx_round(x + cww - SBW + 2, ty, SBW - 6, th, 3, CORNER_ALL, b->dragging ? 0x80868B : 0xBDC1C6, 255);
    }
    gfx_clip_set(old);
    /* status bar */
    int sy = y + ch - STAT_H;
    gfx_fill(x, sy, cw, STAT_H, theme.win_alt); gfx_fill(x, sy, cw, 1, theme.border);
    const char *st = b->status;
    char tmp[200];
    if (b->hover_link >= 0 && b->hover_link < n_links) { resolve(b->cur, links[b->hover_link], tmp, sizeof tmp); st = tmp; }
    if (page_overflow && st == b->status && !busy(b)) { k_snprintf(tmp, sizeof tmp, "%s - page too large, truncated", b->status); st = tmp; }
    gfx_text_fit(&font_sm, x + 12, sy + (STAT_H - font_sm.height) / 2, cw - 24, st, busy(b) ? theme.accent : theme.dim);
}

const AppDesc app_browser = {
    "Browser", "Browse the web (HTTP)", ICON_BROWSER, 920, 620, 480, 300,
    br_init, br_draw, br_mouse, br_key, br_tick, 1, br_reopen, br_close
};
