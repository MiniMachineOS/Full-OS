/* app_settings.c - appearance settings */
#include "app.h"
#include "klib.h"
#include "net.h"
#include "hw.h"
#include "account.h"

#define PAD 28
#define TW 112
#define TH 66

/* item ids: 0,1 theme; 10..15 accent; 20..24 wallpaper */
static int item_rect(int id, int cw, int *x, int *y, int *w, int *h) {
    if (id < 2) { *x = PAD + id * 116; *y = 80; *w = 104; *h = 40; return 1; }
    if (id >= 10 && id < 16) { *x = PAD + (id - 10) * 52; *y = 172; *w = 40; *h = 40; return 1; }
    if (id >= 20 && id < 25) {
        int cols = k_max(1, (cw - 2 * PAD + 16) / (TW + 16));
        int i = id - 20;
        *x = PAD + (i % cols) * (TW + 16); *y = 262 + (i / cols) * (TH + 40); *w = TW; *h = TH;
        return 1;
    }
    if (id == 30) { *x = cw - PAD - 110; *y = 428; *w = 110; *h = 32; return 1; }
    return 0;
}
static int hit(Window *w, int x, int y) {
    int cw = w->w - 2;
    static const int ids[] = { 0, 1, 10, 11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 30 };
    for (unsigned i = 0; i < sizeof ids / sizeof ids[0]; i++) {
        int bx = 0, by = 0, bw = 0, bh = 0; item_rect(ids[i], cw, &bx, &by, &bw, &bh);
        if (ui_inside(x, y, bx, by, bw, bh)) return ids[i];
    }
    return -1;
}
static void set_init(Window *w, const char *arg) { (void)arg; w->u.set.hot = -1; }
static void set_mouse(Window *w, int x, int y, int ev, int clicks) {
    (void)clicks;
    SettingsState *s = &w->u.set;
    int h = hit(w, x, y);
    if (ev == EV_MOVE) { if (h != s->hot) { s->hot = h; win_invalidate(w); } return; }
    if (ev != EV_DOWN || h < 0) return;
    if (h == 30) { net_renew(); win_invalidate(w); return; }
    if (h < 2) cfg_dark = (h == 0);
    else if (h < 20) cfg_accent = h - 10;
    else cfg_wall = h - 20;
    theme_apply();
    persist_save_config();
    gui_damage_all();
}

static void set_draw(Window *w, int x, int y, int cw, int ch) {
    SettingsState *s = &w->u.set;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    gfx_text(&font_big, x + PAD, y + 8, "Appearance", theme.text);
    gfx_text(&font_sm, x + PAD + 0, y + 56, "Theme", theme.dim);
    for (int i = 0; i < 2; i++) {
        int bx = 0, by = 0, bw = 0, bh = 0; item_rect(i, cw, &bx, &by, &bw, &bh);
        int sel = (cfg_dark == (i == 0));
        gfx_round(x + bx - 2, y + by - 2, bw + 4, bh + 4, 9, CORNER_ALL, sel ? theme.accent : theme.border, 255);
        gfx_round(x + bx, y + by, bw, bh, 7, CORNER_ALL, i == 0 ? 0x2B2D31 : 0xFAFAFB, 255);
        gfx_text_center(&font_uib, x + bx, y + by, bw, bh, i == 0 ? "Dark" : "Light", i == 0 ? 0xE8EAED : 0x1F2328);
    }
    gfx_text(&font_sm, x + PAD, y + 150, "Accent colour", theme.dim);
    for (int i = 0; i < N_ACCENTS; i++) {
        int bx = 0, by = 0, bw = 0, bh = 0; item_rect(10 + i, cw, &bx, &by, &bw, &bh);
        int cx = x + bx + 20, cy = y + by + 20;
        if (cfg_accent == i) gfx_circle(cx, cy, 20, theme.text, 255);
        else if (s->hot == 10 + i) gfx_circle(cx, cy, 20, theme.dim, 255);
        if (cfg_accent == i || s->hot == 10 + i) gfx_circle(cx, cy, 18, theme.win_bg, 255);
        gfx_circle(cx, cy, 15, accent_colors[i], 255);
    }
    gfx_text(&font_sm, x + PAD, y + 240, "Wallpaper", theme.dim);
    for (int i = 0; i < N_WALLS; i++) {
        int bx = 0, by = 0, bw = 0, bh = 0; item_rect(20 + i, cw, &bx, &by, &bw, &bh);
        int sel = cfg_wall == i;
        gfx_round(x + bx - 3, y + by - 3, bw + 6, bh + 6, 8, CORNER_ALL, sel ? theme.accent : (s->hot == 20 + i ? theme.dim : theme.win_bg), 255);
        wallpaper_thumb(i, x + bx, y + by, bw, bh);
        gfx_text(&font_ui, x + bx, y + by + bh + 8, wall_names[i], theme.text);
    }
    char b[96];
    gfx_text(&font_sm, x + PAD, y + 376, "Display", theme.dim);
    k_snprintf(b, sizeof b, "%d x %d, 32-bit colour", gfx_w, gfx_h);
    gfx_text(&font_ui, x + PAD, y + 396, b, theme.text);
    gfx_fill(x + PAD, y + 420, cw - 2 * PAD, 1, theme.border);
    gfx_text(&font_sm, x + PAD, y + 438, "Network", theme.dim);
    { int bx = 0, by = 0, bw = 0, bh = 0; item_rect(30, cw, &bx, &by, &bw, &bh);
      ui_button(x + bx, y + by + 6, bw, bh, "Renew address", s->hot == 30, 0); }
    const NetInfo *ni = net_info();
    const char *stt = ni->status == NET_UP ? "Connected" : ni->status == NET_WAIT_DHCP ? "Waiting for an IP address (DHCP)..." : "No supported network adapter found";
    u32 sc = ni->status == NET_UP ? 0x3FB950 : ni->status == NET_WAIT_DHCP ? 0xE3B341 : 0xE5484D;
    gfx_circle(x + PAD + 5, y + 468, 5, sc, 255);
    if (ni->status == NET_UP) k_snprintf(b, sizeof b, "%s (%s)", stt, hw_nic_name()); else k_strcpy(b, stt, sizeof b);
    gfx_text(&font_ui, x + PAD + 18, y + 459, b, theme.text);
    if (ni->status == NET_UP) {
        char ip[20], gw[20], dn[20];
        ip_to_str(ni->ip, ip, sizeof ip); ip_to_str(ni->gw, gw, sizeof gw); ip_to_str(ni->dns, dn, sizeof dn);
        k_snprintf(b, sizeof b, "IP address   %s", ip); gfx_text(&font_ui, x + PAD + 18, y + 484, b, theme.dim);
        k_snprintf(b, sizeof b, "Gateway      %s", gw); gfx_text(&font_ui, x + PAD + 18, y + 506, b, theme.dim);
        k_snprintf(b, sizeof b, "DNS server   %s", dn); gfx_text(&font_ui, x + PAD + 18, y + 528, b, theme.dim);
    }
    if (ni->status != NET_NO_NIC) {
        k_snprintf(b, sizeof b, "MAC address  %02x:%02x:%02x:%02x:%02x:%02x", ni->mac[0], ni->mac[1], ni->mac[2], ni->mac[3], ni->mac[4], ni->mac[5]);
        gfx_text(&font_ui, x + PAD + 18, y + 550, b, theme.dim);
    }
}

const AppDesc app_settings = {
    "Settings", "Appearance and display", ICON_SETTINGS, 720, 650, 520, 460,
    set_init, set_draw, set_mouse, NULL, NULL
};
