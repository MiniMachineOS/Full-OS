/* e1000.c - PCI scan + Intel PRO/1000 (e1000) driver, polled, legacy descriptors.
   QEMU's default NIC, also available in VirtualBox ("Intel PRO/1000 MT Desktop") and VMware. */
#include "../src/types.h"
#include "../src/hw.h"
#include "../src/klib.h"

static inline void outl(u16 p, u32 v) { __asm__ volatile("outl %0, %1" : : "a"(v), "Nd"(p)); }
static inline u32 inl(u16 p) { u32 v; __asm__ volatile("inl %1, %0" : "=a"(v) : "Nd"(p)); return v; }

static u32 pci_read(int bus, int dev, int fn, int off) {
    outl(0xCF8, 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | ((u32)fn << 8) | (u32)(off & 0xFC));
    return inl(0xCFC);
}
static void pci_write(int bus, int dev, int fn, int off, u32 v) {
    outl(0xCF8, 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | ((u32)fn << 8) | (u32)(off & 0xFC));
    outl(0xCFC, v);
}

static const u16 ids[] = { 0x1000, 0x1001, 0x1004, 0x1008, 0x100C, 0x100E, 0x100F, 0x1010, 0x1012, 0x1015, 0x1016,
                           0x1017, 0x101E, 0x1026, 0x1027, 0x1028, 0x10D3, 0x1075, 0x1076, 0x1077, 0x1078, 0x1079,
                           0x107A, 0x107B, 0x107C };

#define R_CTRL 0x0000
#define R_STATUS 0x0008
#define R_EERD 0x0014
#define R_IMC 0x00D8
#define R_RCTL 0x0100
#define R_TCTL 0x0400
#define R_TIPG 0x0410
#define R_RDBAL 0x2800
#define R_RDBAH 0x2804
#define R_RDLEN 0x2808
#define R_RDH 0x2810
#define R_RDT 0x2818
#define R_TDBAL 0x3800
#define R_TDBAH 0x3804
#define R_TDLEN 0x3808
#define R_TDH 0x3810
#define R_TDT 0x3818
#define R_MTA 0x5200
#define R_RAL0 0x5400
#define R_RAH0 0x5404

#define NRX 32
#define NTX 16
typedef struct { u32 addr_lo, addr_hi; u16 length, csum; u8 status, errors; u16 special; } __attribute__((packed)) RxD;
typedef struct { u32 addr_lo, addr_hi; u16 length; u8 cso, cmd, status, css; u16 special; } __attribute__((packed)) TxD;
static RxD rxr[NRX] __attribute__((aligned(16)));
static TxD txr[NTX] __attribute__((aligned(16)));
static u8 rxbuf[NRX][2048] __attribute__((aligned(16)));
static u8 txbuf[NTX][2048] __attribute__((aligned(16)));
static volatile u32 *mmio;
static int ready, rx_cur, tx_tail;

static u32 rd(int off) { return mmio[off / 4]; }
static void wr(int off, u32 v) { mmio[off / 4] = v; }
static void wait_ms(u32 ms) { u32 t = hw_ms(); while (hw_ms() - t < ms) __asm__ volatile("pause"); }

const char *hw_nic_name(void) { return ready ? "Intel e1000" : "none"; }

int hw_nic_init(u8 mac[6]) {
    int found = 0, fb = 0, fd = 0, ff = 0;
    for (int bus = 0; bus < 8 && !found; bus++)
        for (int dev = 0; dev < 32 && !found; dev++)
            for (int fn = 0; fn < 8 && !found; fn++) {
                u32 id = pci_read(bus, dev, fn, 0);
                if ((id & 0xFFFF) == 0xFFFF) { if (fn == 0) break; continue; }
                if ((id & 0xFFFF) == 0x8086)
                    for (unsigned i = 0; i < sizeof ids / sizeof ids[0]; i++)
                        if ((id >> 16) == ids[i]) { found = 1; fb = bus; fd = dev; ff = fn; }
                if (fn == 0 && !((pci_read(bus, dev, 0, 0x0C) >> 16) & 0x80)) break;   /* single-function device */
            }
    if (!found) return 0;
    u32 bar0 = pci_read(fb, fd, ff, 0x10);
    if (bar0 & 1) return 0;                                    /* I/O-space BAR: not supported */
    pci_write(fb, fd, ff, 0x04, pci_read(fb, fd, ff, 0x04) | 0x7);   /* I/O + memory + bus master */
    mmio = (volatile u32 *)(bar0 & ~0xFu);

    wr(R_IMC, 0xFFFFFFFFu);
    wr(R_CTRL, rd(R_CTRL) | (1u << 26));                       /* reset */
    wait_ms(20);
    wr(R_IMC, 0xFFFFFFFFu);
    wr(R_CTRL, (rd(R_CTRL) | (1u << 6)) & ~((1u << 3) | (1u << 31) | (1u << 30)));   /* set link up */

    u32 lo = rd(R_RAL0), hi = rd(R_RAH0);
    if ((lo | (hi & 0xFFFF)) == 0) {                           /* fall back to the EEPROM */
        for (int w = 0; w < 3; w++) {
            wr(R_EERD, 1u | ((u32)w << 8));
            u32 v = 0; for (int i = 0; i < 100000; i++) { v = rd(R_EERD); if (v & 0x12) break; }
            u16 word = (u16)(v >> 16);
            if (w == 0) lo = word; else if (w == 1) lo |= (u32)word << 16; else hi = word;
        }
    }
    mac[0] = (u8)lo; mac[1] = (u8)(lo >> 8); mac[2] = (u8)(lo >> 16); mac[3] = (u8)(lo >> 24);
    mac[4] = (u8)hi; mac[5] = (u8)(hi >> 8);
    wr(R_RAL0, lo); wr(R_RAH0, (hi & 0xFFFF) | (1u << 31));
    for (int i = 0; i < 128; i++) wr(R_MTA + i * 4, 0);

    for (int i = 0; i < NRX; i++) { rxr[i].addr_lo = (u32)(unsigned long)rxbuf[i]; rxr[i].addr_hi = 0; rxr[i].status = 0; }
    wr(R_RDBAL, (u32)(unsigned long)rxr); wr(R_RDBAH, 0); wr(R_RDLEN, NRX * 16);
    wr(R_RDH, 0); wr(R_RDT, NRX - 1); rx_cur = 0;
    wr(R_RCTL, (1u << 1) | (1u << 15) | (1u << 26));           /* enable, accept broadcast, strip CRC, 2 KiB buffers */

    k_memset(txr, 0, sizeof txr);
    wr(R_TDBAL, (u32)(unsigned long)txr); wr(R_TDBAH, 0); wr(R_TDLEN, NTX * 16);
    wr(R_TDH, 0); wr(R_TDT, 0); tx_tail = 0;
    wr(R_TIPG, 0x0060200A);
    wr(R_TCTL, (1u << 1) | (1u << 3) | (0x0Fu << 4) | (0x40u << 12));
    ready = 1;
    return 1;
}

int hw_nic_send(const u8 *f, int len) {
    if (!ready || len <= 0 || len > 1514) return 0;
    volatile TxD *d = &txr[tx_tail];
    for (int i = 0; i < 200000 && d->cmd && !(d->status & 1); i++) __asm__ volatile("pause");   /* wait for a free slot */
    k_memcpy(txbuf[tx_tail], f, (unsigned)len);
    d->addr_lo = (u32)(unsigned long)txbuf[tx_tail]; d->addr_hi = 0; d->length = (u16)len;
    d->cso = 0; d->css = 0; d->special = 0; d->status = 0;
    d->cmd = 0x0B;                                              /* EOP | IFCS | RS */
    tx_tail = (tx_tail + 1) % NTX;
    __asm__ volatile("" ::: "memory");
    wr(R_TDT, (u32)tx_tail);
    return 1;
}

int hw_nic_recv(u8 *buf, int max) {
    if (!ready) return 0;
    volatile RxD *d = &rxr[rx_cur];
    if (!(d->status & 1)) return 0;
    int len = d->length, ok = (d->status & 2) && d->errors == 0;
    if (len > max) len = max;
    if (ok) k_memcpy(buf, rxbuf[rx_cur], (unsigned)len);
    d->status = 0;
    wr(R_RDT, (u32)rx_cur);
    rx_cur = (rx_cur + 1) % NRX;
    return ok ? len : 0;
}
