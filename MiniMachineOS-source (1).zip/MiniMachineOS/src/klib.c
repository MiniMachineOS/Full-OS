#include "klib.h"

int k_strlen(const char *s) { int n = 0; while (s[n]) n++; return n; }
int k_strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (u8)*a - (u8)*b;
}
int k_strncmp(const char *a, const char *b, int n) {
    while (n > 0 && *a && *a == *b) { a++; b++; n--; }
    return n == 0 ? 0 : (u8)*a - (u8)*b;
}
static char lower(char c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
int k_stricmp_sub(const char *hay, const char *needle) {
    int nl = k_strlen(needle);
    if (nl == 0) return 1;
    for (; *hay; hay++) {
        int i = 0;
        while (i < nl && hay[i] && lower(hay[i]) == lower(needle[i])) i++;
        if (i == nl) return 1;
    }
    return 0;
}
int k_strcpy(char *dst, const char *src, int max) {
    int i = 0;
    if (max <= 0) return 0;
    while (src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = 0;
    return i;
}
int k_strcat(char *dst, const char *src, int max) {
    int n = k_strlen(dst);
    return n + k_strcpy(dst + n, src, max - n);
}
int k_atoi(const char *s) {
    int neg = 0, v = 0;
    while (*s == ' ') s++;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; }
    return neg ? -v : v;
}

/* tiny printf: %d %u %x %s %c %% with optional 0 flag and width */
int k_snprintf(char *out, int n, const char *fmt, ...) {
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int len = 0;
#define PUT(ch) do { if (len < n - 1) out[len] = (ch); len++; } while (0)
    for (; *fmt; fmt++) {
        if (*fmt != '%') { PUT(*fmt); continue; }
        fmt++;
        int zero = 0, width = 0;
        if (*fmt == '0') { zero = 1; fmt++; }
        while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        char tmp[16]; int tl = 0;
        if (*fmt == 'd' || *fmt == 'u' || *fmt == 'x') {
            u32 v; int neg = 0;
            if (*fmt == 'd') { int s = __builtin_va_arg(ap, int); if (s < 0) { neg = 1; v = (u32)(-s); } else v = (u32)s; }
            else v = __builtin_va_arg(ap, u32);
            u32 base = (*fmt == 'x') ? 16 : 10;
            if (v == 0) tmp[tl++] = '0';
            while (v) { u32 d = v % base; tmp[tl++] = d < 10 ? '0' + d : 'a' + d - 10; v /= base; }
            if (neg) tmp[tl++] = '-';
            for (int i = tl; i < width; i++) PUT(zero ? '0' : ' ');
            while (tl) PUT(tmp[--tl]);
        } else if (*fmt == 's') {
            const char *s = __builtin_va_arg(ap, const char *);
            if (!s) s = "(null)";
            int sl = k_strlen(s);
            for (int i = sl; i < width; i++) PUT(' ');
            while (*s) { PUT(*s); s++; }
        } else if (*fmt == 'c') {
            PUT((char)__builtin_va_arg(ap, int));
        } else if (*fmt == '%') {
            PUT('%');
        } else if (*fmt == 0) break;
    }
    if (n > 0) out[len < n ? len : n - 1] = 0;
    __builtin_va_end(ap);
    return len;
#undef PUT
}

static u32 rng = 2463534242u;
void k_srand(u32 s) { rng = s ? s : 2463534242u; }
u32 k_rand(void) { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }
u32 k_crc32(const void *data, int n) {
    const u8 *p = data; u32 c = 0xFFFFFFFFu;
    while (n-- > 0) { c ^= *p++; for (int i = 0; i < 8; i++) c = (c >> 1) ^ (0xEDB88320u & (u32)(-(int)(c & 1))); }
    return ~c;
}
