/* vfs.c - tiny in-memory filesystem used by the Files app, Terminal and Editor */
#include "vfs.h"
#include "klib.h"
#include "hw.h"

typedef struct { u8 used, dir; s16 parent; char name[VFS_NAME]; u32 off, size, cap; } Node;
static Node nodes[VFS_MAX];
static char pool[96 * 1024];
static u32 pool_top;
static char empty_str[1] = "";
int vfs_dirty; u32 vfs_dirty_ms;
static char home_user[24] = "user";
static void touch(void) { vfs_dirty = 1; vfs_dirty_ms = hw_ms(); }

int vfs_root(void) { return 0; }
int vfs_is_dir(int n) { return n >= 0 && nodes[n].used && nodes[n].dir; }
int vfs_parent(int n) { return nodes[n].parent < 0 ? 0 : nodes[n].parent; }
const char *vfs_name(int n) { return n == 0 ? "/" : nodes[n].name; }
int vfs_size(int n) { return (int)nodes[n].size; }

int vfs_find(int parent, const char *name) {
    for (int i = 1; i < VFS_MAX; i++)
        if (nodes[i].used && nodes[i].parent == parent && k_strcmp(nodes[i].name, name) == 0) return i;
    return -1;
}

int vfs_create(int parent, const char *name, int is_dir) {
    if (!vfs_is_dir(parent) || !name[0] || k_strlen(name) >= VFS_NAME) return -1;
    if (vfs_find(parent, name) >= 0) return -1;
    for (int i = 1; i < VFS_MAX; i++)
        if (!nodes[i].used) {
            k_memset(&nodes[i], 0, sizeof(Node));
            nodes[i].used = 1; nodes[i].dir = (u8)is_dir; nodes[i].parent = (s16)parent;
            k_strcpy(nodes[i].name, name, VFS_NAME);
            touch();
            return i;
        }
    return -1;
}

int vfs_write(int n, const char *data, int len) {
    if (n <= 0 || !nodes[n].used || nodes[n].dir || len < 0) return -1;
    if ((u32)len > nodes[n].cap || nodes[n].cap == 0) {
        u32 cap = (u32)len + 256;
        if (pool_top + cap + 1 > sizeof(pool)) return -1;
        nodes[n].off = pool_top; nodes[n].cap = cap;
        pool_top += cap + 1;
    }
    k_memcpy(pool + nodes[n].off, data, (unsigned)len);
    pool[nodes[n].off + (u32)len] = 0;
    nodes[n].size = (u32)len;
    touch();
    return 0;
}

const char *vfs_data(int n, int *len) {
    if (n <= 0 || !nodes[n].used || nodes[n].dir || nodes[n].cap == 0) { if (len) *len = 0; return empty_str; }
    if (len) *len = (int)nodes[n].size;
    return pool + nodes[n].off;
}

int vfs_remove(int n) {
    if (n <= 0 || !nodes[n].used) return -1;
    if (nodes[n].dir)
        for (int i = 1; i < VFS_MAX; i++)
            if (nodes[i].used && nodes[i].parent == n) return -1;
    nodes[n].used = 0;
    touch();
    return 0;
}

int vfs_resolve(int cwd, const char *path) {
    int cur = (path[0] == '/') ? 0 : cwd;
    char part[VFS_NAME];
    while (*path) {
        while (*path == '/') path++;
        if (!*path) break;
        int l = 0;
        while (*path && *path != '/') { if (l < VFS_NAME - 1) part[l++] = *path; path++; }
        part[l] = 0;
        if (k_strcmp(part, ".") == 0) continue;
        if (k_strcmp(part, "..") == 0) { cur = cur == 0 ? 0 : vfs_parent(cur); continue; }
        if (!vfs_is_dir(cur)) return -1;
        cur = vfs_find(cur, part);
        if (cur < 0) return -1;
    }
    return cur;
}

void vfs_path(int n, char *out, int max) {
    if (n == 0) { k_strcpy(out, "/", max); return; }
    int stack[16], d = 0;
    while (n > 0 && d < 16) { stack[d++] = n; n = nodes[n].parent; }
    out[0] = 0;
    while (d > 0) { k_strcat(out, "/", max); k_strcat(out, nodes[stack[--d]].name, max); }
}

static int cmp(int a, int b) {
    if (nodes[a].dir != nodes[b].dir) return nodes[a].dir ? -1 : 1;
    const char *x = nodes[a].name, *y = nodes[b].name;
    while (*x && *y) {
        char cx = (*x >= 'A' && *x <= 'Z') ? *x + 32 : *x, cy = (*y >= 'A' && *y <= 'Z') ? *y + 32 : *y;
        if (cx != cy) return cx - cy;
        x++; y++;
    }
    return (u8)*x - (u8)*y;
}

int vfs_list(int dir, int *out, int max) {
    int n = 0;
    for (int i = 1; i < VFS_MAX && n < max; i++)
        if (nodes[i].used && nodes[i].parent == dir) out[n++] = i;
    for (int i = 1; i < n; i++)                       /* insertion sort */
        for (int j = i; j > 0 && cmp(out[j - 1], out[j]) > 0; j--) { int t = out[j]; out[j] = out[j - 1]; out[j - 1] = t; }
    return n;
}

static int mkdir_(int parent, const char *name) { return vfs_create(parent, name, 1); }
static void mkfile(int parent, const char *name, const char *text) {
    int n = vfs_create(parent, name, 0);
    if (n > 0) vfs_write(n, text, k_strlen(text));
}

int vfs_home(void) {
    char p[48]; k_snprintf(p, sizeof p, "/home/%s", home_user);
    int n = vfs_resolve(0, p);
    return n < 0 ? 0 : n;
}
void vfs_set_user(const char *u) { k_strcpy(home_user, u, sizeof home_user); }

#define SNAP_VERSION 3
int vfs_snapshot(u8 *buf, int max) {
    int need = 16 + (int)sizeof(nodes) + (int)pool_top;
    if (need > max) return -1;
    u32 hdr[4] = { SNAP_VERSION, (u32)sizeof(Node), VFS_MAX, pool_top };
    k_memcpy(buf, hdr, 16); k_memcpy(buf + 16, nodes, sizeof(nodes)); k_memcpy(buf + 16 + sizeof(nodes), pool, pool_top);
    return need;
}
int vfs_restore(const u8 *buf, int len) {
    u32 hdr[4];
    if (len < 16) return -1;
    k_memcpy(hdr, buf, 16);
    if (hdr[0] != SNAP_VERSION || hdr[1] != sizeof(Node) || hdr[2] != VFS_MAX || hdr[3] > sizeof(pool)) return -1;
    if (len != 16 + (int)sizeof(nodes) + (int)hdr[3]) return -1;
    k_memcpy(nodes, buf + 16, sizeof(nodes)); k_memcpy(pool, buf + 16 + sizeof(nodes), hdr[3]); pool_top = hdr[3];
    if (!nodes[0].used || !nodes[0].dir) return -1;
    for (int i = 0; i < VFS_MAX; i++) if (nodes[i].used && nodes[i].dir == 0 && nodes[i].off + nodes[i].cap + 1 > pool_top) return -1;
    vfs_dirty = 0;
    return 0;
}

void vfs_init(const char *user) {
    vfs_set_user(user);
    k_memset(nodes, 0, sizeof(nodes));
    pool_top = 0;
    nodes[0].used = 1; nodes[0].dir = 1; nodes[0].parent = -1;
    int home = mkdir_(0, "home"), usr = mkdir_(home, user);
    int docs = mkdir_(usr, "Documents");
    mkdir_(usr, "Desktop"); mkdir_(usr, "Downloads"); mkdir_(usr, "Pictures");
    int etc = mkdir_(0, "etc"); mkdir_(0, "tmp");
    mkfile(usr, "welcome.txt",
        "Welcome to MiniMachineOS!\n\n"
        "This is a desktop environment running on a bare-metal x86 kernel.\n\n"
        "  - Double-click icons on the desktop to open apps\n"
        "  - Press the Menu button (or the Super key) to open the start menu\n"
        "  - Drag windows by their title bar, resize from the edges\n"
        "  - Ctrl+Alt+T opens a terminal, Alt+Tab switches windows\n"
        "  - The Browser (plain http:// only) works when a network card is found;\n"
        "    the globe icon next to the clock shows the connection status\n\n"
        "  - Open the App Store to add games and apps\n\n"
        "When MiniMachineOS runs from its disk image, your account, settings, installed\n"
        "apps and files are saved to the disk. From a CD or USB stick they are not.\n");
    mkfile(docs, "readme.txt",
        "MiniMachineOS Documents\n==============\n\n"
        "Try editing this file and pressing Ctrl+S to save it.\n"
        "Then open the Terminal and run:  cat Documents/readme.txt\n");
    mkfile(docs, "todo.txt",
        "TODO\n----\n[x] bootloader\n[x] graphics mode\n[x] desktop\n[x] disk driver\n[x] network\n");
    mkfile(etc, "os-release", "NAME=\"" "MiniMachineOS" "\"\nVERSION=\"0.2\"\nID=minimachineos\n");
    mkfile(etc, "hostname", "minimachine\n");
}
