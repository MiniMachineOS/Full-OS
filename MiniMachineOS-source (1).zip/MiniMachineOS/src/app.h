#ifndef APP_H
#define APP_H
#include "types.h"
#include "gfx.h"
#include "vfs.h"
struct HwTime_;

#define OS_NAME    "MiniMachineOS"
#define OS_VERSION "0.2"
#define OS_HOST    "minimachine"

/* ---- theme ---------------------------------------------------------- */
typedef struct {
    u32 panel, panel_hover, win_bg, win_alt, field, border, text, dim, hover;
    u32 title_act, title_inact, accent, accent_dk, accent_text;
    int dark;
} Theme;
extern Theme theme;
extern int cfg_dark, cfg_accent, cfg_wall;
#define N_ACCENTS 6
#define N_WALLS 5
extern const u32 accent_colors[N_ACCENTS];
extern const char *accent_names[N_ACCENTS];
extern const char *wall_names[N_WALLS];
void theme_apply(void);
void wallpaper_thumb(int idx, int x, int y, int w, int h);

/* ---- input ---------------------------------------------------------- */
#define KEY_BACKSPACE 8
#define KEY_TAB 9
#define KEY_ENTER 10
#define KEY_ESC 27
#define KEY_UP 0x101
#define KEY_DOWN 0x102
#define KEY_LEFT 0x103
#define KEY_RIGHT 0x104
#define KEY_HOME 0x105
#define KEY_END 0x106
#define KEY_PGUP 0x107
#define KEY_PGDN 0x108
#define KEY_DEL 0x109
#define KEY_LGUI 0x10A
#define KEY_F2 0x112
#define KEY_F4 0x114
#define KEY_F5 0x115
#define MOD_SHIFT 1
#define MOD_CTRL 2
#define MOD_ALT 4
enum { EV_MOVE, EV_DOWN, EV_UP, EV_RDOWN, EV_WHEEL };

/* ---- icons ---------------------------------------------------------- */
enum { ICON_FILES, ICON_TERM, ICON_EDIT, ICON_CALC, ICON_SETTINGS, ICON_ABOUT, ICON_FILE, ICON_LOGO, ICON_BROWSER,
       ICON_STORE, ICON_SNAKE, ICON_MINES, ICON_2048, ICON_TTT, ICON_PAINT, ICON_CLOCK };
void icon_draw(int kind, int x, int y, int s);

/* ---- app state ------------------------------------------------------ */
#define TERM_COLS 110
#define TERM_LINES 96
typedef struct {
    char lines[TERM_LINES][TERM_COLS]; u8 lcol[TERM_LINES]; u8 lsplit[TERM_LINES];
    int n;                       /* number of used lines */
    char in[160]; int ilen, icur;
    int scroll;                  /* lines scrolled up from bottom */
    int cwd;                     /* vfs node */
    char hist[8][160]; int nhist, hpos;
    int ping_mode; u32 ping_ip, ping_t; int ping_n; char ping_host[48];
} TermState;

#define ED_MAX 6000
typedef struct {
    char text[ED_MAX + 1]; int len, cur, top;
    char path[96]; int modified; int node;
    int hot, follow; char msg[48];
} EditState;

typedef struct { int dir, sel, hot; int scroll; char msg[48]; } FilesState;
typedef struct { char entry[16]; int elen; int acc; int op; int fresh; int hot; char expr[48]; int err; } CalcState;
typedef struct { int hot; } SettingsState;

typedef struct { int cat, scroll, hot; char msg[56]; } StoreState;
#define SN_W 24
#define SN_H 18
typedef struct { u8 bx[SN_W * SN_H + 2], by[SN_W * SN_H + 2]; int len, dir, ndir, fx, fy, score, alive, paused, started; u32 last; } SnakeState;
#define MN_W 14
#define MN_H 10
#define MN_MINES 20
typedef struct { u8 mine[MN_W * MN_H], st[MN_W * MN_H], num[MN_W * MN_H]; int placed, over, won, flags, opened, hit, hot, last_sec; u32 t0, tend; } MinesState;
typedef struct { int b[16]; int score, over, won; } G2048State;
typedef struct { int b[9]; int over, winner, hard, hot; } TttState;
typedef struct { int tab, hot, sw_run, last; u32 sw_start, sw_acc; } ClockState;
typedef struct { int hot; } PaintState;

typedef struct {
    char url[200]; int ulen, ucur, ufocus, usel;      /* address bar */
    char cur[200];                                     /* URL of the page being shown */
    char hist[12][200]; int hcount, hpos;
    int st, sock, redirects, hot, hover_link, dragging, layout_w, scroll, plain;
    char host[64]; int port; char path[200];
    u32 t0, tlast; char status[96];
} BrowserState;
typedef struct { int last_sec; } AboutState;

#define TB_H 34          /* window title bar height */
typedef struct Window {
    int used, app;
    int x, y, w, h;
    int rx, ry, rw, rh;  /* restore rectangle */
    int max, min;
    char title[48];
    union { TermState term; EditState edit; FilesState files; CalcState calc; SettingsState set; AboutState about; BrowserState br; StoreState store; SnakeState snake; MinesState mines; G2048State g2048; TttState ttt; ClockState clock; PaintState paint; } u;
} Window;

typedef struct {
    const char *name, *desc;
    int icon, defw, defh, minw, minh;
    void (*init)(Window *w, const char *arg);
    void (*draw)(Window *w, int x, int y, int cw, int ch);                    /* absolute client rect */
    void (*mouse)(Window *w, int x, int y, int ev, int clicks);               /* x,y relative to client */
    void (*key)(Window *w, int key, int mods);
    void (*tick)(Window *w, u32 ms);
    int single;                                                               /* only one window of this app */
    void (*reopen)(Window *w, const char *arg);                               /* single-instance window launched again */
    void (*close)(Window *w);
    int category;                                                             /* 0 built-in, 1 store app, 2 store game */
} AppDesc;
extern const AppDesc *apps[];     /* indexed by APP_* */
enum { APP_FILES, APP_BROWSER, APP_STORE, APP_TERM, APP_EDIT, APP_CALC, APP_SETTINGS, APP_ABOUT,
       APP_SNAKE, APP_MINES, APP_2048, APP_TTT, APP_PAINT, APP_CLOCK, APP_COUNT };
extern const AppDesc app_files, app_browser, app_store, app_term, app_edit, app_calc, app_settings, app_about,
                     app_snake, app_mines, app_2048, app_ttt, app_paint, app_clock;

/* ---- services provided by the shell to apps ------------------------- */
extern int g_mx, g_my;           /* mouse position */
extern int g_blink;              /* caret phase (0/1) */
Window *app_launch(int app, const char *arg);
void win_invalidate(Window *w);
void win_invalidate_rect(Window *w, int x, int y, int cw, int ch);   /* client-relative */
int  win_is_active(Window *w);
void gui_close_app(int app);
void gui_apps_changed(void);                  /* installed set changed: refresh start menu + desktop */
void gui_get_time(struct HwTime_ *t);
void win_close(Window *w);
void win_set_title(Window *w, const char *t);
void win_client(Window *w, int *x, int *y, int *cw, int *ch);
void gui_damage_all(void);
int  browser_busy(void);
const char *browser_status(void);
u32  gui_now(void);
void ui_button(int x, int y, int w, int h, const char *label, int hot, int accent);
void ui_field(int x, int y, int w, int h);
int  ui_inside(int mx, int my, int x, int y, int w, int h);
#endif
