/* app_paint.c - simple paint program (single window; 560x400 canvas of palette indices) */
#include "app.h"
#include "klib.h"

#define CW_ 560
#define CH_ 400
#define TOOLW 84
static u8 canvas[CW_ * CH_];
static int cur_color = 0, cur_size = 1, tool = 0, drawing, lastx, lasty, inited;
static const u32 pal[16] = { 0x000000, 0xFFFFFF, 0x7F7F7F, 0xC3C3C3, 0xE5484D, 0xF39C34, 0xF5D90A, 0x3FB950,
                             0x1FA2A6, 0x3584E4, 0x9B59B6, 0xFF7EB6, 0x8B5A2B, 0x7A1F24, 0x1E6B34, 0x1B2A6B };
static const int sizes[4] = { 0, 2, 5, 10 };      /* brush radius */

static void clear(void) { k_memset(canvas, 1, sizeof canvas); }
static void p_init(Window *w, const char *arg) { (void)w; (void)arg; if (!inited) { clear(); inited = 1; } drawing = 0; }

static void stamp(int cx, int cy, int r, u8 c) {
    for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++) {
        if (dx * dx + dy * dy > r * r + r) continue;
        int x = cx + dx, y = cy + dy;
        if (x >= 0 && y >= 0 && x < CW_ && y < CH_) canvas[y * CW_ + x] = c;
    }
}
static void stroke(int x0, int y0, int x1, int y1) {
    u8 c = tool == 1 ? 1 : (u8)cur_color; int r = tool == 1 ? sizes[cur_size] + 4 : sizes[cur_size];
    int dx = k_abs(x1 - x0), dy = k_abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy;
    for (;;) {
        stamp(x0, y0, r, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 < dx) { err += dx; y0 += sy; }
    }
}

/* toolbar ids: 0..15 colours, 20..23 sizes, 30 pencil, 31 eraser, 32 clear */
static int tb_hit(int x, int y) {
    for (int i = 0; i < 16; i++) if (ui_inside(x, y, 8 + (i % 2) * 36, 8 + (i / 2) * 36, 32, 32)) return i;
    for (int i = 0; i < 4; i++) if (ui_inside(x, y, 8 + (i % 2) * 36, 304 + (i / 2) * 36, 32, 32)) return 20 + i;
    if (ui_inside(x, y, 8, 380, 68, 30)) return 30;
    if (ui_inside(x, y, 8, 414, 68, 30)) return 31;
    if (ui_inside(x, y, 8, 448, 68, 30)) return 32;
    return -1;
}
static void p_mouse(Window *w, int x, int y, int ev, int clicks) {
    PaintState *p = &w->u.paint; (void)clicks;
    int cx = x - TOOLW - 4, cy = y - 8;
    if (ev == EV_MOVE) {
        if (drawing) {
            int px = k_clamp(cx, 0, CW_ - 1), py = k_clamp(cy, 0, CH_ - 1);
            stroke(lastx, lasty, px, py);
            int r = sizes[cur_size] + 6;
            win_invalidate_rect(w, TOOLW + 4 + k_min(lastx, px) - r, 8 + k_min(lasty, py) - r, k_abs(px - lastx) + 2 * r, k_abs(py - lasty) + 2 * r);
            lastx = px; lasty = py;
        } else { int h = tb_hit(x, y); if (h != p->hot) { p->hot = h; win_invalidate_rect(w, 0, 0, TOOLW, 500); } }
    } else if (ev == EV_UP) drawing = 0;
    else if (ev == EV_DOWN) {
        if (x < TOOLW) {
            int h = tb_hit(x, y);
            if (h >= 0 && h < 16) { cur_color = h; if (tool == 1) tool = 0; }
            else if (h >= 20 && h < 24) cur_size = h - 20;
            else if (h == 30) tool = 0; else if (h == 31) tool = 1;
            else if (h == 32) { clear(); win_invalidate(w); return; }
            win_invalidate_rect(w, 0, 0, TOOLW, 500);
        } else if (cx >= 0 && cy >= 0 && cx < CW_ && cy < CH_) {
            drawing = 1; lastx = cx; lasty = cy; stroke(cx, cy, cx, cy);
            int r = sizes[cur_size] + 6; win_invalidate_rect(w, TOOLW + 4 + cx - r, 8 + cy - r, 2 * r, 2 * r);
        }
    }
}

static void p_draw(Window *w, int x, int y, int cw, int ch) {
    PaintState *p = &w->u.paint;
    gfx_fill(x, y, cw, ch, theme.win_alt);
    gfx_fill(x + TOOLW - 1, y, 1, ch, theme.border);
    for (int i = 0; i < 16; i++) {
        int bx = x + 8 + (i % 2) * 36, by = y + 8 + (i / 2) * 36;
        if (cur_color == i && tool == 0) gfx_round(bx - 2, by - 2, 36, 36, 8, CORNER_ALL, theme.accent, 255);
        else if (p->hot == i) gfx_round(bx - 2, by - 2, 36, 36, 8, CORNER_ALL, theme.dim, 255);
        gfx_round(bx, by, 32, 32, 6, CORNER_ALL, pal[i], 255);
        gfx_rect_a(bx, by, 32, 32, 0x000000, 40);
    }
    gfx_text(&font_sm, x + 8, y + 284, "Brush", theme.dim);
    for (int i = 0; i < 4; i++) {
        int bx = x + 8 + (i % 2) * 36, by = y + 304 + (i / 2) * 36;
        gfx_round(bx, by, 32, 32, 6, CORNER_ALL, cur_size == i ? theme.accent : (p->hot == 20 + i ? theme.hover : theme.win_bg), 255);
        gfx_circle(bx + 16, by + 16, sizes[i] + 2, cur_size == i ? theme.accent_text : theme.text, 255);
    }
    ui_button(x + 8, y + 380, 68, 30, "Pencil", p->hot == 30, tool == 0);
    ui_button(x + 8, y + 414, 68, 30, "Eraser", p->hot == 31, tool == 1);
    ui_button(x + 8, y + 448, 68, 30, "Clear", p->hot == 32, 0);
    /* canvas */
    int ox = x + TOOLW + 4, oy = y + 8;
    gfx_rect(ox - 1, oy - 1, CW_ + 2, CH_ + 2, theme.border);
    Clip c = gfx_clip_get();
    int r0 = k_max(0, c.y0 - oy), r1 = k_min(CH_, c.y1 - oy);
    for (int j = r0; j < r1; j++) {
        const u8 *row = canvas + j * CW_;
        int i = 0;
        while (i < CW_) { int k = i; while (k < CW_ && row[k] == row[i]) k++; gfx_fill(ox + i, oy + j, k - i, 1, pal[row[i]]); i = k; }
    }
}

const AppDesc app_paint = {
    "Paint", "Draw and doodle", ICON_PAINT, TOOLW + 4 + CW_ + 20, 8 + CH_ + 16 + TB_H + 1 + 70, TOOLW + 4 + CW_ + 20, 8 + CH_ + 16 + TB_H + 1 + 70,
    p_init, p_draw, p_mouse, NULL, NULL, 1, NULL, NULL, 1
};
