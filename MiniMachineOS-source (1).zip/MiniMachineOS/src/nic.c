/* nic.c - PCI enumeration and NIC driver selection */
#include "nic.h"
#include "plat.h"
#include "hw.h"
#include "klib.h"

static PciInfo plist[64];
static int npci;
static const NicDrv *drivers[] = { &drv_e1000, &drv_rtl8168, &drv_rtl8139, &drv_virtio, &drv_pcnet, &drv_ne2k };
#define NDRV ((int)(sizeof drivers / sizeof drivers[0]))
static const NicDrv *active;
static char status[100], detail[120], active_label[80];

int pci_count(void) { return npci; }
const PciInfo *pci_get(int i) { return (i >= 0 && i < npci) ? &plist[i] : NULL; }

const char *pci_class_name(u32 cls) {
    switch (cls >> 8) {
    case 0x0100: return "SCSI storage"; case 0x0101: return "IDE storage"; case 0x0106: return "SATA storage"; case 0x0108: return "NVMe storage";
    case 0x0200: return "Ethernet"; case 0x0280: return "Network (Wi-Fi?)";
    case 0x0300: return "VGA display"; case 0x0380: return "Display";
    case 0x0401: return "Audio"; case 0x0403: return "Audio";
    case 0x0600: return "Host bridge"; case 0x0601: return "ISA bridge"; case 0x0604: return "PCI bridge"; case 0x0680: return "Bridge";
    case 0x0C03: return "USB controller"; case 0x0C05: return "SMBus";
    case 0x0D00: return "Wireless"; case 0x0780: return "Communication";
    }
    return "Other";
}

static void scan(void) {
    npci = 0;
    int maxbus = 0;
    for (int bus = 0; bus <= maxbus && bus < 256; bus++)
        for (int dev = 0; dev < 32; dev++) {
            u32 id0 = pci_read32(bus, dev, 0, 0);
            if ((id0 & 0xFFFF) == 0xFFFF) continue;
            int nf = ((pci_read32(bus, dev, 0, 0x0C) >> 16) & 0x80) ? 8 : 1;
            for (int fn = 0; fn < nf; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                if ((id & 0xFFFF) == 0xFFFF) continue;
                u32 cls = pci_read32(bus, dev, fn, 8) >> 8;
                int htype = (int)((pci_read32(bus, dev, fn, 0x0C) >> 16) & 0x7F);
                if ((cls >> 8) == 0x0604 && htype == 1) { int sec = (int)((pci_read32(bus, dev, fn, 0x18) >> 8) & 0xFF); if (sec > maxbus) maxbus = sec; }
                if (npci < 64) {
                    PciInfo *p = &plist[npci++];
                    p->bus = bus; p->dev = dev; p->fn = fn; p->vendor = (u16)id; p->device = (u16)(id >> 16); p->cls = cls;
                    for (int i = 0; i < 6; i++) p->bar[i] = htype == 0 ? pci_read32(bus, dev, fn, 0x10 + 4 * i) : 0;
                }
            }
        }
}

const char *nic_driver_for(u16 v, u16 d) {
    for (int i = 0; i < NDRV; i++) if (drivers[i]->match(v, d)) return drivers[i]->name;
    return NULL;
}
const char *nic_status_text(void) { return status; }
const char *nic_detail_text(void) { return detail; }
const char *hw_nic_name(void) { return active ? active_label : "none"; }

int hw_nic_init(u8 mac[6]) {
    active = NULL; status[0] = detail[0] = 0;
    scan();
    int eth = 0, wifi = 0, failed = 0;
    char unsup[40] = "", failname[40] = "";
    for (int i = 0; i < npci; i++) {
        PciInfo *p = &plist[i];
        if ((p->cls >> 16) != 0x02) continue;
        if (((p->cls >> 8) & 0xFF) == 0x80) { wifi++; continue; }
        eth++;
        int matched = 0;
        for (int k = 0; k < NDRV; k++) {
            if (!drivers[k]->match(p->vendor, p->device)) continue;
            matched = 1;
            pci_write32(p->bus, p->dev, p->fn, 4, pci_read32(p->bus, p->dev, p->fn, 4) | 7);   /* I/O + memory + bus master */
            if (drivers[k]->init(p, mac)) {
                active = drivers[k];
                k_snprintf(active_label, sizeof active_label, "%s [%04x:%04x]", drivers[k]->name, p->vendor, p->device);
                k_snprintf(status, sizeof status, "%s", active_label);
                return 1;
            }
            failed++; k_snprintf(failname, sizeof failname, "%s %04x:%04x", drivers[k]->name, p->vendor, p->device);
        }
        if (!matched && !unsup[0]) k_snprintf(unsup, sizeof unsup, "%04x:%04x", p->vendor, p->device);
    }
    if (failed) { k_snprintf(status, sizeof status, "Network card found but its driver failed to start"); k_snprintf(detail, sizeof detail, "Driver: %s", failname); }
    else if (eth) { k_snprintf(status, sizeof status, "Unsupported network card"); k_snprintf(detail, sizeof detail, "PCI id %s (vendor:device) has no driver yet", unsup); }
    else if (wifi) { k_snprintf(status, sizeof status, "Only a Wi-Fi adapter was found"); k_snprintf(detail, sizeof detail, "Wi-Fi is not supported; use a wired adapter"); }
    else { k_snprintf(status, sizeof status, "No network adapter found"); }
    return 0;
}
int hw_nic_send(const u8 *f, int len) { return active ? active->send(f, len) : 0; }
int hw_nic_recv(u8 *b, int max) { return active ? active->recv(b, max) : 0; }
