#ifndef GUI_H
#define GUI_H
#include "types.h"
void gui_init(u32 *scene, u32 *screen, int w, int h, int spitch);
void gui_mouse(int x, int y, int btn, int wheel);   /* absolute position, bit0 = left, bit1 = right */
void gui_key(int key, int mods);
void gui_tick(u32 ms);
void gui_render(void);
void gui_shutdown(void);
void gui_lock(void);
int  gui_test_window(int app, int *x, int *y, int *w, int *h);
void gui_autologin(const char *user, const char *pass);   /* test helper */
void gui_restart(void);
int  gui_dow(int y, int m, int d);                  /* 0 = Sunday */
#endif
