/* app_about.c - system information */
#include "app.h"
#include "klib.h"
#include "hw.h"
#include "account.h"

static void about_init(Window *w, const char *arg) { (void)arg; w->u.about.last_sec = -1; }
static void about_tick(Window *w, u32 ms) {
    int s = (int)(ms / 1000);
    if (s != w->u.about.last_sec) { w->u.about.last_sec = s; win_invalidate(w); }
}
static void row(int x, int y, int labw, const char *label, const char *val) {
    gfx_text(&font_ui, x, y, label, theme.dim);
    gfx_text_fit(&font_ui, x + labw, y, 360, val, theme.text);
}
static void about_draw(Window *w, int x, int y, int cw, int ch) {
    (void)w; (void)cw;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    icon_draw(ICON_LOGO, x + 36, y + 40, 96);
    int tx = x + 168;
    gfx_text(&font_big, tx, y + 36, OS_NAME, theme.text);
    gfx_text(&font_ui, tx, y + 78, "Version " OS_VERSION, theme.dim);
    gfx_fill(tx, y + 112, cw - 168 - 32, 1, theme.border);
    char b[96], cpu[64];
    hw_cpu_brand(cpu, sizeof cpu);
    int ry = y + 130, lh = 30;
    row(tx, ry, 110, "User", acct_name()); ry += lh;
    row(tx, ry, 110, "Processor", cpu); ry += lh;
    u32 kb = hw_mem_kb();
    if (kb) k_snprintf(b, sizeof b, "%d MB", (int)(kb / 1024)); else k_snprintf(b, sizeof b, "Not detected");
    row(tx, ry, 110, "Memory", b); ry += lh;
    k_snprintf(b, sizeof b, "%d x %d, 32-bit colour", gfx_w, gfx_h);
    row(tx, ry, 110, "Display", b); ry += lh;
    row(tx, ry, 110, "Kernel", "x86, 32-bit protected mode"); ry += lh;
    u32 s = gui_now() / 1000;
    k_snprintf(b, sizeof b, "%02d:%02d:%02d", (int)(s / 3600), (int)(s / 60 % 60), (int)(s % 60));
    row(tx, ry, 110, "Uptime", b);
}
const AppDesc app_about = {
    "System", "About this computer", ICON_ABOUT, 620, 410, 520, 380,
    about_init, about_draw, NULL, NULL, about_tick
};
