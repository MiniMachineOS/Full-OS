/* app_files.c - file manager over the in-memory filesystem */
#include "app.h"
#include "klib.h"
#include "account.h"

#define SB_W 168
#define TOOL_H 48
#define STAT_H 26
#define CELL_W 104
#define CELL_H 96

static const struct { const char *name, *path; } places[] = {
    { "Home", "" }, { "Documents", "Documents" }, { "Downloads", "Downloads" },
    { "Desktop", "Desktop" }, { "Pictures", "Pictures" }, { "File System", "/" },
};
#define N_PLACES 6

static void set_dir(Window *w, int dir) {
    FilesState *f = &w->u.files;
    f->dir = dir; f->sel = -1; f->scroll = 0; f->msg[0] = 0;
    char t[48]; k_snprintf(t, sizeof t, "%s - Files", vfs_name(dir));
    win_set_title(w, t);
    win_invalidate(w);
}
static void files_init(Window *w, const char *arg) {
    (void)arg;
    w->u.files.hot = -1;
    set_dir(w, vfs_home());
}

static int cols_of(int cw) { return k_max(1, (cw - SB_W - 16) / CELL_W); }
static void cell_pos(int i, int cols, int scroll, int *x, int *y) {
    *x = SB_W + 8 + (i % cols) * CELL_W;
    *y = TOOL_H + 8 + (i / cols - scroll) * CELL_H;
}

/* toolbar buttons: 0 up, 1 new folder, 2 new file, 3 delete */
static void tool_rect(int b, int cw, int *x, int *y, int *w, int *h) {
    *y = 8; *h = 32;
    if (b == 0) { *x = SB_W + 8; *w = 34; return; }
    int bw[3] = { 98, 80, 66 };
    int rx = cw - 8;
    for (int k = 3; k >= b; k--) { rx -= bw[k - 1] + (k < 3 ? 6 : 0); }
    *x = rx; *w = bw[b - 1];
}

static int hit(Window *w, int x, int y) {          /* returns hot id: 0..N items, 1000+ tools, 2000+ places */
    FilesState *f = &w->u.files;
    int cw = w->w - 2, ch = w->h - TB_H - 1;
    if (x < 0 || y < 0) return -1;
    if (x < SB_W) {
        for (int i = 0; i < N_PLACES; i++) if (ui_inside(x, y, 8, 12 + i * 36, SB_W - 16, 32)) return 2000 + i;
        return -1;
    }
    if (y < TOOL_H) {
        for (int b = 0; b < 4; b++) { int bx, by, bw, bh; tool_rect(b, cw, &bx, &by, &bw, &bh); if (ui_inside(x, y, bx, by, bw, bh)) return 1000 + b; }
        return -1;
    }
    if (y >= ch - STAT_H) return -1;
    int items[VFS_MAX]; int n = vfs_list(f->dir, items, VFS_MAX), cols = cols_of(cw);
    for (int i = 0; i < n; i++) {
        int cx, cy; cell_pos(i, cols, f->scroll, &cx, &cy);
        if (ui_inside(x, y, cx, cy, CELL_W - 4, CELL_H - 4)) return i;
    }
    return -1;
}

static void new_item(Window *w, int dir) {
    FilesState *f = &w->u.files;
    char name[VFS_NAME];
    for (int i = 1; i < 100; i++) {
        if (dir) { if (i == 1) k_snprintf(name, sizeof name, "New Folder"); else k_snprintf(name, sizeof name, "New Folder %d", i); }
        else { if (i == 1) k_snprintf(name, sizeof name, "New File.txt"); else k_snprintf(name, sizeof name, "New File %d.txt", i); }
        if (vfs_find(f->dir, name) < 0) break;
    }
    int n = vfs_create(f->dir, name, dir);
    if (n < 0) { k_strcpy(f->msg, "Could not create item", sizeof f->msg); return; }
    int items[VFS_MAX], cnt = vfs_list(f->dir, items, VFS_MAX);
    for (int i = 0; i < cnt; i++) if (items[i] == n) f->sel = i;
    f->msg[0] = 0;
}

static void delete_sel(Window *w) {
    FilesState *f = &w->u.files;
    int items[VFS_MAX], n = vfs_list(f->dir, items, VFS_MAX);
    if (f->sel < 0 || f->sel >= n) return;
    if (vfs_remove(items[f->sel]) < 0) k_strcpy(f->msg, "Folder is not empty", sizeof f->msg);
    else { f->sel = -1; f->msg[0] = 0; }
}

static void open_item(Window *w, int node) {
    if (vfs_is_dir(node)) set_dir(w, node);
    else { char p[96]; vfs_path(node, p, sizeof p); app_launch(APP_EDIT, p); }
}

static void files_mouse(Window *w, int x, int y, int ev, int clicks) {
    FilesState *f = &w->u.files;
    if (ev == EV_MOVE) { int h = hit(w, x, y); if (h != f->hot) { f->hot = h; win_invalidate(w); } return; }
    if (ev == EV_WHEEL) { f->scroll = k_max(0, f->scroll + clicks); win_invalidate(w); return; }
    if (ev != EV_DOWN) return;
    int h = hit(w, x, y);
    if (h >= 2000) { int d = vfs_resolve(vfs_home(), places[h - 2000].path); if (d >= 0) set_dir(w, d); return; }
    if (h >= 1000) {
        int b = h - 1000;
        if (b == 0) { if (f->dir != 0) set_dir(w, vfs_parent(f->dir)); }
        else if (b == 1) new_item(w, 1); else if (b == 2) new_item(w, 0); else delete_sel(w);
        win_invalidate(w); return;
    }
    int items[VFS_MAX], n = vfs_list(f->dir, items, VFS_MAX);
    if (h >= 0 && h < n) {
        f->sel = h; f->msg[0] = 0;
        if (clicks >= 2) { open_item(w, items[h]); return; }
    } else f->sel = -1;
    win_invalidate(w);
}

static void files_key(Window *w, int key, int mods) {
    FilesState *f = &w->u.files;
    int items[VFS_MAX], n = vfs_list(f->dir, items, VFS_MAX), cols = cols_of(w->w - 2);
    if (key == KEY_DEL) delete_sel(w);
    else if (key == KEY_ENTER) { if (f->sel >= 0 && f->sel < n) open_item(w, items[f->sel]); return; }
    else if (key == KEY_BACKSPACE || (key == KEY_LEFT && (mods & MOD_ALT))) { if (f->dir != 0) set_dir(w, vfs_parent(f->dir)); return; }
    else if (key == KEY_RIGHT) f->sel = k_min(n - 1, f->sel + 1);
    else if (key == KEY_LEFT) f->sel = k_max(0, f->sel - 1);
    else if (key == KEY_DOWN) f->sel = k_min(n - 1, f->sel < 0 ? 0 : f->sel + cols);
    else if (key == KEY_UP) f->sel = k_max(0, f->sel - cols);
    else return;
    win_invalidate(w);
}

static void files_draw(Window *w, int x, int y, int cw, int ch) {
    FilesState *f = &w->u.files;
    /* sidebar */
    gfx_fill(x, y, SB_W, ch, theme.win_alt);
    gfx_fill(x + SB_W - 1, y, 1, ch, theme.border);
    for (int i = 0; i < N_PLACES; i++) {
        int by = y + 12 + i * 36;
        int d = vfs_resolve(vfs_home(), places[i].path);
        int cur = (d == f->dir);
        if (cur) gfx_round(x + 8, by, SB_W - 16, 32, 6, CORNER_ALL, theme.accent, 255);
        else if (f->hot == 2000 + i) gfx_round(x + 8, by, SB_W - 16, 32, 6, CORNER_ALL, theme.hover, 255);
        icon_draw(ICON_FILES, x + 16, by + 5, 22);
        gfx_text(&font_ui, x + 46, by + (32 - font_ui.height) / 2, places[i].name, cur ? theme.accent_text : theme.text);
    }
    /* toolbar */
    gfx_fill(x + SB_W, y, cw - SB_W, TOOL_H, theme.win_bg);
    gfx_fill(x + SB_W, y + TOOL_H - 1, cw - SB_W, 1, theme.border);
    { int bx, by, bw, bh; tool_rect(0, cw, &bx, &by, &bw, &bh);
      ui_button(x + bx, y + by, bw, bh, "", f->hot == 1000, 0);
      int cx = x + bx + bw / 2, cy = y + by + bh / 2;
      u32 c = f->dir == 0 ? theme.dim : theme.text;
      gfx_line(cx, cy - 6, cx, cy + 6, 28, c, 255);
      gfx_line(cx - 5, cy - 1, cx, cy - 6, 28, c, 255);
      gfx_line(cx + 5, cy - 1, cx, cy - 6, 28, c, 255);
      int px = bx + bw + 8, pw; { int ax, ay, aw, ah; tool_rect(1, cw, &ax, &ay, &aw, &ah); pw = ax - 8 - px; }
      ui_field(x + px, y + 8, pw, 32);
      char p[96]; vfs_path(f->dir, p, sizeof p);
      gfx_text_fit(&font_ui, x + px + 10, y + 8 + (32 - font_ui.height) / 2, pw - 20, p, theme.text); }
    { static const char *lbl[3] = { "New Folder", "New File", "Delete" };
      for (int b = 1; b < 4; b++) { int bx, by, bw, bh; tool_rect(b, cw, &bx, &by, &bw, &bh);
        ui_button(x + bx, y + by, bw, bh, lbl[b - 1], f->hot == 1000 + b, 0); } }
    /* items */
    int items[VFS_MAX]; int n = vfs_list(f->dir, items, VFS_MAX), cols = cols_of(cw);
    int vis_rows = k_max(1, (ch - TOOL_H - STAT_H - 8) / CELL_H);
    int rows = (n + cols - 1) / cols;
    f->scroll = k_clamp(f->scroll, 0, k_max(0, rows - vis_rows));
    Clip old = gfx_clip_push(x + SB_W, y + TOOL_H, cw - SB_W, ch - TOOL_H - STAT_H);
    gfx_fill(x + SB_W, y + TOOL_H, cw - SB_W, ch - TOOL_H - STAT_H, theme.win_bg);
    for (int i = 0; i < n; i++) {
        int cx, cy; cell_pos(i, cols, f->scroll, &cx, &cy); cx += x; cy += y;
        if (cy + CELL_H < y + TOOL_H || cy > y + ch) continue;
        if (i == f->sel) gfx_round(cx, cy, CELL_W - 4, CELL_H - 4, 8, CORNER_ALL, theme.accent, 70);
        else if (f->hot == i) gfx_round(cx, cy, CELL_W - 4, CELL_H - 4, 8, CORNER_ALL, theme.hover, 255);
        icon_draw(vfs_is_dir(items[i]) ? ICON_FILES : ICON_FILE, cx + (CELL_W - 4 - 44) / 2, cy + 8, 44);
        const char *nm = vfs_name(items[i]);
        int tw = k_min(gfx_text_w(&font_ui, nm), CELL_W - 12);
        Clip c2 = gfx_clip_push(cx + 2, cy, CELL_W - 8, CELL_H);
        gfx_text_fit(&font_ui, cx + (CELL_W - 4 - tw) / 2, cy + 58, CELL_W - 12, nm, theme.text);
        gfx_clip_set(c2);
    }
    if (n == 0) gfx_text_center(&font_ui, x + SB_W, y + TOOL_H, cw - SB_W, 80, "This folder is empty", theme.dim);
    gfx_clip_set(old);
    /* status */
    int sy = y + ch - STAT_H;
    gfx_fill(x + SB_W, sy, cw - SB_W, STAT_H, theme.win_alt);
    gfx_fill(x + SB_W, sy, cw - SB_W, 1, theme.border);
    char b[64]; k_snprintf(b, sizeof b, "%d item%s", n, n == 1 ? "" : "s");
    gfx_text(&font_sm, x + SB_W + 12, sy + (STAT_H - font_sm.height) / 2, b, theme.dim);
    if (f->msg[0]) gfx_text_right(&font_sm, x + cw - 12, sy + (STAT_H - font_sm.height) / 2, f->msg, 0xE5484D);
}

const AppDesc app_files = {
    "Files", "Browse files and folders", ICON_FILES, 780, 500, 620, 300,
    files_init, files_draw, files_mouse, files_key, NULL
};
