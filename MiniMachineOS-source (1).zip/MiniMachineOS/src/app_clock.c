/* app_clock.c - analog/digital clock and a stopwatch */
#include "app.h"
#include "klib.h"
#include "hw.h"

static const int S15[16] = { 0, 105, 208, 309, 407, 500, 588, 669, 743, 809, 866, 914, 951, 978, 995, 1000 };
static int sin60(int i) {                            /* sin(i * 6 degrees) * 1000, i any integer */
    i %= 60; if (i < 0) i += 60;
    if (i <= 15) return S15[i];
    if (i <= 30) return S15[30 - i];
    if (i <= 45) return -S15[i - 30];
    return -S15[60 - i];
}
static int cos60(int i) { return sin60(i + 15); }

static void c_init(Window *w, const char *arg) { (void)arg; w->u.clock.hot = -1; w->u.clock.last = -1; }

static void c_tick(Window *w, u32 ms) {
    ClockState *c = &w->u.clock;
    if (c->tab == 1 && c->sw_run) { int f = (int)(ms / 50); if (f != c->last) { c->last = f; win_invalidate_rect(w, 0, 60, w->w - 2, 120); } }
    else if (c->tab == 0) { int f = (int)(ms / 1000); if (f != c->last) { c->last = f; win_invalidate(w); } }
}
static int hit(Window *w, int x, int y) {
    int cw = w->w - 2;
    if (ui_inside(x, y, cw / 2 - 130, 12, 124, 32)) return 100;
    if (ui_inside(x, y, cw / 2 + 6, 12, 124, 32)) return 101;
    if (w->u.clock.tab == 1) {
        if (ui_inside(x, y, cw / 2 - 130, 230, 124, 40)) return 200;
        if (ui_inside(x, y, cw / 2 + 6, 230, 124, 40)) return 201;
    }
    return -1;
}
static void c_mouse(Window *w, int x, int y, int ev, int clicks) {
    ClockState *c = &w->u.clock; (void)clicks;
    int h = hit(w, x, y);
    if (ev == EV_MOVE) { if (h != c->hot) { c->hot = h; win_invalidate(w); } return; }
    if (ev != EV_DOWN) return;
    if (h == 100) c->tab = 0; else if (h == 101) c->tab = 1;
    else if (h == 200) {
        if (c->sw_run) { c->sw_acc += gui_now() - c->sw_start; c->sw_run = 0; } else { c->sw_start = gui_now(); c->sw_run = 1; }
    } else if (h == 201) { c->sw_acc = 0; c->sw_run = 0; }
    else return;
    c->last = -1; win_invalidate(w);
}
static void c_key(Window *w, int key, int mods) {
    ClockState *c = &w->u.clock; (void)mods;
    if (key == ' ' && c->tab == 1) { if (c->sw_run) { c->sw_acc += gui_now() - c->sw_start; c->sw_run = 0; } else { c->sw_start = gui_now(); c->sw_run = 1; } win_invalidate(w); }
}

static const char *dn[7] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
static const char *mn[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

static void c_draw(Window *w, int x, int y, int cw, int ch) {
    ClockState *c = &w->u.clock;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    ui_button(x + cw / 2 - 130, y + 12, 124, 32, "Clock", c->hot == 100, c->tab == 0);
    ui_button(x + cw / 2 + 6, y + 12, 124, 32, "Stopwatch", c->hot == 101, c->tab == 1);
    char b[64];
    if (c->tab == 0) {
        HwTime t; gui_get_time(&t);
        int R = k_min(130, (k_min(cw, ch - 140) - 40) / 2), cx = x + cw / 2, cy = y + 64 + R;
        gfx_circle(cx, cy, R + 6, theme.border, 255); gfx_circle(cx, cy, R + 4, theme.field, 255);
        for (int i = 0; i < 60; i++) {
            int big = (i % 5 == 0), r0 = R - (big ? 14 : 7), r1 = R - 2;
            gfx_line(cx + r0 * sin60(i) / 1000, cy - r0 * cos60(i) / 1000, cx + r1 * sin60(i) / 1000, cy - r1 * cos60(i) / 1000, big ? 40 : 20, big ? theme.text : theme.dim, 255);
        }
        int hi = (t.hour % 12) * 5 + t.min / 12;
        int hl = R * 5 / 10, ml = R * 75 / 100, sl = R * 85 / 100;
        gfx_line(cx, cy, cx + hl * sin60(hi) / 1000, cy - hl * cos60(hi) / 1000, 90, theme.text, 255);
        gfx_line(cx, cy, cx + ml * sin60(t.min) / 1000, cy - ml * cos60(t.min) / 1000, 60, theme.text, 255);
        gfx_line(cx - 18 * sin60(t.sec) / 1000, cy + 18 * cos60(t.sec) / 1000, cx + sl * sin60(t.sec) / 1000, cy - sl * cos60(t.sec) / 1000, 28, theme.accent, 255);
        gfx_circle(cx, cy, 5, theme.accent, 255);
        k_snprintf(b, sizeof b, "%02d:%02d:%02d", t.hour, t.min, t.sec);
        gfx_text_center(&font_big, x, cy + R + 16, cw, 40, b, theme.text);
        k_snprintf(b, sizeof b, "%s, %d %s %d", dn[t.wday % 7], t.day, mn[(t.mon + 11) % 12], t.year);
        gfx_text_center(&font_ui, x, cy + R + 58, cw, 22, b, theme.dim);
    } else {
        u32 el = c->sw_acc + (c->sw_run ? gui_now() - c->sw_start : 0);
        int cs = (int)(el / 10 % 100), s = (int)(el / 1000 % 60), m = (int)(el / 60000);
        k_snprintf(b, sizeof b, "%02d:%02d.%02d", m, s, cs);
        gfx_round(x + cw / 2 - 140, y + 70, 280, 110, 14, CORNER_ALL, theme.field, 255);
        gfx_text_center(&font_big, x + cw / 2 - 140, y + 70, 280, 110, b, theme.text);
        ui_button(x + cw / 2 - 130, y + 230, 124, 40, c->sw_run ? "Stop" : "Start", c->hot == 200, !c->sw_run);
        ui_button(x + cw / 2 + 6, y + 230, 124, 40, "Reset", c->hot == 201, 0);
        gfx_text_center(&font_sm, x, y + 286, cw, 20, "Space starts and stops", theme.dim);
    }
}

const AppDesc app_clock = {
    "Clock", "Clock and stopwatch", ICON_CLOCK, 420, 470, 380, 440,
    c_init, c_draw, c_mouse, c_key, c_tick, 0, NULL, NULL, 1
};
