/* nic_rtl8168.c - Realtek RTL8168/8111 and RTL8169/8110 gigabit (the NIC on most desktop motherboards),
   plus RTL8101/8102/8136 fast-ethernet. Descriptor-ring DMA, polled.
   EXPERIMENTAL: written from the register documentation and the Linux r8169 sequence; chip revisions differ. */
#include "nic.h"
#include "plat.h"
#include "klib.h"

typedef struct { u32 opts1, opts2, addr_lo, addr_hi; } Desc;
#define NRX 16
#define NTX 8
#define OWN (1u << 31)
#define EOR (1u << 30)
#define FS (1u << 29)
#define LS (1u << 28)
static Desc rxr[NRX] __attribute__((aligned(256)));
static Desc txr[NTX] __attribute__((aligned(256)));
static u8 rxb[NRX][2048] __attribute__((aligned(16)));
static u8 txb[NTX][2048] __attribute__((aligned(16)));
static u32 base; static int use_mmio, rx_cur, tx_cur, ready;

static u8 r8(int o) { return use_mmio ? mm_in8(base + (u32)o) : io_in8((u16)(base + (u32)o)); }

static u32 r32(int o) { return use_mmio ? mm_in32(base + (u32)o) : io_in32((u16)(base + (u32)o)); }
static void w8(int o, u8 v) { if (use_mmio) mm_out8(base + (u32)o, v); else io_out8((u16)(base + (u32)o), v); }
static void w16(int o, u16 v) { if (use_mmio) mm_out16(base + (u32)o, v); else io_out16((u16)(base + (u32)o), v); }
static void w32(int o, u32 v) { if (use_mmio) mm_out32(base + (u32)o, v); else io_out32((u16)(base + (u32)o), v); }

static int match(u16 v, u16 d) {
    if (v == 0x10EC) return d == 0x8168 || d == 0x8169 || d == 0x8167 || d == 0x8136 || d == 0x8161 || d == 0x8162 || d == 0x8101 || d == 0x8100;
    if (v == 0x1186) return d == 0x4300;                              /* D-Link DGE-528T (RTL8169) */
    return 0;
}

static void phy_write(int reg, u16 val) {
    w32(0x60, 0x80000000u | ((u32)reg << 16) | val);
    for (int i = 0; i < 200; i++) { if (!(r32(0x60) & 0x80000000u)) break; delay_ms(1); }
}

static int init(const PciInfo *p, u8 mac[6]) {
    use_mmio = 0; base = 0;
    for (int i = 0; i < 6 && !base; i++) {                            /* prefer a 32-bit memory BAR, else the I/O BAR */
        u32 b = p->bar[i];
        if (!(b & 1) && (b & ~0xFu) && ((b >> 1) & 3) == 0) { base = b & ~0xFu; use_mmio = 1; }
        else if (!(b & 1) && (b & ~0xFu) && ((b >> 1) & 3) == 2) { if (i + 1 < 6 && p->bar[i + 1] == 0) { base = b & ~0xFu; use_mmio = 1; } i++; }
    }
    if (!base) for (int i = 0; i < 6; i++) if (p->bar[i] & 1) { base = p->bar[i] & ~3u; break; }
    if (!base) return 0;

    w8(0x37, 0x10);                                                   /* ChipCmd: reset */
    int ok = 0; for (int i = 0; i < 100; i++) { if (!(r8(0x37) & 0x10)) { ok = 1; break; } delay_ms(1); }
    if (!ok) return 0;
    for (int i = 0; i < 6; i++) mac[i] = r8(i);
    if ((mac[0] | mac[1] | mac[2] | mac[3] | mac[4] | mac[5]) == 0) return 0;

    k_memset(rxr, 0, sizeof rxr); k_memset(txr, 0, sizeof txr);
    for (int i = 0; i < NRX; i++) { rxr[i].addr_lo = dma_addr(rxb[i]); rxr[i].opts1 = OWN | (i == NRX - 1 ? EOR : 0) | 2048; }
    for (int i = 0; i < NTX; i++) { txr[i].addr_lo = dma_addr(txb[i]); txr[i].opts1 = (i == NTX - 1 ? EOR : 0); }
    BARRIER();

    w8(0x50, 0xC0);                                                   /* unlock config registers */
    w8(0x37, 0x0C);                                                   /* RE | TE */
    w16(0xDA, 2047);                                                  /* max receive size */
    w8(0xEC, 0x3B);                                                   /* max transmit packet size */
    w32(0x20, dma_addr(txr)); w32(0x24, 0);                           /* TNPDS */
    w32(0xE4, dma_addr(rxr)); w32(0xE8, 0);                           /* RDSAR */
    w8(0x50, 0x00);                                                   /* lock */
    w32(0x40, 0x03000700);                                            /* TxConfig: unlimited DMA burst, normal IFG */
    w32(0x44, 0x0000E70E);                                            /* RxConfig: AB | AM | APM, no FIFO threshold, unlimited burst */
    w16(0x3C, 0);                                                     /* no interrupts */
    w16(0x3E, 0xFFFF);
    phy_write(0, 0x1200);                                             /* BMCR: power up, auto-negotiate, restart */
    rx_cur = tx_cur = 0; ready = 1;
    return 1;
}

static int send(const u8 *f, int len) {
    if (!ready || len <= 0 || len > 1514) return 0;
    Desc *d = &txr[tx_cur];
    for (int i = 0; i < 200000 && (d->opts1 & OWN); i++) __asm__ volatile("pause");
    if (d->opts1 & OWN) return 0;
    k_memcpy(txb[tx_cur], f, (unsigned)len);
    if (len < 60) { k_memset(txb[tx_cur] + len, 0, (unsigned)(60 - len)); len = 60; }
    d->addr_lo = dma_addr(txb[tx_cur]); d->opts2 = 0;
    BARRIER();
    d->opts1 = OWN | FS | LS | (tx_cur == NTX - 1 ? EOR : 0) | (u32)len;
    BARRIER();
    w8(0x38, 0x40);                                                   /* TxPoll: normal priority queue */
    tx_cur = (tx_cur + 1) % NTX;
    return 1;
}

static int recv(u8 *buf, int max) {
    if (!ready) return 0;
    Desc *d = &rxr[rx_cur];
    if (d->opts1 & OWN) return 0;
    u32 o = d->opts1;
    int len = (int)(o & 0x3FFF), n = 0;
    if (!(o & (1u << 21)) && (o & FS) && (o & LS) && len > 4) {       /* no error, single-buffer frame, CRC included */
        n = len - 4; if (n > max) n = max;
        k_memcpy(buf, rxb[rx_cur], (unsigned)n);
    }
    d->opts2 = 0; d->addr_lo = dma_addr(rxb[rx_cur]);
    BARRIER();
    d->opts1 = OWN | (rx_cur == NRX - 1 ? EOR : 0) | 2048;
    rx_cur = (rx_cur + 1) % NRX;
    return n;
}

const NicDrv drv_rtl8168 = { "Realtek RTL8168/8111 (experimental)", match, init, send, recv };
