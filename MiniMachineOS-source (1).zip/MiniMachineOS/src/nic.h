#ifndef NIC_H
#define NIC_H
#include "types.h"
typedef struct { int bus, dev, fn; u16 vendor, device; u32 cls; u32 bar[6]; } PciInfo;   /* cls = class<<16 | subclass<<8 | prog-if */
typedef struct NicDrv {
    const char *name;
    int (*match)(u16 vendor, u16 device);
    int (*init)(const PciInfo *p, u8 mac[6]);          /* 1 on success; must never hang */
    int (*send)(const u8 *frame, int len);
    int (*recv)(u8 *buf, int max);
} NicDrv;
extern const NicDrv drv_e1000, drv_rtl8139, drv_rtl8168, drv_virtio, drv_pcnet, drv_ne2k;

int  pci_count(void);
const PciInfo *pci_get(int i);
const char *pci_class_name(u32 cls);
const char *nic_driver_for(u16 vendor, u16 device);    /* driver name or NULL */
const char *nic_status_text(void);                     /* one line for the UI */
const char *nic_detail_text(void);                     /* extra hint (unsupported chip id etc.) */
#endif
