/* net.c - Ethernet/ARP, IPv4, ICMP, UDP, DHCP, DNS and a small TCP client. Polled, no interrupts. */
#include "net.h"
#include "hw.h"
#include "klib.h"

/* ------------------------------------------------------------------ helpers */
static inline u16 rd16(const u8 *p) { return (u16)((p[0] << 8) | p[1]); }
static inline u32 rd32(const u8 *p) { return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3]; }
static inline void wr16(u8 *p, u16 v) { p[0] = (u8)(v >> 8); p[1] = (u8)v; }
static inline void wr32(u8 *p, u32 v) { p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16); p[2] = (u8)(v >> 8); p[3] = (u8)v; }

static u16 csum(const u8 *d, int n, u32 sum) {
    while (n > 1) { sum += (u32)((d[0] << 8) | d[1]); d += 2; n -= 2; }
    if (n) sum += (u32)(d[0] << 8);
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (u16)~sum;
}
static u32 pseudo(u32 src, u32 dst, u8 proto, int len) {
    return (src >> 16) + (src & 0xFFFF) + (dst >> 16) + (dst & 0xFFFF) + proto + (u32)len;
}

void ip_to_str(u32 ip, char *out, int max) {
    k_snprintf(out, max, "%d.%d.%d.%d", (int)(ip >> 24) & 255, (int)(ip >> 16) & 255, (int)(ip >> 8) & 255, (int)ip & 255);
}
int ip_parse(const char *s, u32 *ip) {
    u32 v = 0; int parts = 0;
    while (parts < 4) {
        if (*s < '0' || *s > '9') return 0;
        int n = 0, digits = 0;
        while (*s >= '0' && *s <= '9') { n = n * 10 + (*s - '0'); s++; if (++digits > 3) return 0; }
        if (n > 255) return 0;
        v = (v << 8) | (u32)n; parts++;
        if (parts < 4) { if (*s != '.') return 0; s++; }
    }
    if (*s) return 0;
    *ip = v; return 1;
}

/* ------------------------------------------------------------------ state */
static NetInfo info;
static u8 rxb[1600], txf[1600];
static int have_nic;
static u32 now;
const NetInfo *net_info(void) { return &info; }

/* ------------------------------------------------------------------ ARP / Ethernet */
static struct { u32 ip; u8 mac[6]; u8 valid; } arp[8];
static int arp_next;
static u8 pend[1600]; static int pend_len; static u32 pend_ip, pend_time;
static u32 arp_req_time;

static const u8 BCAST[6] = { 255, 255, 255, 255, 255, 255 };

static const u8 *arp_find(u32 ip) {
    for (int i = 0; i < 8; i++) if (arp[i].valid && arp[i].ip == ip) return arp[i].mac;
    return NULL;
}
static void arp_learn(u32 ip, const u8 *mac) {
    for (int i = 0; i < 8; i++) if (arp[i].valid && arp[i].ip == ip) { k_memcpy(arp[i].mac, mac, 6); return; }
    int i = arp_next++ & 7;
    arp[i].ip = ip; arp[i].valid = 1; k_memcpy(arp[i].mac, mac, 6);
}
static void eth_out(const u8 *dst, u16 type, const u8 *payload, int len) {
    k_memcpy(txf, dst, 6); k_memcpy(txf + 6, info.mac, 6); wr16(txf + 12, type);
    k_memcpy(txf + 14, payload, (unsigned)len);
    int total = 14 + len; if (total < 60) { k_memset(txf + total, 0, (unsigned)(60 - total)); total = 60; }
    hw_nic_send(txf, total);
}
static void arp_send(int op, const u8 *dstmac, u32 dstip) {
    u8 p[28];
    wr16(p, 1); wr16(p + 2, 0x0800); p[4] = 6; p[5] = 4; wr16(p + 6, (u16)op);
    k_memcpy(p + 8, info.mac, 6); wr32(p + 14, info.ip);
    if (op == 1) k_memset(p + 18, 0, 6); else k_memcpy(p + 18, dstmac, 6);
    wr32(p + 24, dstip);
    eth_out(op == 1 ? BCAST : dstmac, 0x0806, p, 28);
}
static void arp_request(u32 ip) {
    if (now - arp_req_time < 300 && arp_req_time) return;
    arp_req_time = now ? now : 1;
    arp_send(1, NULL, ip);
}

/* ------------------------------------------------------------------ IPv4 */
static u16 ip_id;
static void ip_send(u32 dst, u8 proto, const u8 *pl, int plen) {
    u8 f[1600];
    u8 *ip = f + 14;
    ip[0] = 0x45; ip[1] = 0; wr16(ip + 2, (u16)(20 + plen)); wr16(ip + 4, ip_id++); wr16(ip + 6, 0x4000);
    ip[8] = 64; ip[9] = proto; wr16(ip + 10, 0); wr32(ip + 12, info.ip); wr32(ip + 16, dst);
    wr16(ip + 10, csum(ip, 20, 0));
    k_memcpy(ip + 20, pl, (unsigned)plen);
    int total = 14 + 20 + plen;
    k_memcpy(f + 6, info.mac, 6); wr16(f + 12, 0x0800);
    const u8 *mac = NULL;
    u32 nh = dst;
    if (dst == 0xFFFFFFFFu || (info.mask && dst == (info.ip | ~info.mask))) mac = BCAST;
    else {
        if (info.mask && (dst & info.mask) != (info.ip & info.mask)) nh = info.gw;
        mac = arp_find(nh);
    }
    if (mac) {
        k_memcpy(f, mac, 6);
        if (total < 60) { k_memset(f + total, 0, (unsigned)(60 - total)); total = 60; }
        hw_nic_send(f, total);
    } else {                                     /* park one packet until ARP answers */
        k_memcpy(pend, f, (unsigned)total); pend_len = total; pend_ip = nh; pend_time = now;
        arp_request(nh);
    }
}

/* ------------------------------------------------------------------ ICMP / ping */
static int ping_state, ping_seq; static u32 ping_t0, ping_rtt, ping_ip;
static void icmp_rx(u32 src, const u8 *p, int len) {
    if (len < 8) return;
    if (p[0] == 8) {                              /* echo request -> reply */
        u8 r[1500]; if (len > 1480) return;
        k_memcpy(r, p, (unsigned)len); r[0] = 0; wr16(r + 2, 0); wr16(r + 2, csum(r, len, 0));
        ip_send(src, 1, r, len);
    } else if (p[0] == 0 && ping_state == 1 && src == ping_ip && rd16(p + 6) == (u16)ping_seq) {
        ping_rtt = now - ping_t0; ping_state = 2;
    }
}
int net_ping_start(u32 ip) {
    if (info.status != NET_UP) return 0;
    u8 p[40]; k_memset(p, 0, sizeof p);
    p[0] = 8; wr16(p + 4, 0x4D4D); wr16(p + 6, (u16)++ping_seq);
    for (int i = 8; i < 40; i++) p[i] = (u8)('a' + i % 23);
    wr16(p + 2, csum(p, 40, 0));
    ping_ip = ip; ping_t0 = now; ping_state = 1;
    ip_send(ip, 1, p, 40);
    return 1;
}
int net_ping_poll(int *rtt) {
    if (ping_state == 2) { *rtt = (int)ping_rtt; ping_state = 0; return 1; }
    if (ping_state == 1 && now - ping_t0 > 3000) { ping_state = 0; return -1; }
    return ping_state == 1 ? 0 : -1;
}

/* ------------------------------------------------------------------ UDP */
static void udp_send(u32 dst, u16 sport, u16 dport, const u8 *d, int len) {
    u8 p[1500]; if (len > 1400) return;
    wr16(p, sport); wr16(p + 2, dport); wr16(p + 4, (u16)(8 + len)); wr16(p + 6, 0);   /* checksum optional in IPv4 */
    k_memcpy(p + 8, d, (unsigned)len);
    ip_send(dst, 17, p, 8 + len);
}

/* ------------------------------------------------------------------ DHCP */
enum { D_IDLE, D_DISCOVER, D_REQUEST, D_BOUND };
static int dhcp_state; static u32 dhcp_xid, dhcp_t, dhcp_tries, offered_ip, server_id;

static void dhcp_send(int type) {
    u8 b[300]; k_memset(b, 0, sizeof b);
    b[0] = 1; b[1] = 1; b[2] = 6; wr32(b + 4, dhcp_xid); wr16(b + 10, 0x8000);
    k_memcpy(b + 28, info.mac, 6);
    wr32(b + 236, 0x63825363u);
    u8 *o = b + 240;
    *o++ = 53; *o++ = 1; *o++ = (u8)type;
    if (type == 3) {
        *o++ = 50; *o++ = 4; wr32(o, offered_ip); o += 4;
        *o++ = 54; *o++ = 4; wr32(o, server_id); o += 4;
    }
    *o++ = 55; *o++ = 3; *o++ = 1; *o++ = 3; *o++ = 6;
    *o++ = 255;
    u32 save = info.ip; info.ip = 0;
    udp_send(0xFFFFFFFFu, 68, 67, b, (int)(o - b));
    info.ip = save;
    dhcp_t = now ? now : 1;
}
static void dhcp_start(void) {
    info.status = NET_WAIT_DHCP; info.ip = info.mask = info.gw = info.dns = 0;
    dhcp_state = D_DISCOVER; dhcp_xid = 0x4D4D0000u ^ now ^ (u32)(info.mac[5] << 8); dhcp_tries = 0;
    dhcp_send(1);
}
void net_renew(void) { if (have_nic) dhcp_start(); }

static void dhcp_rx(const u8 *p, int len) {
    if (len < 241 || p[0] != 2 || rd32(p + 4) != dhcp_xid || rd32(p + 236) != 0x63825363u) return;
    int type = 0; u32 mask = 0, gw = 0, dns = 0, sid = 0;
    const u8 *o = p + 240, *end = p + len;
    while (o < end && *o != 255) {
        if (*o == 0) { o++; continue; }
        if (o + 2 > end || o + 2 + o[1] > end) break;
        int code = o[0], l = o[1];
        if (code == 53 && l >= 1) type = o[2];
        else if (code == 1 && l >= 4) mask = rd32(o + 2);
        else if (code == 3 && l >= 4) gw = rd32(o + 2);
        else if (code == 6 && l >= 4) dns = rd32(o + 2);
        else if (code == 54 && l >= 4) sid = rd32(o + 2);
        o += 2 + l;
    }
    if (type == 2 && dhcp_state == D_DISCOVER) {
        offered_ip = rd32(p + 16); server_id = sid; dhcp_state = D_REQUEST; dhcp_tries = 0;
        dhcp_send(3);
    } else if (type == 5 && dhcp_state == D_REQUEST) {
        info.ip = rd32(p + 16); info.mask = mask ? mask : 0xFFFFFF00u; info.gw = gw; info.dns = dns ? dns : gw;
        info.status = NET_UP; dhcp_state = D_BOUND;
        if (info.gw) arp_request(info.gw);
    } else if (type == 6) dhcp_start();
}

/* ------------------------------------------------------------------ DNS */
#define DNS_SLOTS 6
static struct { u8 used; s8 state; char name[64]; u16 id; u32 ip; u8 tries; u32 sent, done; } dq[DNS_SLOTS];
static u16 dns_id = 0x1234;

static int dns_name_ok(const char *n) {
    int l = k_strlen(n); if (l == 0 || l > 60) return 0;
    for (int i = 0; i < l; i++) {
        char c = n[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '.' || c == '_')) return 0;
    }
    return 1;
}
static void dns_send(int i) {
    u8 b[128]; k_memset(b, 0, 12);
    wr16(b, dq[i].id); wr16(b + 2, 0x0100); wr16(b + 4, 1);
    int o = 12; const char *n = dq[i].name;
    while (*n) {
        const char *dot = n; int l = 0;
        while (*dot && *dot != '.') { dot++; l++; }
        if (l == 0 || l > 63) { dq[i].state = -1; return; }
        b[o++] = (u8)l; k_memcpy(b + o, n, (unsigned)l); o += l;
        n = *dot ? dot + 1 : dot;
    }
    b[o++] = 0; wr16(b + o, 1); wr16(b + o + 2, 1); o += 4;
    dq[i].sent = now ? now : 1; dq[i].tries++;
    udp_send(info.dns, 49200, 53, b, o);
}
int dns_lookup(const char *name, u32 *ip) {
    u32 lit; if (ip_parse(name, &lit)) { *ip = lit; return 1; }
    if (!dns_name_ok(name) || info.status != NET_UP || !info.dns) return -1;
    for (int i = 0; i < DNS_SLOTS; i++)
        if (dq[i].used && k_strcmp(dq[i].name, name) == 0) {
            if (dq[i].state == 1) { *ip = dq[i].ip; return 1; }
            if (dq[i].state == 0) return 0;
            if (now - dq[i].done < 2000) return -1;           /* recent failure; retry later */
            dq[i].state = 0; dq[i].tries = 0; dq[i].id = dns_id++; dns_send(i); return 0;
        }
    int slot = -1;
    for (int i = 0; i < DNS_SLOTS; i++) if (!dq[i].used) { slot = i; break; }
    if (slot < 0) { slot = 0; for (int i = 1; i < DNS_SLOTS; i++) if (dq[i].done < dq[slot].done) slot = i; }
    k_memset(&dq[slot], 0, sizeof dq[slot]);
    dq[slot].used = 1; k_strcpy(dq[slot].name, name, sizeof dq[slot].name); dq[slot].id = dns_id++;
    dns_send(slot);
    return 0;
}
static int dns_skip_name(const u8 *p, int o, int len) {
    while (o < len) {
        int l = p[o];
        if (l == 0) return o + 1;
        if ((l & 0xC0) == 0xC0) return o + 2;
        o += l + 1;
    }
    return -1;
}
static void dns_rx(const u8 *p, int len) {
    if (len < 12) return;
    int i; for (i = 0; i < DNS_SLOTS; i++) if (dq[i].used && dq[i].state == 0 && dq[i].id == rd16(p)) break;
    if (i == DNS_SLOTS) return;
    int rcode = p[3] & 15, qd = rd16(p + 4), an = rd16(p + 6), o = 12;
    if (rcode != 0) { dq[i].state = -1; dq[i].done = now; return; }
    while (qd-- > 0) { o = dns_skip_name(p, o, len); if (o < 0) return; o += 4; }
    while (an-- > 0) {
        o = dns_skip_name(p, o, len); if (o < 0 || o + 10 > len) break;
        int type = rd16(p + o), rdlen = rd16(p + o + 8); o += 10;
        if (o + rdlen > len) break;
        if (type == 1 && rdlen == 4) { dq[i].ip = rd32(p + o); dq[i].state = 1; dq[i].done = now; return; }
        o += rdlen;
    }
    dq[i].state = -1; dq[i].done = now;
}

/* ------------------------------------------------------------------ TCP */
#define NSOCK 4
#define RXSZ 32768
#define TCP_FIN 1
#define TCP_SYN 2
#define TCP_RST 4
#define TCP_PSH 8
#define TCP_ACK 16
enum { S_FREE, S_SYN, S_ESTAB, S_CLOSE_WAIT, S_FIN_WAIT, S_LAST_ACK, S_ERR };
typedef struct {
    u8 state, fin_rcvd, fin_sent, fin_acked, orphan, want_close;
    u32 rip; u16 rport, lport;
    u32 snd_una, snd_nxt, rcv_nxt;
    u32 rx_head, rx_tail;               /* free-running counters */
    u8 rx[RXSZ];
    u8 tx[1460]; int tx_len; u32 tx_seq;
    u32 rto_at, rto; int retries; u32 closed_at;
} Sock;
static Sock socks[NSOCK];
static u16 next_port = 49300;
static u32 isn_ctr;

static int sock_ok(int s) { return s >= 0 && s < NSOCK && socks[s].state != S_FREE; }

static void tcp_seg(Sock *s, u8 flags, u32 seq, const u8 *data, int len) {
    u8 b[1500]; int hl = (flags & TCP_SYN) ? 24 : 20;
    wr16(b, s->lport); wr16(b + 2, s->rport); wr32(b + 4, seq); wr32(b + 8, (flags & TCP_ACK) ? s->rcv_nxt : 0);
    b[12] = (u8)((hl / 4) << 4); b[13] = flags;
    u32 free_ = RXSZ - (s->rx_head - s->rx_tail);
    wr16(b + 14, (u16)(free_ > 65535 ? 65535 : free_)); wr16(b + 16, 0); wr16(b + 18, 0);
    if (flags & TCP_SYN) { b[20] = 2; b[21] = 4; wr16(b + 22, 1460); }
    if (len) k_memcpy(b + hl, data, (unsigned)len);
    wr16(b + 16, csum(b, hl + len, pseudo(info.ip, s->rip, 6, hl + len)));
    ip_send(s->rip, 6, b, hl + len);
}
static void sock_free(Sock *s) { s->state = S_FREE; }

int tcp_open(u32 ip, u16 port) {
    if (info.status != NET_UP) return -1;
    for (int i = 0; i < NSOCK; i++)
        if (socks[i].state == S_FREE) {
            Sock *s = &socks[i];
            k_memset(s, 0, sizeof(*s));
            s->state = S_SYN; s->rip = ip; s->rport = port; s->lport = next_port++; if (next_port > 60000) next_port = 49300;
            isn_ctr += 64000;
            s->snd_una = now * 250 + isn_ctr; s->snd_nxt = s->snd_una + 1;
            s->rto = 1000; s->rto_at = now + s->rto; s->closed_at = now;
            tcp_seg(s, TCP_SYN, s->snd_una, NULL, 0);
            return i;
        }
    return -1;
}
int tcp_state(int sid) {
    if (!sock_ok(sid)) return TCP_CLOSED;
    switch (socks[sid].state) {
    case S_SYN: return TCP_CONNECTING;
    case S_ESTAB: return TCP_OPEN;
    case S_CLOSE_WAIT: case S_LAST_ACK: return TCP_PEER_CLOSED;
    case S_ERR: return TCP_ERROR;
    case S_FIN_WAIT: return socks[sid].fin_rcvd ? TCP_PEER_CLOSED : TCP_OPEN;
    }
    return TCP_CLOSED;
}
int tcp_send(int sid, const void *d, int n) {
    if (!sock_ok(sid)) return 0;
    Sock *s = &socks[sid];
    if ((s->state != S_ESTAB && s->state != S_CLOSE_WAIT) || s->tx_len > 0 || s->fin_sent) return 0;
    if (n > 1400) n = 1400;
    if (n <= 0) return 0;
    k_memcpy(s->tx, d, (unsigned)n); s->tx_len = n; s->tx_seq = s->snd_nxt; s->snd_nxt += (u32)n;
    s->rto = 1000; s->rto_at = now + s->rto; s->retries = 0;
    tcp_seg(s, TCP_PSH | TCP_ACK, s->tx_seq, s->tx, n);
    return n;
}
int tcp_recv(int sid, void *buf, int max) {
    if (!sock_ok(sid)) return 0;
    Sock *s = &socks[sid]; u8 *o = buf; int n = 0;
    u32 before = RXSZ - (s->rx_head - s->rx_tail);
    while (n < max && s->rx_tail != s->rx_head) o[n++] = s->rx[s->rx_tail++ % RXSZ];
    if (n && before < 8192) tcp_seg(s, TCP_ACK, s->snd_nxt, NULL, 0);     /* window update */
    return n;
}
static void send_fin(Sock *s) {
    s->fin_sent = 1; tcp_seg(s, TCP_FIN | TCP_ACK, s->snd_nxt, NULL, 0); s->snd_nxt++;
    s->rto = 1000; s->rto_at = now + s->rto; s->retries = 0;
    s->state = s->fin_rcvd ? S_LAST_ACK : S_FIN_WAIT;
}
void tcp_close(int sid) {
    if (!sock_ok(sid)) return;
    Sock *s = &socks[sid];
    s->orphan = 1; s->closed_at = now;
    if (s->state == S_SYN || s->state == S_ERR) {
        if (s->state == S_SYN) tcp_seg(s, TCP_RST | TCP_ACK, s->snd_nxt, NULL, 0);
        sock_free(s); return;
    }
    if (s->tx_len == 0 && !s->fin_sent) send_fin(s); else s->want_close = 1;
}

static void tcp_rx(u32 src, const u8 *p, int len) {
    if (len < 20) return;
    int hl = (p[12] >> 4) * 4; if (hl < 20 || hl > len) return;
    u16 sport = rd16(p), dport = rd16(p + 2); u32 seq = rd32(p + 4), ack = rd32(p + 8);
    u8 fl = p[13]; int dlen = len - hl; const u8 *data = p + hl;
    Sock *s = NULL;
    for (int i = 0; i < NSOCK; i++)
        if (socks[i].state != S_FREE && socks[i].rip == src && socks[i].rport == sport && socks[i].lport == dport) { s = &socks[i]; break; }
    if (!s) return;
    if (fl & TCP_RST) { s->state = S_ERR; if (s->orphan) sock_free(s); return; }
    if (s->state == S_SYN) {
        if ((fl & (TCP_SYN | TCP_ACK)) == (TCP_SYN | TCP_ACK) && ack == s->snd_nxt) {
            s->snd_una = ack; s->rcv_nxt = seq + 1; s->state = S_ESTAB; s->retries = 0;
            tcp_seg(s, TCP_ACK, s->snd_nxt, NULL, 0);
        }
        return;
    }
    if (fl & TCP_ACK) {
        if ((int)(ack - s->snd_una) > 0 && (int)(ack - s->snd_nxt) <= 0) {
            s->snd_una = ack;
            if (s->tx_len > 0 && (int)(ack - (s->tx_seq + (u32)s->tx_len)) >= 0) {
                s->tx_len = 0; s->retries = 0;
                if (s->want_close && !s->fin_sent) { s->want_close = 0; send_fin(s); }
            }
            if (s->fin_sent && ack == s->snd_nxt) s->fin_acked = 1;
        }
    }
    int need_ack = 0;
    if (dlen > 0) {
        int skip = 0;
        if ((int)(s->rcv_nxt - seq) > 0) skip = (int)(s->rcv_nxt - seq);      /* partly old data */
        if (skip < dlen && seq + (u32)skip == s->rcv_nxt) {
            u32 space = RXSZ - (s->rx_head - s->rx_tail);
            int take = dlen - skip; if ((u32)take > space) take = (int)space;
            if (s->orphan) take = dlen - skip;
            for (int i = 0; i < take; i++) { if (!s->orphan) s->rx[s->rx_head++ % RXSZ] = data[skip + i]; }
            s->rcv_nxt += (u32)take;
            if (take < dlen - skip) fl &= (u8)~TCP_FIN;
        } else if (skip < dlen) fl &= (u8)~TCP_FIN;                                  /* gap: ask for retransmission */
        need_ack = 1;
    }
    if ((fl & TCP_FIN) && seq + (u32)dlen == s->rcv_nxt && !s->fin_rcvd) {
        s->fin_rcvd = 1; s->rcv_nxt++; need_ack = 1;
        if (s->state == S_ESTAB) s->state = S_CLOSE_WAIT;
        else if (s->state == S_FIN_WAIT) s->state = S_LAST_ACK;
    } else if (fl & TCP_FIN) need_ack = 1;
    if (need_ack) tcp_seg(s, TCP_ACK, s->snd_nxt, NULL, 0);
    if (s->fin_acked && s->fin_rcvd) sock_free(s);
}

static void tcp_timers(void) {
    for (int i = 0; i < NSOCK; i++) {
        Sock *s = &socks[i];
        if (s->state == S_FREE) continue;
        if (s->orphan && now - s->closed_at > 12000) { sock_free(s); continue; }
        if ((int)(now - s->rto_at) < 0) continue;
        if (s->state == S_SYN || s->tx_len > 0 || (s->fin_sent && !s->fin_acked)) {
            if (++s->retries > 5) { s->state = S_ERR; if (s->orphan) sock_free(s); continue; }
            s->rto = s->rto * 2 > 8000 ? 8000 : s->rto * 2; s->rto_at = now + s->rto;
            if (s->state == S_SYN) tcp_seg(s, TCP_SYN, s->snd_una, NULL, 0);
            else if (s->tx_len > 0) tcp_seg(s, TCP_PSH | TCP_ACK, s->tx_seq, s->tx, s->tx_len);
            else tcp_seg(s, TCP_FIN | TCP_ACK, s->snd_nxt - 1, NULL, 0);
        }
    }
}

/* ------------------------------------------------------------------ receive path */
static void ip_rx(const u8 *f, int len) {
    const u8 *ip = f + 14; int plen = len - 14;
    if (plen < 20 || (ip[0] >> 4) != 4) return;
    int ihl = (ip[0] & 15) * 4, tot = rd16(ip + 2);
    if (ihl < 20 || tot < ihl || tot > plen) return;
    if (rd16(ip + 6) & 0x3FFF) return;                                        /* fragments unsupported */
    u32 src = rd32(ip + 12), dst = rd32(ip + 16);
    if (info.ip && dst != info.ip && dst != 0xFFFFFFFFu && dst != (info.ip | ~info.mask)) return;
    const u8 *pl = ip + ihl; int pl_len = tot - ihl;
    if (ip[9] == 1) icmp_rx(src, pl, pl_len);
    else if (ip[9] == 6) tcp_rx(src, pl, pl_len);
    else if (ip[9] == 17 && pl_len >= 8) {
        u16 sp = rd16(pl), dp = rd16(pl + 2);
        if (dp == 68) dhcp_rx(pl + 8, pl_len - 8);
        else if (sp == 53 && dp == 49200) dns_rx(pl + 8, pl_len - 8);
    }
}
static void arp_rx(const u8 *f, int len) {
    if (len < 42) return;
    const u8 *a = f + 14;
    if (rd16(a) != 1 || rd16(a + 2) != 0x0800 || a[4] != 6 || a[5] != 4) return;
    int op = rd16(a + 6); u32 sip = rd32(a + 14), tip = rd32(a + 24);
    if (sip) arp_learn(sip, a + 8);
    if (op == 1 && info.ip && tip == info.ip) arp_send(2, a + 8, sip);
    if (pend_len && sip == pend_ip) {                                          /* flush the parked packet */
        k_memcpy(pend, a + 8, 6); hw_nic_send(pend, pend_len); pend_len = 0;
    }
}

void net_init(void) {
    have_nic = hw_nic_init(info.mac);
    info.status = have_nic ? NET_WAIT_DHCP : NET_NO_NIC;
    if (have_nic) { now = hw_ms(); dhcp_start(); }
}

void net_poll(void) {
    if (!have_nic) return;
    now = hw_ms(); if (!now) now = 1;
    for (int i = 0; i < 24; i++) {
        int n = hw_nic_recv(rxb, sizeof rxb);
        if (n < 14) break;
        u16 type = rd16(rxb + 12);
        if (type == 0x0806) arp_rx(rxb, n);
        else if (type == 0x0800) ip_rx(rxb, n);
    }
    if (pend_len && now - pend_time > 1500) pend_len = 0;
    if (dhcp_state == D_DISCOVER || dhcp_state == D_REQUEST) {
        if (now - dhcp_t > 3000) {
            if (++dhcp_tries > 4) dhcp_start(); else dhcp_send(dhcp_state == D_DISCOVER ? 1 : 3);
        }
    }
    for (int i = 0; i < DNS_SLOTS; i++)
        if (dq[i].used && dq[i].state == 0 && now - dq[i].sent > 1500) {
            if (dq[i].tries >= 4) { dq[i].state = -1; dq[i].done = now; } else dns_send(i);
        }
    tcp_timers();
}
