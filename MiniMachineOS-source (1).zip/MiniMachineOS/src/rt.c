/* rt.c - the few C runtime functions gcc may call implicitly (kernel build only) */
#include "types.h"
void *memcpy(void *d, const void *s, unsigned long n) {
    void *r = d;
    __asm__ volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(n) : : "memory");
    return r;
}
void *memset(void *d, int c, unsigned long n) {
    void *r = d;
    __asm__ volatile("rep stosb" : "+D"(d), "+c"(n) : "a"(c) : "memory");
    return r;
}
void *memmove(void *d, const void *s, unsigned long n) {
    u8 *dd = d; const u8 *ss = s;
    if (dd < ss || dd >= ss + n) { __asm__ volatile("rep movsb" : "+D"(dd), "+S"(ss), "+c"(n) : : "memory"); }
    else { dd += n; ss += n; while (n--) *--dd = *--ss; }
    return d;
}
int memcmp(const void *a, const void *b, unsigned long n) {
    const u8 *x = a, *y = b;
    while (n--) { if (*x != *y) return *x - *y; x++; y++; }
    return 0;
}
