#ifndef ACCOUNT_H
#define ACCOUNT_H
#include "types.h"
/* The single user account, installed-app list and saved settings, kept in sector 0 of a reserved area of the
   boot disk (LBA 2048..4095) together with a snapshot of the in-memory filesystem. */
#define ACCT_NAME_MAX 16
#define ACCT_PASS_MIN 4
#define ACCT_PASS_MAX 32
void persist_init(void);                          /* detect disk, load account/settings/files */
int  persist_disk(void);                          /* 1 if a writable disk backs this session */
int  acct_exists(void);
const char *acct_name(void);
int  acct_create(const char *user, const char *pass);     /* 0 ok, else error code */
int  acct_check(const char *pass);                        /* 1 = correct */
int  app_installed(int app);
void app_set_installed(int app, int on);
void persist_save_config(void);                   /* account + theme + installed apps */
void persist_tick(u32 now);                       /* debounced filesystem flush */
void entropy_add(u32 v);                          /* mix timing noise into the salt generator */
#endif
