#ifndef KLIB_H
#define KLIB_H
#include "types.h"
/* The GUI code only uses these names, so it builds both as a freestanding
   kernel (rt.c supplies memcpy & co.) and as a normal host program for testing. */
#define k_memcpy  __builtin_memcpy
#define k_memset  __builtin_memset
#define k_memmove __builtin_memmove
#define k_memcmp  __builtin_memcmp

int  k_strlen(const char *s);
int  k_strcmp(const char *a, const char *b);
int  k_strncmp(const char *a, const char *b, int n);
int  k_stricmp_sub(const char *hay, const char *needle);   /* case-insensitive substring: 1 if found */
int  k_strcpy(char *dst, const char *src, int max);        /* bounded copy, returns length */
int  k_strcat(char *dst, const char *src, int max);        /* bounded append, returns new length */
int  k_atoi(const char *s);
u32  k_rand(void);                                         /* xorshift32 */
void k_srand(u32 seed);
u32  k_crc32(const void *data, int n);
int  k_snprintf(char *out, int n, const char *fmt, ...);
static inline int k_min(int a, int b) { return a < b ? a : b; }
static inline int k_max(int a, int b) { return a > b ? a : b; }
static inline int k_abs(int a) { return a < 0 ? -a : a; }
static inline int k_clamp(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
#endif
