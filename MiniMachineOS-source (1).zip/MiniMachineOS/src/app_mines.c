/* app_mines.c - Minesweeper (14x10, 20 mines). Left click opens, right click flags. First click is always safe. */
#include "app.h"
#include "klib.h"
#include "hw.h"

#define CELL 32
#define HEAD 60
static int mw_(void) { return MN_W * CELL; }

static void reset(MinesState *m) { k_memset(m, 0, sizeof *m); m->hit = -1; m->hot = -1; m->last_sec = -1; }
static void mn_init(Window *w, const char *arg) { (void)arg; k_srand(gui_now() | 1); reset(&w->u.mines); }

static void each_nb(int i, int *out, int *n) {
    int x = i % MN_W, y = i / MN_W; *n = 0;
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        int nx = x + dx, ny = y + dy;
        if (nx >= 0 && ny >= 0 && nx < MN_W && ny < MN_H) out[(*n)++] = ny * MN_W + nx;
    }
}
static void place(MinesState *m, int safe) {
    int nb[8], nn; each_nb(safe, nb, &nn);
    int placed = 0;
    while (placed < MN_MINES) {
        int i = (int)(k_rand() % (MN_W * MN_H)); int bad = (i == safe);
        for (int k = 0; k < nn; k++) if (nb[k] == i) bad = 1;
        if (bad || m->mine[i]) continue;
        m->mine[i] = 1; placed++;
    }
    for (int i = 0; i < MN_W * MN_H; i++) {
        int c = 0; each_nb(i, nb, &nn);
        for (int k = 0; k < nn; k++) c += m->mine[nb[k]];
        m->num[i] = (u8)c;
    }
    m->placed = 1; m->t0 = gui_now();
}
static void reveal(MinesState *m, int i0) {
    int stack[MN_W * MN_H * 2], sp = 0;
    stack[sp++] = i0;
    while (sp > 0) {
        int i = stack[--sp];
        if (m->st[i] != 0) continue;
        m->st[i] = 1; m->opened++;
        if (m->num[i] == 0 && !m->mine[i]) {
            int nb[8], nn; each_nb(i, nb, &nn);
            for (int k = 0; k < nn; k++) if (m->st[nb[k]] == 0 && sp < MN_W * MN_H * 2 - 8) stack[sp++] = nb[k];
        }
    }
}
static void lose(MinesState *m, int i) {
    m->over = 1; m->hit = i; m->tend = gui_now();
    for (int k = 0; k < MN_W * MN_H; k++) if (m->mine[k] && m->st[k] != 2) m->st[k] = 1;
}
static void check_win(MinesState *m) {
    if (!m->over && m->opened >= MN_W * MN_H - MN_MINES) {
        m->over = m->won = 1; m->tend = gui_now();
        for (int k = 0; k < MN_W * MN_H; k++) if (m->mine[k]) m->st[k] = 2;
        m->flags = MN_MINES;
    }
}

static int cell_at(Window *w, int x, int y) {
    int cw = w->w - 2, bx = (cw - mw_()) / 2, by = HEAD;
    if (x < bx || y < by || x >= bx + mw_() || y >= by + MN_H * CELL) return -1;
    return ((y - by) / CELL) * MN_W + (x - bx) / CELL;
}
static int btn_hit(Window *w, int x, int y) { int cw = w->w - 2; return ui_inside(x, y, cw / 2 - 50, 12, 100, 34); }

static void mn_mouse(Window *w, int x, int y, int ev, int clicks) {
    MinesState *m = &w->u.mines; (void)clicks;
    if (ev == EV_MOVE) { int h = cell_at(w, x, y); if (btn_hit(w, x, y)) h = 1000; if (h != m->hot) { m->hot = h; win_invalidate(w); } return; }
    if (ev == EV_DOWN) {
        if (btn_hit(w, x, y)) { reset(m); win_invalidate(w); return; }
        int i = cell_at(w, x, y);
        if (i < 0 || m->over || m->st[i] == 2) return;
        if (!m->placed) place(m, i);
        if (m->mine[i]) { lose(m, i); }
        else if (m->st[i] == 0) { reveal(m, i); check_win(m); }
        win_invalidate(w);
    } else if (ev == EV_RDOWN) {
        int i = cell_at(w, x, y);
        if (i < 0 || m->over || m->st[i] == 1) return;
        if (m->st[i] == 0) { m->st[i] = 2; m->flags++; } else { m->st[i] = 0; m->flags--; }
        win_invalidate(w);
    }
}
static void mn_key(Window *w, int key, int mods) { (void)mods; if (key == 'r' || key == KEY_ENTER || key == KEY_F2) { reset(&w->u.mines); win_invalidate(w); } }
static void mn_tick(Window *w, u32 ms) {
    MinesState *m = &w->u.mines;
    if (m->placed && !m->over) { int s = (int)((ms - m->t0) / 1000); if (s != m->last_sec) { m->last_sec = s; win_invalidate_rect(w, 0, 0, w->w - 2, HEAD); } }
}

static void flag(int x, int y) {
    gfx_line(x + 12, y + 8, x + 12, y + 24, 28, 0x303030, 255);
    gfx_line(x + 12, y + 9, x + 21, y + 13, 40, 0xE5484D, 255); gfx_line(x + 12, y + 17, x + 21, y + 13, 40, 0xE5484D, 255);
    gfx_fill(x + 12, y + 10, 8, 7, 0xE5484D);
    gfx_fill(x + 8, y + 24, 10, 2, 0x303030);
}
static void mine(int x, int y) {
    int cx = x + CELL / 2, cy = y + CELL / 2;
    gfx_line(cx - 9, cy, cx + 9, cy, 30, 0x202020, 255); gfx_line(cx, cy - 9, cx, cy + 9, 30, 0x202020, 255);
    gfx_line(cx - 6, cy - 6, cx + 6, cy + 6, 30, 0x202020, 255); gfx_line(cx - 6, cy + 6, cx + 6, cy - 6, 30, 0x202020, 255);
    gfx_circle(cx, cy, 6, 0x202020, 255); gfx_circle(cx - 2, cy - 2, 2, 0xFFFFFF, 255);
}

static void mn_draw(Window *w, int x, int y, int cw, int ch) {
    MinesState *m = &w->u.mines;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    char b[32];
    k_snprintf(b, sizeof b, "%03d", k_max(0, MN_MINES - m->flags));
    gfx_round(x + 16, y + 12, 70, 34, 6, CORNER_ALL, 0x151515, 255); gfx_text_center(&font_h2, x + 16, y + 12, 70, 34, b, 0xFF5A5A);
    int secs = m->placed ? (int)(((m->over ? m->tend : gui_now()) - m->t0) / 1000) : 0;
    k_snprintf(b, sizeof b, "%03d", k_min(999, secs));
    gfx_round(x + cw - 86, y + 12, 70, 34, 6, CORNER_ALL, 0x151515, 255); gfx_text_center(&font_h2, x + cw - 86, y + 12, 70, 34, b, 0xFF5A5A);
    ui_button(x + cw / 2 - 50, y + 12, 100, 34, m->won ? "You won!" : m->over ? "Try again" : "New game", m->hot == 1000, m->over);
    int bx = x + (cw - mw_()) / 2, by = y + HEAD;
    gfx_round(bx - 4, by - 4, mw_() + 8, MN_H * CELL + 8, 6, CORNER_ALL, theme.border, 255);
    static const u32 numc[9] = { 0, 0x2F6BFF, 0x2E9B3B, 0xE0443E, 0x1E2E8C, 0x9A2A2A, 0x1C9A9A, 0x202020, 0x808080 };
    for (int j = 0; j < MN_H; j++) for (int i = 0; i < MN_W; i++) {
        int k = j * MN_W + i, cx = bx + i * CELL, cy = by + j * CELL;
        if (m->st[k] == 1) {
            gfx_fill(cx, cy, CELL, CELL, k == m->hit ? 0xE5484D : (theme.dark ? 0x1B1D20 : 0xD5D8DD));
            gfx_rect_a(cx, cy, CELL, CELL, 0x000000, 40);
            if (m->mine[k]) mine(cx, cy);
            else if (m->num[k]) { char n[2] = { (char)('0' + m->num[k]), 0 }; gfx_text_center(&font_uib, cx, cy, CELL, CELL, n, numc[m->num[k]]); }
        } else {
            gfx_fill(cx, cy, CELL, CELL, theme.dark ? 0x2B2D31 : 0xFAFAFB);
            gfx_round(cx + 2, cy + 2, CELL - 4, CELL - 4, 4, CORNER_ALL, m->hot == k ? gfx_lerp(theme.accent, 0xFFFFFF, 40) : theme.accent, 255);
            if (m->st[k] == 2) flag(cx, cy);
        }
    }
    if (m->over) gfx_text_center(&font_uib, x, by + MN_H * CELL + 8, cw, 24, m->won ? "Cleared! Well done." : "Boom! You hit a mine.", theme.dim);
    else gfx_text_center(&font_sm, x, by + MN_H * CELL + 10, cw, 20, "Left click: open   Right click: flag   R: restart", theme.dim);
}

const AppDesc app_mines = {
    "Minesweeper", "Find every mine", ICON_MINES, MN_W * CELL + 34, HEAD + MN_H * CELL + 46 + TB_H + 1, MN_W * CELL + 34, HEAD + MN_H * CELL + 46 + TB_H + 1,
    mn_init, mn_draw, mn_mouse, mn_key, mn_tick, 0, NULL, NULL, 2
};
