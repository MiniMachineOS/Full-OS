/* nic_pcnet.c - AMD PCnet-PCI II / PCnet-FAST III (Am79C970A/973): VirtualBox default, QEMU `-nic model=pcnet`.
   32-bit software style (SWSTYLE 2). NOT yet verified against a device model. */
#include "nic.h"
#include "plat.h"
#include "klib.h"

#define NRX 16
#define NTX 8
typedef struct { u32 base, flags, mcnt, res; } __attribute__((packed)) PDesc;
typedef struct { u16 mode; u8 rlen, tlen; u8 padr[6]; u16 res; u8 ladr[8]; u32 rdra, tdra; } __attribute__((packed)) InitBlk;
static PDesc rxr[NRX] __attribute__((aligned(16)));
static PDesc txr[NTX] __attribute__((aligned(16)));
static InitBlk iblk __attribute__((aligned(16)));
static u8 rxb[NRX][2048] __attribute__((aligned(16)));
static u8 txb[NTX][2048] __attribute__((aligned(16)));
static u16 io; static int rx_cur, tx_cur, ready;

static void csr_w(int r, u32 v) { io_out32((u16)(io + 0x14), (u32)r); io_out32((u16)(io + 0x10), v); }
static u32 csr_r(int r) { io_out32((u16)(io + 0x14), (u32)r); return io_in32((u16)(io + 0x10)); }
static void bcr_w(int r, u32 v) { io_out32((u16)(io + 0x14), (u32)r); io_out32((u16)(io + 0x1C), v); }

static int match(u16 v, u16 d) { return v == 0x1022 && d == 0x2000; }

static int init(const PciInfo *p, u8 mac[6]) {
    u32 bar = p->bar[0];
    if (!(bar & 1)) return 0;
    io = (u16)(bar & ~3u);
    (void)io_in32((u16)(io + 0x18));                                  /* reset (dword access also switches to 32-bit I/O mode) */
    io_out32((u16)(io + 0x10), 0);
    delay_ms(2);
    for (int i = 0; i < 6; i++) mac[i] = io_in8((u16)(io + i));
    if ((mac[0] | mac[1] | mac[2] | mac[3] | mac[4] | mac[5]) == 0) return 0;
    bcr_w(20, 0x0102);                                                /* SSIZE32 | SWSTYLE 2 */
    csr_w(0, 4);                                                      /* STOP */

    k_memset(rxr, 0, sizeof rxr); k_memset(txr, 0, sizeof txr); k_memset(&iblk, 0, sizeof iblk);
    for (int i = 0; i < NRX; i++) { rxr[i].base = dma_addr(rxb[i]); rxr[i].flags = 0x80000000u | 0xF000u | (u32)((-2048) & 0xFFF); }
    for (int i = 0; i < NTX; i++) txr[i].base = dma_addr(txb[i]);
    iblk.mode = 0; iblk.rlen = (u8)(4 << 4); iblk.tlen = (u8)(3 << 4);   /* ring sizes 2^4 and 2^3 */
    for (int i = 0; i < 6; i++) iblk.padr[i] = mac[i];
    iblk.rdra = dma_addr(rxr); iblk.tdra = dma_addr(txr);
    BARRIER();
    csr_w(1, dma_addr(&iblk) & 0xFFFF); csr_w(2, dma_addr(&iblk) >> 16);
    csr_w(0, 1);                                                      /* INIT */
    int ok = 0; for (int i = 0; i < 1000; i++) { if (csr_r(0) & 0x100) { ok = 1; break; } delay_ms(1); }   /* IDON */
    if (!ok) return 0;
    csr_w(0, 2);                                                      /* STRT (interrupts stay masked) */
    rx_cur = tx_cur = 0; ready = 1;
    return 1;
}

static int send(const u8 *f, int len) {
    if (!ready || len <= 0 || len > 1514) return 0;
    PDesc *d = &txr[tx_cur];
    for (int i = 0; i < 200000 && (d->flags & 0x80000000u); i++) __asm__ volatile("pause");
    if (d->flags & 0x80000000u) return 0;
    k_memcpy(txb[tx_cur], f, (unsigned)len);
    if (len < 60) { k_memset(txb[tx_cur] + len, 0, (unsigned)(60 - len)); len = 60; }
    d->mcnt = 0;
    BARRIER();
    d->flags = 0x80000000u | 0x03000000u | 0xF000u | (u32)((-len) & 0xFFF);   /* OWN | STP | ENP */
    BARRIER();
    csr_w(0, 0x08);                                                   /* TDMD */
    tx_cur = (tx_cur + 1) % NTX;
    return 1;
}

static int recv(u8 *buf, int max) {
    if (!ready) return 0;
    PDesc *d = &rxr[rx_cur];
    if (d->flags & 0x80000000u) return 0;
    int n = 0;
    u32 fl = d->flags;
    if (!(fl & 0x40000000u) && (fl & 0x03000000u) == 0x03000000u) {   /* no ERR, STP + ENP */
        int len = (int)(d->mcnt & 0xFFF);
        if (len > 4) { n = len - 4; if (n > max) n = max; k_memcpy(buf, rxb[rx_cur], (unsigned)n); }
    }
    d->mcnt = 0;
    BARRIER();
    d->flags = 0x80000000u | 0xF000u | (u32)((-2048) & 0xFFF);
    rx_cur = (rx_cur + 1) % NRX;
    return n;
}

const NicDrv drv_pcnet = { "AMD PCnet (VirtualBox)", match, init, send, recv };
