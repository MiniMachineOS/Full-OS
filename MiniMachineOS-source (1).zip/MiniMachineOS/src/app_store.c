/* app_store.c - App Store: add/remove the bundled apps and games (they live in the kernel; installing enables them) */
#include "app.h"
#include "account.h"
#include "klib.h"

#define SB_W 176
#define HEAD_H 64
#define ROW_H 88
static const char *cats[4] = { "Discover", "Apps", "Games", "Installed" };

static int visible(int app, int cat) {
    int c = apps[app]->category;
    if (c == 0) return 0;
    if (cat == 0) return 1;
    if (cat == 1) return c == 1;
    if (cat == 2) return c == 2;
    return app_installed(app);
}
static int list(int cat, int *out) {
    int n = 0;
    for (int i = 0; i < APP_COUNT; i++) if (visible(i, cat)) out[n++] = i;
    return n;
}
static void store_init(Window *w, const char *arg) { (void)arg; w->u.store.hot = -1; }

/* hot ids: 100+i category, 1000 + row*10 + button (0 install/open, 1 remove) */
static int hit(Window *w, int x, int y) {
    StoreState *s = &w->u.store;
    int cw = w->w - 2, ch = w->h - TB_H - 1;
    if (x < 0 || y < 0) return -1;
    if (x < SB_W) { for (int i = 0; i < 4; i++) if (ui_inside(x, y, 10, 70 + i * 40, SB_W - 20, 34)) return 100 + i; return -1; }
    int ids[APP_COUNT]; int n = list(s->cat, ids);
    for (int r = 0; r < n; r++) {
        int ry = HEAD_H + r * ROW_H - s->scroll;
        if (ry + ROW_H < HEAD_H || ry > ch) continue;
        int inst = app_installed(ids[r]);
        if (inst) {
            if (ui_inside(x, y, cw - 20 - 86, ry + 28, 86, 32)) return 1000 + r * 10 + 1;
            if (ui_inside(x, y, cw - 20 - 86 - 8 - 80, ry + 28, 80, 32)) return 1000 + r * 10;
        } else if (ui_inside(x, y, cw - 20 - 96, ry + 28, 96, 32)) return 1000 + r * 10;
    }
    return -1;
}

static void store_mouse(Window *w, int x, int y, int ev, int clicks) {
    StoreState *s = &w->u.store; (void)clicks;
    int ch = w->h - TB_H - 1;
    int ids[APP_COUNT]; int n = list(s->cat, ids);
    int maxs = k_max(0, HEAD_H + n * ROW_H + 12 - ch);
    if (ev == EV_MOVE) { int h = hit(w, x, y); if (h != s->hot) { s->hot = h; win_invalidate(w); } return; }
    if (ev == EV_WHEEL) { s->scroll = k_clamp(s->scroll + clicks * 50, 0, maxs); win_invalidate(w); return; }
    if (ev != EV_DOWN) return;
    int h = hit(w, x, y);
    if (h >= 100 && h < 104) { s->cat = h - 100; s->scroll = 0; s->msg[0] = 0; win_invalidate(w); return; }
    if (h >= 1000) {
        int r = (h - 1000) / 10, b = (h - 1000) % 10, app = ids[r];
        if (!app_installed(app)) {
            app_set_installed(app, 1);
            k_snprintf(s->msg, sizeof s->msg, "Installed %s", apps[app]->name);
            gui_apps_changed();
        } else if (b == 0) app_launch(app, NULL);
        else {
            gui_close_app(app);
            app_set_installed(app, 0);
            k_snprintf(s->msg, sizeof s->msg, "Removed %s", apps[app]->name);
            gui_apps_changed();
        }
        s->scroll = k_clamp(s->scroll, 0, maxs);
        win_invalidate(w);
    }
}

static void store_draw(Window *w, int x, int y, int cw, int ch) {
    StoreState *s = &w->u.store;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    /* sidebar */
    gfx_fill(x, y, SB_W, ch, theme.win_alt); gfx_fill(x + SB_W - 1, y, 1, ch, theme.border);
    icon_draw(ICON_STORE, x + 16, y + 14, 36);
    gfx_text(&font_uib, x + 62, y + 14, "App Store", theme.text);
    gfx_text(&font_sm, x + 62, y + 34, "Apps & games", theme.dim);
    for (int i = 0; i < 4; i++) {
        int by = y + 70 + i * 40;
        if (s->cat == i) gfx_round(x + 10, by, SB_W - 20, 34, 6, CORNER_ALL, theme.accent, 255);
        else if (s->hot == 100 + i) gfx_round(x + 10, by, SB_W - 20, 34, 6, CORNER_ALL, theme.hover, 255);
        gfx_text(&font_ui, x + 24, by + (34 - font_ui.height) / 2, cats[i], s->cat == i ? theme.accent_text : theme.text);
    }
    /* header */
    int ids[APP_COUNT]; int n = list(s->cat, ids);
    int mx = x + SB_W;
    gfx_text(&font_h2, mx + 20, y + 14, cats[s->cat], theme.text);
    char b[80]; k_snprintf(b, sizeof b, "%d item%s", n, n == 1 ? "" : "s");
    gfx_text(&font_sm, mx + 22, y + 42, b, theme.dim);
    if (s->msg[0]) gfx_text_right(&font_ui, x + cw - 20, y + 22, s->msg, theme.accent);
    Clip old = gfx_clip_push(mx, y + HEAD_H, cw - SB_W, ch - HEAD_H);
    for (int r = 0; r < n; r++) {
        int app = ids[r]; const AppDesc *a = apps[app];
        int ry = y + HEAD_H + r * ROW_H - s->scroll;
        if (ry + ROW_H < y + HEAD_H || ry > y + ch) continue;
        gfx_round_border(mx + 16, ry + 4, cw - SB_W - 32, ROW_H - 12, 10, theme.win_alt, theme.border);
        icon_draw(a->icon, mx + 32, ry + 16, 52);
        gfx_text(&font_uib, mx + 100, ry + 16, a->name, theme.text);
        gfx_text(&font_sm, mx + 100 + gfx_text_w(&font_uib, a->name) + 10, ry + 19, a->category == 2 ? "GAME" : "APP", theme.accent);
        gfx_text_fit(&font_ui, mx + 100, ry + 40, cw - SB_W - 100 - 230, a->desc, theme.dim);
        int inst = app_installed(app);
        int bx = x + cw - 20 - 96;
        if (inst) {
            ui_button(x + cw - 20 - 86, ry + 28, 86, 32, "Remove", s->hot == 1000 + r * 10 + 1, 0);
            ui_button(x + cw - 20 - 86 - 8 - 80, ry + 28, 80, 32, "Open", s->hot == 1000 + r * 10, 1);
        } else ui_button(bx, ry + 28, 96, 32, "Install", s->hot == 1000 + r * 10, 1);
    }
    if (n == 0) gfx_text_center(&font_ui, mx, y + HEAD_H, cw - SB_W, 120, "Nothing here yet", theme.dim);
    gfx_clip_set(old);
}

const AppDesc app_store = {
    "App Store", "Get apps and games", ICON_STORE, 800, 540, 640, 360,
    store_init, store_draw, store_mouse, NULL, NULL
};
