#ifndef GFX_H
#define GFX_H
#include "types.h"

typedef struct { s8 xoff, yoff; u8 w, h, adv; u16 off; } Glyph;
typedef struct { const Glyph *g; const u8 *bits; int height, ascent, first, count; } Font;
extern const Font font_ui, font_uib, font_sm, font_h2, font_big, font_mono;

typedef struct { int x0, y0, x1, y1; } Clip;           /* x1,y1 exclusive */

#define CORNER_TL 1
#define CORNER_TR 2
#define CORNER_BL 4
#define CORNER_BR 8
#define CORNER_ALL 15
#define CORNER_TOP 3
#define CORNER_BOTTOM 12

#define RGB(r,g,b) (((u32)(r) << 16) | ((u32)(g) << 8) | (u32)(b))

extern u32 *gfx_scene;      /* off-screen composition buffer (width * height) */
extern u32 *gfx_screen;     /* the visible framebuffer */
extern int  gfx_w, gfx_h, gfx_spitch;   /* spitch = screen pitch in pixels */

void gfx_init(u32 *scene, u32 *screen, int w, int h, int spitch);
Clip gfx_clip_get(void);
void gfx_clip_set(Clip c);
Clip gfx_clip_push(int x, int y, int w, int h);       /* intersect; returns the old clip */
int  gfx_visible(int x, int y, int w, int h);

u32  gfx_blend(u32 dst, u32 src, u32 a);
u32  gfx_lerp(u32 a, u32 b, int t256);

void gfx_fill(int x, int y, int w, int h, u32 c);
void gfx_fill_a(int x, int y, int w, int h, u32 c, int a);
void gfx_rect(int x, int y, int w, int h, u32 c);                 /* 1px outline */
void gfx_rect_a(int x, int y, int w, int h, u32 c, int a);
void gfx_vgrad(int x, int y, int w, int h, u32 top, u32 bot);
void gfx_round(int x, int y, int w, int h, int r, int corners, u32 c, int a);
void gfx_round_border(int x, int y, int w, int h, int r, u32 fill, u32 border);
void gfx_circle(int cx, int cy, int r, u32 c, int a);             /* centre in pixel-corner coords */
void gfx_line(int x0, int y0, int x1, int y1, int w16, u32 c, int a);   /* AA, w16 = width in 1/16 px, short lines only */
void gfx_shadow(int x, int y, int w, int h, int dy_off, int size, int maxa);

int  gfx_text_w(const Font *f, const char *s);
int  gfx_text(const Font *f, int x, int y, const char *s, u32 c);
int  gfx_text_n(const Font *f, int x, int y, const char *s, int n, u32 c);
void gfx_text_fit(const Font *f, int x, int y, int maxw, const char *s, u32 c);
void gfx_text_center(const Font *f, int x, int y, int w, int h, const char *s, u32 c);
void gfx_text_right(const Font *f, int rx, int y, const char *s, u32 c);

void gfx_present(int x, int y, int w, int h);          /* scene -> screen */
void gfx_cursor(int x, int y);                         /* draw arrow on screen */
#define CURSOR_W 12
#define CURSOR_H 19
#endif
