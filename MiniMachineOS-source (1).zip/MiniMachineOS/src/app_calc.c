/* app_calc.c - fixed-point (3 decimals) calculator */
#include "app.h"
#include "klib.h"

#define DISP_H 120
static const char *keys[5][4] = {
    { "C", "<", "+/-", "/" },
    { "7", "8", "9", "*" },
    { "4", "5", "6", "-" },
    { "1", "2", "3", "+" },
    { "0", "0", ".", "=" },
};

/* a*b/c with 64-bit intermediate, guarded so idiv can never fault */
static int muldiv(int a, int b, int c, int *ovf) {
    long long P = (long long)a * b;
    unsigned long long ap = P < 0 ? (unsigned long long)(-P) : (unsigned long long)P;
    unsigned long long lim = ((unsigned long long)(unsigned)k_abs(c)) << 31;
    if (ap >= lim) { *ovf = 1; return 0; }
    int lo = (int)P, hi = (int)(P >> 32), q, r;
    __asm__("idivl %4" : "=a"(q), "=d"(r) : "0"(lo), "1"(hi), "r"(c) : "cc");
    return q;
}

static int parse(const char *s) {
    int neg = 0, ip = 0, fp = 0, fd = 0;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') { ip = ip * 10 + (*s - '0'); s++; }
    if (*s == '.') { s++; while (*s >= '0' && *s <= '9' && fd < 3) { fp = fp * 10 + (*s - '0'); fd++; s++; } }
    while (fd < 3) { fp *= 10; fd++; }
    int v = ip * 1000 + fp;
    return neg ? -v : v;
}
static void fmt(int v, char *out, int max) {
    int neg = v < 0; unsigned u = neg ? (unsigned)(-v) : (unsigned)v;
    char b[24];
    int ip = (int)(u / 1000), fp = (int)(u % 1000);
    if (fp) {
        char f[4]; k_snprintf(f, 4, "%03d", fp);
        for (int i = 2; i >= 0 && f[i] == '0'; i--) f[i] = 0;
        k_snprintf(b, sizeof b, "%s%d.%s", neg ? "-" : "", ip, f);
    } else k_snprintf(b, sizeof b, "%s%d", neg ? "-" : "", ip);
    k_strcpy(out, b, max);
}

static void reset(CalcState *c) { c->entry[0] = '0'; c->entry[1] = 0; c->elen = 1; c->acc = 0; c->op = 0; c->fresh = 1; c->expr[0] = 0; c->err = 0; }
static void calc_init(Window *w, const char *arg) { (void)arg; reset(&w->u.calc); w->u.calc.hot = -1; }

static int apply(CalcState *c, int a, int op, int b) {
    int r = 0, ovf = 0;
    if (op == '+') { if (__builtin_add_overflow(a, b, &r)) ovf = 1; }
    else if (op == '-') { if (__builtin_sub_overflow(a, b, &r)) ovf = 1; }
    else if (op == '*') r = muldiv(a, b, 1000, &ovf);
    else if (op == '/') { if (b == 0) { c->err = 1; return 0; } r = muldiv(a, 1000, b, &ovf); }
    else r = b;
    if (ovf) c->err = 2;
    return r;
}
static void show(CalcState *c, int v) { fmt(v, c->entry, sizeof c->entry); c->elen = k_strlen(c->entry); }

static void press(CalcState *c, const char *k) {
    char ch = k[0];
    if (c->err && ch != 'C') { reset(c); }
    if (ch >= '0' && ch <= '9') {
        if (c->fresh) { c->entry[0] = 0; c->elen = 0; c->fresh = 0; }
        if (c->elen == 1 && c->entry[0] == '0') c->elen = 0;
        if (c->elen < 11) { c->entry[c->elen++] = ch; c->entry[c->elen] = 0; }
    } else if (ch == '.') {
        if (c->fresh) { k_strcpy(c->entry, "0", sizeof c->entry); c->elen = 1; c->fresh = 0; }
        int has = 0; for (int i = 0; i < c->elen; i++) if (c->entry[i] == '.') has = 1;
        if (!has && c->elen < 11) { c->entry[c->elen++] = '.'; c->entry[c->elen] = 0; }
    } else if (ch == 'C') reset(c);
    else if (ch == '<') {
        if (!c->fresh && c->elen > 0) { c->entry[--c->elen] = 0; if (c->elen == 0 || (c->elen == 1 && c->entry[0] == '-')) { k_strcpy(c->entry, "0", sizeof c->entry); c->elen = 1; } }
    } else if (ch == '+' && k[1] == '/') {
        if (c->entry[0] == '-') { k_memmove(c->entry, c->entry + 1, (unsigned)c->elen); c->elen--; }
        else if (!(c->elen == 1 && c->entry[0] == '0') && c->elen < 11) { k_memmove(c->entry + 1, c->entry, (unsigned)c->elen + 1); c->entry[0] = '-'; c->elen++; }
    } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '=') {
        int v = parse(c->entry);
        if (c->op && !c->fresh) { c->acc = apply(c, c->acc, c->op, v); }
        else if (!c->op) c->acc = v;
        if (c->err) { k_strcpy(c->expr, "", sizeof c->expr); return; }
        show(c, c->acc);
        if (ch == '=') { c->op = 0; c->expr[0] = 0; }
        else { c->op = ch; char t[24]; fmt(c->acc, t, sizeof t); k_snprintf(c->expr, sizeof c->expr, "%s %c", t, ch); }
        c->fresh = 1;
    }
}

static void cell(int cw, int ch, int r, int col, int *x, int *y, int *w, int *h) {
    int gh = ch - DISP_H - 12, gw = cw - 24;
    *w = (gw - 3 * 8) / 4; *h = (gh - 4 * 8) / 5;
    *x = 12 + col * (*w + 8); *y = DISP_H + r * (*h + 8);
}
static int hit(Window *w, int x, int y) {
    int cw = w->w - 2, ch = w->h - TB_H - 1;
    for (int r = 0; r < 5; r++) for (int c = 0; c < 4; c++) {
        int bx, by, bw, bh; cell(cw, ch, r, c, &bx, &by, &bw, &bh);
        if (r == 4 && c == 0) bw = bw * 2 + 8;
        if (r == 4 && c == 1) continue;
        if (ui_inside(x, y, bx, by, bw, bh)) return r * 4 + c;
    }
    return -1;
}
static void calc_mouse(Window *w, int x, int y, int ev, int clicks) {
    (void)clicks;
    CalcState *c = &w->u.calc;
    int h = hit(w, x, y);
    if (ev == EV_MOVE) { if (h != c->hot) { c->hot = h; win_invalidate(w); } }
    else if (ev == EV_DOWN && h >= 0) { press(c, keys[h / 4][h % 4]); win_invalidate(w); }
}
static void calc_key(Window *w, int key, int mods) {
    CalcState *c = &w->u.calc;
    (void)mods;
    char k[2] = { 0, 0 };
    if ((key >= '0' && key <= '9') || key == '.' || key == '+' || key == '-' || key == '*' || key == '/') k[0] = (char)key;
    else if (key == KEY_ENTER || key == '=') k[0] = '=';
    else if (key == KEY_BACKSPACE) k[0] = '<';
    else if (key == KEY_ESC || key == 'c' || key == 'C') k[0] = 'C';
    else return;
    press(c, k); win_invalidate(w);
}

static void symbol(const char *k, int cx, int cy, u32 col) {
    char ch = k[0];
    if (ch == '+' && k[1] == '/') { gfx_text_center(&font_uib, cx - 20, cy - 12, 40, 24, "+/-", col); return; }
    if (ch == '+') { gfx_line(cx - 7, cy, cx + 7, cy, 36, col, 255); gfx_line(cx, cy - 7, cx, cy + 7, 36, col, 255); }
    else if (ch == '-') gfx_line(cx - 7, cy, cx + 7, cy, 36, col, 255);
    else if (ch == '*') { gfx_line(cx - 6, cy - 6, cx + 6, cy + 6, 36, col, 255); gfx_line(cx - 6, cy + 6, cx + 6, cy - 6, 36, col, 255); }
    else if (ch == '/') { gfx_line(cx - 7, cy, cx + 7, cy, 36, col, 255); gfx_circle(cx, cy - 7, 2, col, 255); gfx_circle(cx, cy + 7, 2, col, 255); }
    else if (ch == '=') { gfx_line(cx - 7, cy - 3, cx + 7, cy - 3, 36, col, 255); gfx_line(cx - 7, cy + 4, cx + 7, cy + 4, 36, col, 255); }
    else if (ch == '<') { gfx_line(cx + 8, cy, cx - 6, cy, 30, col, 255); gfx_line(cx - 6, cy, cx - 1, cy - 5, 30, col, 255); gfx_line(cx - 6, cy, cx - 1, cy + 5, 30, col, 255); }
    else gfx_text_center(&font_big, cx - 20, cy - 20, 40, 40, k, col);
}

static void calc_draw(Window *w, int x, int y, int cw, int ch) {
    CalcState *c = &w->u.calc;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    gfx_round(x + 12, y + 12, cw - 24, DISP_H - 24, 8, CORNER_ALL, theme.field, 255);
    gfx_text_right(&font_ui, x + cw - 24, y + 20, c->expr, theme.dim);
    const char *v = c->err == 1 ? "Cannot divide by zero" : c->err == 2 ? "Overflow" : c->entry;
    const Font *f = &font_big;
    if (gfx_text_w(f, v) > cw - 60) f = &font_uib;
    gfx_text_right(f, x + cw - 24, y + 12 + (DISP_H - 24 - f->height) / 2 + 8, v, theme.text);
    for (int r = 0; r < 5; r++) for (int col = 0; col < 4; col++) {
        if (r == 4 && col == 1) continue;
        int bx, by, bw, bh; cell(cw, ch, r, col, &bx, &by, &bw, &bh);
        if (r == 4 && col == 0) bw = bw * 2 + 8;
        const char *k = keys[r][col];
        int isop = (col == 3), isclr = (r == 0 && col < 3), isdig = !isop && !isclr;
        int hot = c->hot == r * 4 + col || (r == 4 && col == 0 && c->hot == 17);
        u32 bg = isop ? (k[0] == '=' ? theme.accent : theme.hover) : isclr ? theme.win_alt : theme.field;
        if (hot) bg = gfx_lerp(bg, 0xFFFFFF, theme.dark ? 24 : 50);
        gfx_round_border(bx + x, by + y, bw, bh, 8, bg, theme.border);
        u32 fg = (k[0] == '=') ? theme.accent_text : (isop ? theme.accent : theme.text);
        if (!theme.dark && isop && k[0] != '=') fg = theme.accent_dk;
        (void)isdig;
        symbol(k, bx + x + bw / 2, by + y + bh / 2, fg);
    }
}

const AppDesc app_calc = {
    "Calculator", "Basic arithmetic", ICON_CALC, 340, 500, 280, 400,
    calc_init, calc_draw, calc_mouse, calc_key, NULL
};
