#ifndef HW_H
#define HW_H
#include "types.h"
/* Platform services. kernel/kmain.c implements them on real/emulated hardware,
   host/host.c implements them for the screenshot test harness. */
typedef struct HwTime_ { int year, mon, day, hour, min, sec, wday; } HwTime;
u32  hw_ms(void);                       /* monotonic milliseconds */
void hw_time(HwTime *t);                /* wall clock (RTC) */
void hw_poweroff(void);
void hw_reboot(void);
void hw_cpu_brand(char *out, int max);
u32  hw_mem_kb(void);                   /* 0 if unknown */
/* ---- network interface card (implemented by kernel/e1000.c, or the host harness) ---- */
int  hw_nic_init(u8 mac[6]);                 /* 1 if a supported NIC was found and started */
int  hw_nic_send(const u8 *frame, int len);  /* raw Ethernet frame (no FCS); 1 on success */
int  hw_nic_recv(u8 *buf, int max);          /* length of a received frame, or 0 if none pending */
const char *hw_nic_name(void);
/* ---- persistent disk (ATA PIO on the primary IDE channel; absent on CD / USB boots) ---- */
int  hw_disk_init(u32 *sectors);                       /* 1 if a writable disk was found */
int  hw_disk_read(u32 lba, int n, void *buf);          /* 512-byte sectors; 1 on success */
int  hw_disk_write(u32 lba, int n, const void *buf);   /* 1 on success */
#endif
