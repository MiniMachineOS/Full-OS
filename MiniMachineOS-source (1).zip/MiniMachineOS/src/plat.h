#ifndef PLAT_H
#define PLAT_H
#include "types.h"
/* Hardware access used by the NIC drivers. kernel/plat.c implements it with real port I/O and MMIO;
   host/nicmodels.c implements it against software models of the network cards so driver logic can be tested. */
u8   io_in8(u16 p);   u16 io_in16(u16 p);   u32 io_in32(u16 p);
void io_out8(u16 p, u8 v); void io_out16(u16 p, u16 v); void io_out32(u16 p, u32 v);
void io_ins16(u16 p, void *buf, int words);
void io_outs16(u16 p, const void *buf, int words);
u8   mm_in8(u32 a);   u16 mm_in16(u32 a);   u32 mm_in32(u32 a);
void mm_out8(u32 a, u8 v); void mm_out16(u32 a, u16 v); void mm_out32(u32 a, u32 v);
u32  pci_read32(int bus, int dev, int fn, int off);
void pci_write32(int bus, int dev, int fn, int off, u32 v);
u32  dma_addr(const void *p);                 /* bus address of a buffer (identity-mapped in the kernel) */
void delay_ms(u32 ms);
#define BARRIER() __asm__ volatile("" ::: "memory")
#endif
