/* icons.c - procedurally drawn app icons (no image assets needed) */
#include "app.h"
#include "klib.h"

#define S(v) ((v) * s / 48)

static void rr(int s, int x, int y, int ix, int iy, int iw, int ih, int r, int corners, u32 c) {
    gfx_round(x + S(ix), y + S(iy), k_max(1, S(iw)), k_max(1, S(ih)), S(r), corners, c, 255);
}
static void ln(int s, int x, int y, int x0, int y0, int x1, int y1, int w, u32 c) {
    gfx_line(x + S(x0), y + S(y0), x + S(x1), y + S(y1), k_max(14, S(w) * 16), c, 255);
}

void icon_draw(int kind, int x, int y, int s) {
    if (!gfx_visible(x, y, s, s)) return;
    switch (kind) {
    case ICON_FILES:
        rr(s, x, y, 4, 8, 20, 12, 4, CORNER_TOP, 0xC9972B);
        rr(s, x, y, 4, 12, 40, 30, 4, CORNER_ALL, 0xE0AE3C);
        rr(s, x, y, 4, 19, 40, 23, 4, CORNER_ALL, 0xF7C95A);
        gfx_fill(x + S(6), y + S(20), S(36), k_max(1, S(1)), 0xFFE39A);
        break;
    case ICON_TERM:
        rr(s, x, y, 3, 5, 42, 38, 6, CORNER_ALL, 0x1F2226);
        rr(s, x, y, 3, 5, 42, 8, 6, CORNER_TOP, 0x3A3F46);
        gfx_fill(x + S(3), y + S(11), S(42), k_max(1, S(2)), 0x3A3F46);
        ln(s, x, y, 11, 19, 19, 26, 3, 0x7EE787);
        ln(s, x, y, 19, 26, 11, 33, 3, 0x7EE787);
        rr(s, x, y, 23, 32, 13, 3, 1, 0, 0xD6DADF);
        break;
    case ICON_EDIT:
        rr(s, x, y, 8, 3, 32, 42, 4, CORNER_ALL, 0xF2F3F5);
        rr(s, x, y, 8, 3, 32, 10, 4, CORNER_TOP, 0x3584E4);
        rr(s, x, y, 13, 19, 22, 2, 1, 0, 0x9AA0A6);
        rr(s, x, y, 13, 25, 22, 2, 1, 0, 0x9AA0A6);
        rr(s, x, y, 13, 31, 22, 2, 1, 0, 0x9AA0A6);
        rr(s, x, y, 13, 37, 14, 2, 1, 0, 0x9AA0A6);
        break;
    case ICON_CALC:
        rr(s, x, y, 7, 3, 34, 42, 5, CORNER_ALL, 0x3C4048);
        rr(s, x, y, 11, 7, 26, 10, 2, CORNER_ALL, 0xA3D98F);
        for (int j = 0; j < 4; j++)
            for (int i = 0; i < 3; i++)
                rr(s, x, y, 11 + i * 9, 21 + j * 6, 8, 5, 1, CORNER_ALL, (i == 2) ? 0xF39C34 : 0xD3D7DD);
        break;
    case ICON_SETTINGS: {
        static const int dx[8] = {1000, 707, 0, -707, -1000, -707, 0, 707};
        static const int dy[8] = {0, 707, 1000, 707, 0, -707, -1000, -707};
        int cx = x + s / 2, cy = y + s / 2;
        for (int i = 0; i < 8; i++)
            gfx_line(cx + S(10) * dx[i] / 1000, cy + S(10) * dy[i] / 1000,
                     cx + S(18) * dx[i] / 1000, cy + S(18) * dy[i] / 1000, k_max(24, S(7) * 16), 0xA9B1BC, 255);
        gfx_circle(cx, cy, S(15), 0xA9B1BC, 255);
        gfx_circle(cx, cy, S(6), 0x59606B, 255);
        break; }
    case ICON_ABOUT:
        rr(s, x, y, 3, 7, 42, 28, 4, CORNER_ALL, 0x3A3F47);
        rr(s, x, y, 6, 10, 36, 22, 2, CORNER_ALL, 0x3584E4);
        gfx_fill(x + S(6), y + S(21), S(36), S(11), 0x2A6BC4);
        gfx_circle(x + S(24), y + S(16), S(4), 0xFFFFFF, 255);
        rr(s, x, y, 21, 21, 6, 8, 1, 0, 0xFFFFFF);
        rr(s, x, y, 20, 35, 8, 5, 0, 0, 0x6B727C);
        rr(s, x, y, 13, 40, 22, 3, 1, CORNER_ALL, 0x8A919C);
        break;
    case ICON_FILE:
        rr(s, x, y, 9, 3, 30, 42, 3, CORNER_ALL, 0xF4F5F7);
        rr(s, x, y, 29, 3, 10, 10, 2, CORNER_TR, 0xC9CED6);
        rr(s, x, y, 14, 20, 20, 2, 1, 0, 0xA2A8B1);
        rr(s, x, y, 14, 26, 20, 2, 1, 0, 0xA2A8B1);
        rr(s, x, y, 14, 32, 13, 2, 1, 0, 0xA2A8B1);
        break;
    case ICON_BROWSER:
        gfx_circle(x + s / 2, y + s / 2, S(21), 0x2F7BEA, 255);
        gfx_circle(x + s / 2, y + s / 2, S(18), 0x5BA3FF, 255);
        gfx_circle(x + s / 2, y + s / 2, S(16), 0x2F7BEA, 255);
        ln(s, x, y, 24, 6, 24, 42, 2, 0xE8F1FF);
        ln(s, x, y, 7, 24, 41, 24, 2, 0xE8F1FF);
        ln(s, x, y, 11, 14, 37, 14, 2, 0xE8F1FF);
        ln(s, x, y, 11, 34, 37, 34, 2, 0xE8F1FF);
        gfx_circle(x + S(24), y + S(24), S(9), 0x2F7BEA, 0);
        break;
    case ICON_STORE:
        rr(s, x, y, 7, 14, 34, 30, 5, CORNER_ALL, 0x3584E4);
        rr(s, x, y, 7, 14, 34, 9, 5, CORNER_TOP, 0x2A6BC4);
        gfx_line(x + S(16), y + S(14), x + S(16), y + S(8), 60, 0xE8F1FF, 255);
        gfx_line(x + S(32), y + S(14), x + S(32), y + S(8), 60, 0xE8F1FF, 255);
        gfx_line(x + S(16), y + S(8), x + S(32), y + S(8), 60, 0xE8F1FF, 255);
        gfx_circle(x + S(24), y + S(30), S(7), 0xFFFFFF, 255);
        gfx_line(x + S(24), y + S(26), x + S(24), y + S(34), 50, 0x3584E4, 255);
        gfx_line(x + S(20), y + S(30), x + S(24), y + S(34), 50, 0x3584E4, 255);
        gfx_line(x + S(28), y + S(30), x + S(24), y + S(34), 50, 0x3584E4, 255);
        break;
    case ICON_SNAKE:
        rr(s, x, y, 4, 4, 40, 40, 8, CORNER_ALL, 0x1E2B22);
        ln(s, x, y, 12, 34, 12, 14, 7, 0x71B04C); ln(s, x, y, 12, 14, 26, 14, 7, 0x71B04C);
        ln(s, x, y, 26, 14, 26, 30, 7, 0x71B04C); ln(s, x, y, 26, 30, 36, 30, 7, 0x9BDB6B);
        gfx_circle(x + S(36), y + S(30), S(5), 0x9BDB6B, 255); gfx_circle(x + S(37), y + S(29), S(1) + 1, 0x101010, 255);
        gfx_circle(x + S(34), y + S(12), S(4), 0xE5484D, 255);
        break;
    case ICON_MINES:
        rr(s, x, y, 4, 4, 40, 40, 8, CORNER_ALL, 0x5B6470);
        rr(s, x, y, 7, 7, 15, 15, 3, CORNER_ALL, 0x9AA3AF); rr(s, x, y, 26, 7, 15, 15, 3, CORNER_ALL, 0x9AA3AF);
        rr(s, x, y, 7, 26, 15, 15, 3, CORNER_ALL, 0x9AA3AF);
        gfx_circle(x + S(33), y + S(33), S(7), 0x202020, 255);
        ln(s, x, y, 24, 33, 42, 33, 3, 0x202020); ln(s, x, y, 33, 24, 33, 42, 3, 0x202020);
        ln(s, x, y, 14, 9, 14, 20, 2, 0x303030); rr(s, x, y, 14, 9, 7, 6, 1, 0, 0xE5484D);
        break;
    case ICON_2048:
        rr(s, x, y, 4, 4, 40, 40, 8, CORNER_ALL, 0x8F7A66);
        rr(s, x, y, 8, 8, 15, 15, 3, CORNER_ALL, 0xF2B179); rr(s, x, y, 25, 8, 15, 15, 3, CORNER_ALL, 0xF65E3B);
        rr(s, x, y, 8, 25, 15, 15, 3, CORNER_ALL, 0xEDCF72); rr(s, x, y, 25, 25, 15, 15, 3, CORNER_ALL, 0xEEE4DA);
        break;
    case ICON_TTT:
        rr(s, x, y, 4, 4, 40, 40, 8, CORNER_ALL, 0x2B2D31);
        ln(s, x, y, 18, 9, 18, 39, 2, 0x70757A); ln(s, x, y, 30, 9, 30, 39, 2, 0x70757A);
        ln(s, x, y, 9, 18, 39, 18, 2, 0x70757A); ln(s, x, y, 9, 30, 39, 30, 2, 0x70757A);
        ln(s, x, y, 10, 10, 16, 16, 3, theme.accent); ln(s, x, y, 16, 10, 10, 16, 3, theme.accent);
        gfx_circle(x + S(24), y + S(24), S(5), 0xE8EAED, 255); gfx_circle(x + S(24), y + S(24), S(3), 0x2B2D31, 255);
        ln(s, x, y, 32, 32, 38, 38, 3, theme.accent); ln(s, x, y, 38, 32, 32, 38, 3, theme.accent);
        break;
    case ICON_PAINT:
        gfx_circle(x + s / 2, y + s / 2, S(21), 0xE8D5B5, 255);
        gfx_circle(x + S(16), y + S(18), S(4), 0xE5484D, 255); gfx_circle(x + S(26), y + S(13), S(4), 0xF5D90A, 255);
        gfx_circle(x + S(35), y + S(21), S(4), 0x3FB950, 255); gfx_circle(x + S(33), y + S(32), S(4), 0x3584E4, 255);
        gfx_circle(x + S(21), y + S(34), S(5), 0xF4F0E6, 255);
        break;
    case ICON_CLOCK:
        gfx_circle(x + s / 2, y + s / 2, S(21), 0x3A3F47, 255); gfx_circle(x + s / 2, y + s / 2, S(18), 0xF4F5F7, 255);
        ln(s, x, y, 24, 24, 24, 11, 3, 0x202124); ln(s, x, y, 24, 24, 34, 28, 3, 0x202124); ln(s, x, y, 24, 24, 14, 32, 2, 0xE5484D);
        gfx_circle(x + s / 2, y + s / 2, S(2) + 1, 0xE5484D, 255);
        break;
    case ICON_LOGO:
        gfx_circle(x + s / 2, y + s / 2, s / 2, theme.accent, 255);
        ln(s, x, y, 14, 33, 14, 15, 4, 0xFFFFFF);
        ln(s, x, y, 14, 15, 24, 26, 4, 0xFFFFFF);
        ln(s, x, y, 24, 26, 34, 15, 4, 0xFFFFFF);
        ln(s, x, y, 34, 15, 34, 33, 4, 0xFFFFFF);
        break;
    }
}
