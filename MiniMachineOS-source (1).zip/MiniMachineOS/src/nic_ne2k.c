/* nic_ne2k.c - NE2000-compatible PCI cards (Realtek RTL8029, QEMU `-nic model=ne2k_pci`, v86's NIC).
   NOT yet verified against a device model. */
#include "nic.h"
#include "plat.h"
#include "klib.h"

#define PSTART 0x46
#define PSTOP 0x80
#define TXPAGE 0x40
static u16 io; static int ready, next_pkt;

#define CR 0x00
#define ISR 0x07
static void cr(u8 v) { io_out8((u16)(io + CR), v); }
static void rdma_setup(u16 addr, u16 len, u8 cmd) {
    io_out8((u16)(io + 0x08), (u8)addr); io_out8((u16)(io + 0x09), (u8)(addr >> 8));
    io_out8((u16)(io + 0x0A), (u8)len); io_out8((u16)(io + 0x0B), (u8)(len >> 8));
    cr(cmd);
}
static void rdma_wait(void) { for (int i = 0; i < 100000; i++) if (io_in8((u16)(io + ISR)) & 0x40) break; io_out8((u16)(io + ISR), 0x40); }
static void rdma_read(u16 addr, u8 *dst, int len) {
    rdma_setup(addr, (u16)len, 0x0A);
    int words = len / 2; if (words) io_ins16((u16)(io + 0x10), dst, words);
    if (len & 1) { u16 w = io_in16((u16)(io + 0x10)); dst[len - 1] = (u8)w; }
    rdma_wait();
}

static int match(u16 v, u16 d) { return (v == 0x10EC && d == 0x8029) || (v == 0x1050 && d == 0x0940) || (v == 0x11F6 && d == 0x1401); }

static int init(const PciInfo *p, u8 mac[6]) {
    u32 bar = p->bar[0];
    if (!(bar & 1)) return 0;
    io = (u16)(bar & ~3u);
    u8 r = io_in8((u16)(io + 0x1F)); io_out8((u16)(io + 0x1F), r);     /* reset port */
    int ok = 0; for (int i = 0; i < 1000; i++) { if (io_in8((u16)(io + ISR)) & 0x80) { ok = 1; break; } delay_ms(1); }
    if (!ok) return 0;
    io_out8((u16)(io + ISR), 0xFF);
    cr(0x21);                                                         /* stop, page 0 */
    io_out8((u16)(io + 0x0E), 0x49);                                  /* DCR: word transfers, FIFO 8 */
    io_out8((u16)(io + 0x0A), 0); io_out8((u16)(io + 0x0B), 0);
    io_out8((u16)(io + 0x0C), 0x20); io_out8((u16)(io + 0x0D), 0x02); /* monitor mode, loopback while configuring */
    u8 prom[32]; rdma_read(0, prom, 32);
    for (int i = 0; i < 6; i++) mac[i] = prom[i * 2];
    if ((mac[0] | mac[1] | mac[2] | mac[3] | mac[4] | mac[5]) == 0) return 0;
    io_out8((u16)(io + 0x01), PSTART); io_out8((u16)(io + 0x02), PSTOP); io_out8((u16)(io + 0x03), PSTART);
    io_out8((u16)(io + 0x04), TXPAGE);
    cr(0x61);                                                         /* page 1 */
    for (int i = 0; i < 6; i++) io_out8((u16)(io + 0x01 + i), mac[i]);
    io_out8((u16)(io + 0x07), PSTART + 1);                            /* CURR */
    for (int i = 0; i < 8; i++) io_out8((u16)(io + 0x08 + i), 0);
    cr(0x21);                                                         /* page 0 */
    io_out8((u16)(io + 0x0C), 0x04);                                  /* RCR: accept broadcast */
    io_out8((u16)(io + 0x0D), 0x00);                                  /* TCR: normal */
    io_out8((u16)(io + ISR), 0xFF); io_out8((u16)(io + 0x0F), 0);
    cr(0x22);                                                         /* start */
    next_pkt = PSTART + 1; ready = 1;
    return 1;
}

static int send(const u8 *f, int len) {
    if (!ready || len <= 0 || len > 1514) return 0;
    for (int i = 0; i < 100000 && (io_in8((u16)(io + CR)) & 0x04); i++) { }          /* previous TX still running */
    u8 pad[1514]; int n = len;
    k_memcpy(pad, f, (unsigned)len);
    if (n < 60) { k_memset(pad + n, 0, (unsigned)(60 - n)); n = 60; }
    rdma_setup((u16)(TXPAGE << 8), (u16)n, 0x12);
    io_outs16((u16)(io + 0x10), pad, (n + 1) / 2);
    rdma_wait();
    io_out8((u16)(io + 0x04), TXPAGE); io_out8((u16)(io + 0x05), (u8)n); io_out8((u16)(io + 0x06), (u8)(n >> 8));
    cr(0x26);                                                         /* transmit */
    return 1;
}

static int recv(u8 *buf, int max) {
    if (!ready) return 0;
    cr(0x62); u8 curr = io_in8((u16)(io + 0x07)); cr(0x22);           /* CURR lives in page 1 */
    if (next_pkt == curr) return 0;
    u8 hdr[4]; rdma_read((u16)(next_pkt << 8), hdr, 4);
    int total = hdr[2] | (hdr[3] << 8), n = 0;
    int next = hdr[1];
    if ((hdr[0] & 1) && total >= 64 && total <= 1518 + 4 && next >= PSTART && next < PSTOP) {
        n = total - 4; if (n > max) n = max;
        u16 a = (u16)((next_pkt << 8) + 4), end = (u16)(PSTOP << 8);
        if (a + n > end) {                                            /* frame wraps around the ring */
            int first = end - a; rdma_read(a, buf, first); rdma_read((u16)(PSTART << 8), buf + first, n - first);
        } else rdma_read(a, buf, n);
        next_pkt = next;
    } else {                                                          /* corrupt header: drop everything queued */
        cr(0x62); next_pkt = io_in8((u16)(io + 0x07)); cr(0x22);
    }
    int bn = next_pkt - 1; if (bn < PSTART) bn = PSTOP - 1;
    io_out8((u16)(io + 0x03), (u8)bn);                                /* BNRY */
    return n;
}

const NicDrv drv_ne2k = { "NE2000 PCI (RTL8029)", match, init, send, recv };
