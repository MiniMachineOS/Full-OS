/* account.c - account, installed apps, settings and filesystem persistence */
#include "account.h"
#include "app.h"
#include "hw.h"
#include "klib.h"
#include "sha256.h"

#define DATA_LBA 2048
#define DATA_SECTORS 2048
#define MAGIC 0x534F4D4Du      /* "MMOS" */
#define VERSION 2

typedef struct {
    u32 magic, version;
    char user[24];
    u8 salt[16], hash[32];
    u32 installed, cfg;          /* cfg: bit0 dark, bits 8..11 accent, bits 16..19 wallpaper */
    u32 vfs_len, vfs_crc;
    u8 pad[512 - 4 - 4 - 24 - 16 - 32 - 4 - 4 - 4 - 4];
} Cfg;

static Cfg cfg;
static int have_acct, disk_ok;
static u32 entropy, entropy_n;
static u8 snap[16 + 96 * 64 + 100 * 1024 + 4096];     /* staging buffer for filesystem snapshots */

void entropy_add(u32 v) { entropy = (entropy * 1664525u + 1013904223u) ^ v ^ (entropy >> 15); entropy_n++; }
int persist_disk(void) { return disk_ok; }
int acct_exists(void) { return have_acct; }
const char *acct_name(void) { return cfg.user; }

int app_installed(int app) {
    if (app < 0 || app >= APP_COUNT) return 0;
    if (apps[app]->category == 0) return 1;
    return (cfg.installed >> app) & 1;
}
void app_set_installed(int app, int on) {
    if (apps[app]->category == 0) return;
    if (on) cfg.installed |= 1u << app; else cfg.installed &= ~(1u << app);
    persist_save_config();
}

static void cfg_pack(void) { cfg.cfg = (u32)(cfg_dark ? 1 : 0) | ((u32)cfg_accent << 8) | ((u32)cfg_wall << 16); }
static void cfg_apply(void) {
    cfg_dark = cfg.cfg & 1; cfg_accent = (int)((cfg.cfg >> 8) & 15); cfg_wall = (int)((cfg.cfg >> 16) & 15);
    if (cfg_accent >= N_ACCENTS) cfg_accent = 0;
    if (cfg_wall >= N_WALLS) cfg_wall = 0;
    theme_apply();
}

void persist_save_config(void) {
    if (!have_acct) return;
    cfg_pack();
    if (disk_ok) hw_disk_write(DATA_LBA, 1, &cfg);
}

static void flush_vfs(void) {
    int n = vfs_snapshot(snap, sizeof snap);
    if (n < 0) return;
    int secs = (n + 511) / 512;
    if (secs > DATA_SECTORS - 1) return;
    k_memset(snap + n, 0, (unsigned)(secs * 512 - n));
    if (!hw_disk_write(DATA_LBA + 1, secs, snap)) return;
    cfg.vfs_len = (u32)n; cfg.vfs_crc = k_crc32(snap, n);
    vfs_dirty = 0;
    persist_save_config();
}

void persist_tick(u32 now) {
    if (disk_ok && have_acct && vfs_dirty && now - vfs_dirty_ms > 2000) flush_vfs();
}

void persist_init(void) {
    u32 sectors = 0;
    k_memset(&cfg, 0, sizeof cfg);
    disk_ok = hw_disk_init(&sectors) && sectors >= DATA_LBA + DATA_SECTORS;
    if (!disk_ok) return;
    Cfg c;
    if (!hw_disk_read(DATA_LBA, 1, &c) || c.magic != MAGIC || c.version != VERSION || !c.user[0]) return;
    c.user[23] = 0;
    cfg = c; have_acct = 1;
    cfg_apply();
    vfs_set_user(cfg.user);
    int ok = 0;
    if (cfg.vfs_len > 0 && cfg.vfs_len <= sizeof snap) {
        int secs = ((int)cfg.vfs_len + 511) / 512;
        if (hw_disk_read(DATA_LBA + 1, secs, snap) && k_crc32(snap, (int)cfg.vfs_len) == cfg.vfs_crc)
            ok = (vfs_restore(snap, (int)cfg.vfs_len) == 0);
    }
    if (!ok) vfs_init(cfg.user);
}

int acct_create(const char *user, const char *pass) {
    int ul = k_strlen(user), pl = k_strlen(pass);
    if (ul < 1 || ul > ACCT_NAME_MAX) return 1;
    for (int i = 0; i < ul; i++) {
        char c = user[i];
        int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-';
        if (!ok || (i == 0 && !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')))) return 1;
    }
    if (pl < ACCT_PASS_MIN || pl > ACCT_PASS_MAX) return 2;
    HwTime t; hw_time(&t);
    u8 seed[32]; u32 mix[8] = { entropy, entropy_n, hw_ms(), (u32)(t.sec | t.min << 8 | t.hour << 16), (u32)t.day, 0, 0, 0 };
    k_memcpy(seed, mix, 32);
    u8 d[32]; sha256(seed, 32, d);
    k_memset(&cfg, 0, sizeof cfg);
    cfg.magic = MAGIC; cfg.version = VERSION;
    k_strcpy(cfg.user, user, sizeof cfg.user);
    k_memcpy(cfg.salt, d, 16);
    pw_hash(pass, cfg.salt, cfg.hash);
    have_acct = 1;
    vfs_init(cfg.user);
    persist_save_config();
    return 0;
}

int acct_check(const char *pass) {
    if (!have_acct) return 0;
    u8 h[32]; pw_hash(pass, cfg.salt, h);
    int diff = 0; for (int i = 0; i < 32; i++) diff |= h[i] ^ cfg.hash[i];
    k_memset(h, 0, sizeof h);
    return diff == 0;
}
