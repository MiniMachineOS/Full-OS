#ifndef VFS_H
#define VFS_H
#include "types.h"
/* A small in-memory filesystem (there is no disk driver yet). */
#define VFS_MAX 96
#define VFS_NAME 28
void vfs_init(const char *user);                           /* fresh tree with /home/<user> */
int  vfs_home(void);
void vfs_set_user(const char *u);
extern int vfs_dirty; extern u32 vfs_dirty_ms;             /* changed since the last snapshot? */
int  vfs_snapshot(u8 *buf, int max);                       /* serialise; returns length or -1 */
int  vfs_restore(const u8 *buf, int len);                  /* 0 on success */
int  vfs_root(void);
int  vfs_find(int parent, const char *name);              /* child by name or -1 */
int  vfs_resolve(int cwd, const char *path);              /* absolute/relative, supports . and .. */
int  vfs_create(int parent, const char *name, int is_dir);/* returns node or -1 */
int  vfs_write(int node, const char *data, int len);      /* returns 0 / -1 */
const char *vfs_data(int node, int *len);
int  vfs_remove(int node);                                /* files, or empty dirs */
int  vfs_is_dir(int node);
int  vfs_parent(int node);
const char *vfs_name(int node);
void vfs_path(int node, char *out, int max);
int  vfs_list(int dir, int *out, int max);                /* children, dirs first, then A-Z */
int  vfs_size(int node);
#endif
