#ifndef SHA256_H
#define SHA256_H
#include "types.h"
void sha256(const u8 *data, u32 len, u8 out[32]);
void pw_hash(const char *pass, const u8 salt[16], u8 out[32]);
#endif
