/* nic_rtl8139.c - Realtek RTL8139 (QEMU rtl8139, many older/cheap cards) */
#include "nic.h"
#include "plat.h"
#include "klib.h"

#define RXLEN 8192
static u8 rxbuf[RXLEN + 16 + 1536 + 4] __attribute__((aligned(16)));
static u8 txbuf[4][2048] __attribute__((aligned(16)));
static u16 io;
static int rx_off, tx_cur, ready;

static int match(u16 v, u16 d) { return v == 0x10EC && d == 0x8139; }

static int init(const PciInfo *p, u8 mac[6]) {
    u32 bar = p->bar[0];
    if (!(bar & 1)) return 0;
    io = (u16)(bar & ~3u);
    io_out8((u16)(io + 0x52), 0);                                     /* CONFIG1: power on */
    io_out8((u16)(io + 0x37), 0x10);                                  /* software reset */
    int ok = 0; for (int i = 0; i < 1000; i++) { if (!(io_in8((u16)(io + 0x37)) & 0x10)) { ok = 1; break; } delay_ms(1); }
    if (!ok) return 0;
    for (int i = 0; i < 6; i++) mac[i] = io_in8((u16)(io + i));
    k_memset(rxbuf, 0, sizeof rxbuf);
    io_out32((u16)(io + 0x30), dma_addr(rxbuf));                      /* RBSTART */
    io_out16((u16)(io + 0x3C), 0);                                    /* no interrupts */
    io_out32((u16)(io + 0x44), 0xE78E);                               /* RCR: AB|AM|APM, WRAP, 8K ring, unlimited DMA */
    io_out32((u16)(io + 0x40), 0x03000600);                           /* TCR: IFG, DMA burst */
    io_out8((u16)(io + 0x37), 0x0C);                                  /* RE | TE */
    rx_off = 0; tx_cur = 0; ready = 1;
    return 1;
}

static int send(const u8 *f, int len) {
    if (!ready || len <= 0 || len > 1514) return 0;
    u16 tsd = (u16)(io + 0x10 + 4 * tx_cur);
    for (int i = 0; i < 100000 && !(io_in32(tsd) & (1u << 13)); i++) __asm__ volatile("pause");   /* OWN set = free */
    k_memcpy(txbuf[tx_cur], f, (unsigned)len);
    if (len < 60) { k_memset(txbuf[tx_cur] + len, 0, (unsigned)(60 - len)); len = 60; }
    io_out32((u16)(io + 0x20 + 4 * tx_cur), dma_addr(txbuf[tx_cur]));
    io_out32(tsd, (u32)len);                                          /* writing the length starts the DMA */
    tx_cur = (tx_cur + 1) & 3;
    return 1;
}

static int recv(u8 *buf, int max) {
    if (!ready) return 0;
    if (io_in8((u16)(io + 0x37)) & 1) return 0;                       /* BUFE: ring empty */
    u8 *h = rxbuf + rx_off;
    u16 status = (u16)(h[0] | (h[1] << 8)), len = (u16)(h[2] | (h[3] << 8));
    int n = 0;
    if ((status & 1) && len >= 8 && len <= 1518 + 4) {
        n = len - 4; if (n > max) n = max;
        k_memcpy(buf, h + 4, (unsigned)n);
    } else {                                                          /* bad frame: reset the receiver */
        io_out8((u16)(io + 0x37), 0x04); io_out8((u16)(io + 0x37), 0x0C);
        rx_off = 0; io_out16((u16)(io + 0x38), (u16)(0 - 16));
        return 0;
    }
    rx_off = (rx_off + len + 4 + 3) & ~3;
    if (rx_off >= RXLEN) rx_off -= RXLEN;
    io_out16((u16)(io + 0x38), (u16)(rx_off - 16));                   /* CAPR */
    io_out16((u16)(io + 0x3E), 0xFFFF);                               /* ack ISR */
    return n;
}

const NicDrv drv_rtl8139 = { "Realtek RTL8139", match, init, send, recv };
