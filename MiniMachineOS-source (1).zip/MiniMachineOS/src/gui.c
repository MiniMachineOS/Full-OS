/* gui.c - desktop shell: wallpaper, icons, taskbar, start menu, window manager */
#include "app.h"
#include "gui.h"
#include "klib.h"
#include "hw.h"
#include "net.h"
#include "account.h"

/* ====================================================================== */
/*  theme                                                                  */
/* ====================================================================== */
Theme theme;
int cfg_dark = 1, cfg_accent = 0, cfg_wall = 0;
const u32 accent_colors[N_ACCENTS] = { 0x71B04C, 0x3584E4, 0x9B59B6, 0xE9822B, 0xD9534F, 0x1FA2A6 };
const char *accent_names[N_ACCENTS] = { "Mint", "Blue", "Purple", "Orange", "Red", "Teal" };

typedef struct { const char *name; u32 top, bot, glow; int gx, gy; } Wall;
static const Wall walls[N_WALLS] = {
    { "Aurora", 0x0B1F2E, 0x105566, 0x2EC4B6, 72, 28 },
    { "Dusk",   0x1B1038, 0x7A2E6E, 0xF08A5D, 24, 72 },
    { "Meadow", 0x0F2B1D, 0x2F6B3B, 0xB5E48C, 74, 26 },
    { "Slate",  0x1D2128, 0x3D4656, 0x6C8EBF, 30, 30 },
    { "Ocean",  0x06142E, 0x0B5CAD, 0x4CC9F0, 68, 34 },
};
const char *wall_names[N_WALLS] = { "Aurora", "Dusk", "Meadow", "Slate", "Ocean" };

void theme_apply(void) {
    theme.dark = cfg_dark;
    if (cfg_dark) {
        theme.panel = 0x1B1D20; theme.panel_hover = 0x34373C; theme.win_bg = 0x2B2D31; theme.win_alt = 0x232528;
        theme.field = 0x1D1F22; theme.border = 0x45484E; theme.text = 0xE8EAED; theme.dim = 0x9AA0A6;
        theme.hover = 0x3A3D43; theme.title_act = 0x1F2124; theme.title_inact = 0x27292D;
    } else {
        theme.panel = 0xF1F2F4; theme.panel_hover = 0xDCDFE4; theme.win_bg = 0xFAFAFB; theme.win_alt = 0xEEF0F2;
        theme.field = 0xFFFFFF; theme.border = 0xC9CDD3; theme.text = 0x1F2328; theme.dim = 0x666C74;
        theme.hover = 0xE2E5E9; theme.title_act = 0xFFFFFF; theme.title_inact = 0xEDEEF0;
    }
    theme.accent = accent_colors[cfg_accent];
    theme.accent_dk = gfx_lerp(theme.accent, 0x000000, 70);
    theme.accent_text = 0xFFFFFF;
}

/* ====================================================================== */
/*  state                                                                  */
/* ====================================================================== */
#define MAX_WIN 10
#define TASKBAR_H 44
#define CAL_W 316
#define CAL_H 372
static Window wins[MAX_WIN];
static Window *zs[MAX_WIN];          /* z-order, bottom .. top */
static int nz;
int g_mx, g_my, g_blink;
static u32 now_ms;
static HwTime g_time;
static u32 last_time_poll;
static int prev_btn;
static u32 last_click_ms; static int last_cx, last_cy;

static int has_dmg; static Clip dmg;
static int cur_drawn, cur_x, cur_y;

/* popups */
static int sm_top;
static int sm_open, sm_sel, sm_hover = -1; static char sm_q[32]; static int sm_n; static int sm_items[APP_COUNT];
static int cal_open, cal_mon, cal_year, cal_hover = -1;
static int cm_open, cm_x, cm_y, cm_hover = -1;
static int sel_icon = -1;
static int hov_task = -1, hov_wb_win = -1, hov_wb = -1;

/* drag state */
static Window *drag_win, *cap_win;
static int drag_mode, drag_dx, drag_dy, drag_ox, drag_oy, drag_ow, drag_oh;
enum { DRAG_NONE, DRAG_MOVE, DRAG_RESIZE };
static int resize_r, resize_b;

static int tb_top(void) { return gfx_h - TASKBAR_H; }
static void ctxmenu_close(void);
static void cal_rect_(int *x, int *y);
u32 gui_now(void) { return now_ms; }
int ui_inside(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

/* ====================================================================== */
/*  damage / presentation                                                  */
/* ====================================================================== */
static void damage(int x, int y, int w, int h) {
    int x1 = x + w, y1 = y + h;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x1 > gfx_w) x1 = gfx_w;
    if (y1 > gfx_h) y1 = gfx_h;
    if (x >= x1 || y >= y1) return;
    if (!has_dmg) { dmg.x0 = x; dmg.y0 = y; dmg.x1 = x1; dmg.y1 = y1; has_dmg = 1; return; }
    if (x < dmg.x0) dmg.x0 = x;
    if (y < dmg.y0) dmg.y0 = y;
    if (x1 > dmg.x1) dmg.x1 = x1;
    if (y1 > dmg.y1) dmg.y1 = y1;
}
void gui_damage_all(void) { damage(0, 0, gfx_w, gfx_h); }
static void damage_win(Window *w) { damage(w->x - 24, w->y - 20, w->w + 48, w->h + 52); }
static void damage_taskbar(void) { damage(0, tb_top(), gfx_w, TASKBAR_H); }

void win_client(Window *w, int *x, int *y, int *cw, int *ch) {
    *x = w->x + 1; *y = w->y + TB_H; *cw = w->w - 2; *ch = w->h - TB_H - 1;
}
void win_invalidate(Window *w) {
    int x, y, cw, ch; win_client(w, &x, &y, &cw, &ch);
    damage(x, y, cw, ch);
}
void win_set_title(Window *w, const char *t) { k_strcpy(w->title, t, sizeof(w->title)); damage(w->x, w->y, w->w, TB_H); damage_taskbar(); }

/* ====================================================================== */
/*  small UI helpers for apps                                              */
/* ====================================================================== */
void ui_button(int x, int y, int w, int h, const char *label, int hot, int accent) {
    u32 bg, fg, bd;
    if (accent) { bg = hot ? gfx_lerp(theme.accent, 0xFFFFFF, 40) : theme.accent; fg = theme.accent_text; bd = theme.accent_dk; }
    else { bg = hot ? theme.hover : theme.win_alt; fg = theme.text; bd = theme.border; }
    gfx_round_border(x, y, w, h, 6, bg, bd);
    gfx_text_center(&font_ui, x, y, w, h, label, fg);
}
void ui_field(int x, int y, int w, int h) { gfx_round_border(x, y, w, h, 6, theme.field, theme.border); }

/* ====================================================================== */
/*  wallpaper                                                              */
/* ====================================================================== */
static void wallpaper_draw(void) {
    const Wall *wp = &walls[cfg_wall];
    Clip c = gfx_clip_get();
    for (int j = c.y0; j < c.y1; j++)
        gfx_fill(c.x0, j, c.x1 - c.x0, 1, gfx_lerp(wp->top, wp->bot, j * 256 / gfx_h));
    int R = gfx_h * 65 / 100, gcx = gfx_w * wp->gx / 100, gcy = gfx_h * wp->gy / 100, R2 = R * R;
    int y0 = k_max(c.y0, gcy - R), y1 = k_min(c.y1, gcy + R);
    int x0 = k_max(c.x0, gcx - R), x1 = k_min(c.x1, gcx + R);
    for (int j = y0; j < y1; j++) {
        int dy = j - gcy, dy2 = dy * dy;
        u32 *row = gfx_scene + j * gfx_w;
        for (int i = x0; i < x1; i++) {
            int dx = i - gcx, d2 = dx * dx + dy2;
            if (d2 >= R2) continue;
            int t = (R2 - d2) * 256 / R2;
            int a = (((t * t) >> 8) * 80) >> 8;
            if (a) row[i] = gfx_blend(row[i], wp->glow, (u32)a);
        }
    }
}

void wallpaper_thumb(int idx, int x, int y, int w, int h) {
    const Wall *wp = &walls[idx];
    Clip old = gfx_clip_push(x, y, w, h);
    gfx_vgrad(x, y, w, h, wp->top, wp->bot);
    int gx = x + w * wp->gx / 100, gy = y + h * wp->gy / 100;
    gfx_circle(gx, gy, h / 2, wp->glow, 70);
    gfx_circle(gx, gy, h / 4, wp->glow, 70);
    gfx_clip_set(old);
}

/* ====================================================================== */
/*  desktop icons                                                          */
/* ====================================================================== */
static int dic[APP_COUNT]; static int n_dicons;
static void dicons_refresh(void) {
    n_dicons = 0;
    for (int i = 0; i < APP_COUNT; i++) if (app_installed(i)) dic[n_dicons++] = i;
}
#define N_DICONS n_dicons
#define DI_W 96
#define DI_H 100
static void dicon_pos(int i, int *x, int *y) {
    int rows = k_max(1, (tb_top() - 16) / DI_H);
    *x = 16 + (i / rows) * (DI_W + 4);
    *y = 16 + (i % rows) * DI_H;
}
static void desktop_icons_draw(void) {
    for (int i = 0; i < N_DICONS; i++) {
        int x, y; dicon_pos(i, &x, &y);
        if (!gfx_visible(x, y, DI_W, DI_H)) continue;
        if (i == sel_icon) {
            gfx_round(x, y, DI_W, DI_H - 6, 8, CORNER_ALL, 0xFFFFFF, 46);
        }
        icon_draw(apps[dic[i]]->icon, x + (DI_W - 48) / 2, y + 8, 48);
        const char *l = apps[dic[i]]->name;
        int tw = gfx_text_w(&font_ui, l), tx = x + (DI_W - tw) / 2, ty = y + 64;
        gfx_text(&font_ui, tx + 1, ty + 1, l, 0x000000);
        gfx_text(&font_ui, tx, ty, l, 0xFFFFFF);
    }
}

/* ====================================================================== */
/*  windows                                                                */
/* ====================================================================== */
static Window *active_win(void) {
    for (int i = nz - 1; i >= 0; i--) if (!zs[i]->min) return zs[i];
    return NULL;
}
static void z_remove(Window *w) {
    int j = 0;
    for (int i = 0; i < nz; i++) if (zs[i] != w) zs[j++] = zs[i];
    nz = j;
}
static void win_focus(Window *w) {
    Window *a = active_win();
    if (w->min) { w->min = 0; damage_win(w); }
    if (a != w || zs[nz - 1] != w) {
        z_remove(w); zs[nz++] = w;
        damage_win(w);
        if (a) damage_win(a);
        damage_taskbar();
    }
}
void win_close(Window *w) {
    if (apps[w->app]->close) apps[w->app]->close(w);
    damage_win(w);
    z_remove(w);
    w->used = 0;
    if (cap_win == w) cap_win = NULL;
    if (drag_win == w) { drag_win = NULL; drag_mode = DRAG_NONE; }
    hov_wb_win = -1;
    damage_taskbar();
    Window *a = active_win();
    if (a) damage_win(a);
}
static void win_minimize(Window *w) { w->min = 1; damage_win(w); damage_taskbar(); Window *a = active_win(); if (a) damage_win(a); }
static void win_toggle_max(Window *w) {
    damage_win(w);
    if (!w->max) {
        w->rx = w->x; w->ry = w->y; w->rw = w->w; w->rh = w->h;
        w->x = 0; w->y = 0; w->w = gfx_w; w->h = tb_top(); w->max = 1;
    } else {
        w->x = w->rx; w->y = w->ry; w->w = w->rw; w->h = w->rh; w->max = 0;
    }
    damage_win(w);
}

Window *app_launch(int app, const char *arg) {
    if (!app_installed(app)) return NULL;
    if (apps[app]->single) {
        for (int i = 0; i < MAX_WIN; i++)
            if (wins[i].used && wins[i].app == app) {
                if (apps[app]->reopen) apps[app]->reopen(&wins[i], arg);
                win_focus(&wins[i]);
                return &wins[i];
            }
    }
    Window *w = NULL;
    for (int i = 0; i < MAX_WIN; i++) if (!wins[i].used) { w = &wins[i]; break; }
    if (!w) return NULL;
    const AppDesc *d = apps[app];
    static int cascade;
    k_memset(w, 0, sizeof(*w));
    w->used = 1; w->app = app;
    w->w = k_min(d->defw, gfx_w - 20); w->h = k_min(d->defh, tb_top() - 20);
    w->x = k_max(8, k_min(70 + (cascade % 7) * 32, gfx_w - w->w - 8));
    w->y = k_max(8, k_min(40 + (cascade % 7) * 32, tb_top() - w->h - 8));
    cascade++;
    k_strcpy(w->title, d->name, sizeof(w->title));
    if (d->init) d->init(w, arg);
    Window *prev = active_win();
    zs[nz++] = w;
    damage_win(w); damage_taskbar();
    if (prev) damage_win(prev);
    return w;
}

enum { P_NONE, P_MIN, P_MAX, P_CLOSE, P_TITLE, P_CLIENT, P_RES_R, P_RES_B, P_RES_RB };
static void wb_rect(Window *w, int b, int *x, int *y, int *bw, int *bh) {      /* b: 0 min, 1 max, 2 close */
    *bw = 30; *bh = 24; *y = w->y + (TB_H - 24) / 2; *x = w->x + w->w - 8 - (3 - b) * 32 + 2;
}
static int win_part(Window *w, int x, int y) {
    if (!ui_inside(x, y, w->x, w->y, w->w, w->h)) return P_NONE;
    if (y < w->y + TB_H) {
        for (int b = 0; b < 3; b++) {
            int bx, by, bw, bh; wb_rect(w, b, &bx, &by, &bw, &bh);
            if (ui_inside(x, y, bx, by, bw, bh)) return P_MIN + b;
        }
        return P_TITLE;
    }
    if (!w->max) {
        int r = x >= w->x + w->w - 6, b = y >= w->y + w->h - 6;
        if (r && b) return P_RES_RB;
        if (r) return P_RES_R;
        if (b) return P_RES_B;
    }
    return P_CLIENT;
}
static Window *win_at(int x, int y, int *part) {
    for (int i = nz - 1; i >= 0; i--) {
        if (zs[i]->min) continue;
        int p = win_part(zs[i], x, y);
        if (p != P_NONE) { *part = p; return zs[i]; }
    }
    return NULL;
}

static void draw_window(Window *w, int active) {
    int x = w->x, y = w->y, ww = w->w, hh = w->h, rad = w->max ? 0 : 8;
    if (!gfx_visible(x - 24, y - 20, ww + 48, hh + 52)) return;
    if (!w->max) gfx_shadow(x, y, ww, hh, 4, active ? 20 : 12, active ? 120 : 80);
    gfx_round(x, y, ww, hh, rad, CORNER_ALL, theme.border, 255);
    gfx_round(x + 1, y + 1, ww - 2, TB_H - 1, rad ? rad - 1 : 0, CORNER_TOP, active ? theme.title_act : theme.title_inact, 255);
    gfx_round(x + 1, y + TB_H, ww - 2, hh - TB_H - 1, rad ? rad - 1 : 0, CORNER_BOTTOM, theme.win_bg, 255);
    gfx_fill(x + 1, y + TB_H - 1, ww - 2, 1, theme.border);
    icon_draw(apps[w->app]->icon, x + 10, y + (TB_H - 20) / 2, 20);
    gfx_text_fit(&font_uib, x + 38, y + (TB_H - font_uib.height) / 2, ww - 38 - 104, w->title, active ? theme.text : theme.dim);
    for (int b = 0; b < 3; b++) {
        int bx, by, bw, bh; wb_rect(w, b, &bx, &by, &bw, &bh);
        int hot = (hov_wb_win == (int)(w - wins)) && hov_wb == b;
        if (hot) gfx_round(bx, by, bw, bh, 6, CORNER_ALL, b == 2 ? 0xE5484D : theme.hover, 255);
        u32 fg = (hot && b == 2) ? 0xFFFFFF : theme.text;
        int cx = bx + bw / 2, cy = by + bh / 2;
        if (b == 0) gfx_fill(cx - 5, cy + 3, 10, 1, fg);
        else if (b == 1) {
            if (w->max) { gfx_rect(cx - 4, cy - 2, 8, 8, fg); gfx_fill(cx - 2, cy - 4, 8, 1, fg); gfx_fill(cx + 5, cy - 4, 1, 7, fg); }
            else gfx_rect(cx - 5, cy - 5, 10, 10, fg);
        } else {
            gfx_line(cx - 4, cy - 4, cx + 4, cy + 4, 24, fg, 255);
            gfx_line(cx - 4, cy + 4, cx + 4, cy - 4, 24, fg, 255);
        }
    }
    int cx, cy, cw, ch; win_client(w, &cx, &cy, &cw, &ch);
    Clip old = gfx_clip_push(cx, cy, cw, ch);
    apps[w->app]->draw(w, cx, cy, cw, ch);
    gfx_clip_set(old);
}

/* ====================================================================== */
/*  taskbar                                                                */
/* ====================================================================== */
typedef struct { int x, y, w, h; } R;
static R r_start(void) { R r = { 6, tb_top() + 4, 104, 36 }; return r; }
static R r_clock(void) { R r = { gfx_w - 8 - 108, tb_top() + 3, 108, TASKBAR_H - 6 }; return r; }
static R r_show(void)  { R r = { gfx_w - 8, tb_top(), 8, TASKBAR_H }; return r; }
static R r_net(void)   { R r = { gfx_w - 8 - 108 - 40, tb_top() + 4, 36, 36 }; return r; }
static int task_list(Window **out) {
    int n = 0;
    for (int i = 0; i < MAX_WIN; i++) if (wins[i].used) out[n++] = &wins[i];
    return n;
}
static R r_task(int i, int n) {
    int x0 = 6 + 104 + 12, avail = r_net().x - 8 - x0;
    int bw = k_min(176, n ? avail / n : avail);
    R r = { x0 + i * bw, tb_top() + 4, bw - 4, 36 };
    return r;
}

static const char *day_names[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
static const char *mon_names[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
static const char *mon_full[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

static void net_icon_draw(int x, int y, int status, u32 col, u32 bg) {
    gfx_circle(x + 10, y + 10, 10, col, 255);
    gfx_circle(x + 10, y + 10, 9, bg, 255);
    gfx_line(x + 1, y + 10, x + 19, y + 10, 18, col, 255);
    gfx_line(x + 10, y + 1, x + 10, y + 19, 18, col, 255);
    gfx_line(x + 4, y + 5, x + 16, y + 5, 16, col, 255);
    gfx_line(x + 4, y + 15, x + 16, y + 15, 16, col, 255);
    u32 dot = status == NET_UP ? 0x3FB950 : status == NET_WAIT_DHCP ? 0xE3B341 : 0xE5484D;
    gfx_circle(x + 17, y + 17, 5, bg, 255);
    gfx_circle(x + 17, y + 17, 3, dot, 255);
}

static void taskbar_draw(void) {
    int top = tb_top();
    if (!gfx_visible(0, top, gfx_w, TASKBAR_H)) return;
    gfx_fill_a(0, top, gfx_w, TASKBAR_H, theme.panel, 244);
    gfx_fill_a(0, top, gfx_w, 1, theme.border, 200);

    R s = r_start();
    if (sm_open || hov_task == 0) gfx_round(s.x, s.y, s.w, s.h, 6, CORNER_ALL, theme.panel_hover, 255);
    icon_draw(ICON_LOGO, s.x + 8, s.y + 5, 26);
    gfx_text(&font_uib, s.x + 44, s.y + (s.h - font_uib.height) / 2, "Menu", theme.text);

    Window *list[MAX_WIN]; int n = task_list(list);
    Window *act = active_win();
    for (int i = 0; i < n; i++) {
        R r = r_task(i, n);
        Window *w = list[i];
        int isact = (w == act);
        if (isact) gfx_round(r.x, r.y, r.w, r.h, 6, CORNER_ALL, theme.panel_hover, 255);
        else if (hov_task == 10 + i) gfx_round(r.x, r.y, r.w, r.h, 6, CORNER_ALL, theme.hover, 255);
        icon_draw(apps[w->app]->icon, r.x + 8, r.y + 7, 22);
        gfx_text_fit(&font_ui, r.x + 38, r.y + (r.h - font_ui.height) / 2, r.w - 46, w->title, w->min ? theme.dim : theme.text);
        int bw = isact ? 22 : 8;
        gfx_round(r.x + (r.w - bw) / 2, r.y + r.h - 3, bw, 3, 1, CORNER_ALL, theme.accent, w->min ? 120 : 255);
    }

    R c = r_clock();
    if (cal_open || hov_task == 1) gfx_round(c.x, c.y, c.w, c.h, 6, CORNER_ALL, theme.panel_hover, 255);
    char buf[32];
    k_snprintf(buf, sizeof buf, "%02d:%02d", g_time.hour, g_time.min);
    gfx_text_center(&font_uib, c.x, c.y + 2, c.w, 18, buf, theme.text);
    k_snprintf(buf, sizeof buf, "%s %d %s", day_names[g_time.wday % 7], g_time.day, mon_names[(g_time.mon + 11) % 12]);
    gfx_text_center(&font_sm, c.x, c.y + 19, c.w, 16, buf, theme.dim);
    R nt = r_net();
    if (hov_task == 3) gfx_round(nt.x, nt.y, nt.w, nt.h, 6, CORNER_ALL, theme.hover, 255);
    net_icon_draw(nt.x + 7, nt.y + 7, net_info()->status, theme.text, hov_task == 3 ? theme.hover : theme.panel);
    R sh = r_show();
    gfx_fill_a(sh.x, sh.y + 6, 1, sh.h - 12, theme.border, 255);
    if (hov_task == 2) gfx_fill_a(sh.x + 1, sh.y, sh.w - 1, sh.h, theme.hover, 255);
}

/* ====================================================================== */
/*  start menu                                                             */
/* ====================================================================== */
#define SM_W 440
static int sm_h(void) { return k_min(540, tb_top() - 16); }
static int sm_x(void) { return 6; }
static int sm_y(void) { return tb_top() - 8 - sm_h(); }
static int sm_vis(void) { return k_max(1, (sm_h() - 78 - 70) / 50); }
static void sm_refilter(void) {
    sm_n = 0;
    for (int i = 0; i < APP_COUNT; i++)
        if (app_installed(i) && (k_stricmp_sub(apps[i]->name, sm_q) || k_stricmp_sub(apps[i]->desc, sm_q))) sm_items[sm_n++] = i;
    if (sm_sel >= sm_n) sm_sel = k_max(0, sm_n - 1);
    if (sm_sel < sm_top) sm_top = sm_sel;
    if (sm_sel >= sm_top + sm_vis()) sm_top = sm_sel - sm_vis() + 1;
    sm_top = k_clamp(sm_top, 0, k_max(0, sm_n - sm_vis()));
}
static void sm_toggle(void) {
    if (sm_open) { sm_open = 0; damage(sm_x() - 24, sm_y() - 20, SM_W + 48, sm_h() + 52); }
    else {
        if (cal_open) { int x, y; cal_rect_(&x, &y); damage(x - 24, y - 20, CAL_W + 48, CAL_H + 52); }
        if (cm_open) ctxmenu_close();
        sm_open = 1; sm_q[0] = 0; sm_sel = 0; sm_top = 0; sm_hover = -1; sm_refilter(); cal_open = 0;
        damage(sm_x() - 24, sm_y() - 20, SM_W + 48, sm_h() + 52);
    }
    damage_taskbar();
}
static R sm_row(int i) { R r = { sm_x() + 10, sm_y() + 78 + (i - sm_top) * 50, SM_W - 20, 46 }; return r; }
static int sm_row_ok(int i) { return i >= sm_top && i < sm_top + sm_vis() && i < sm_n; }
static R sm_btn(int i) {                          /* 0 Lock, 1 Restart, 2 Shut down */
    static const int bw[3] = { 64, 84, 96 };
    int x = sm_x() + SM_W - 14;
    for (int k = 2; k >= i; k--) { x -= bw[k]; if (k > i) x -= 6; }
    R r = { x, sm_y() + sm_h() - 48, bw[i], 34 };
    return r;
}
void gui_lock(void);

static void power_screen(const char *msg) {
    gfx_clip_set((Clip){ 0, 0, gfx_w, gfx_h });
    gfx_fill(0, 0, gfx_w, gfx_h, 0x000000);
    gfx_text_center(&font_ui, 0, 0, gfx_w, gfx_h, msg, 0xB0B0B0);
    gfx_present(0, 0, gfx_w, gfx_h);
}
void gui_shutdown(void) {
    power_screen("Shutting down...");
    u32 t = hw_ms(); while (hw_ms() - t < 700) { }
    hw_poweroff();
    power_screen("It is now safe to turn off your computer.");
    for (;;) __asm__ volatile("cli; hlt");
}
void gui_restart(void) {
    power_screen("Restarting...");
    u32 t = hw_ms(); while (hw_ms() - t < 500) { }
    hw_reboot();
    for (;;) { }
}

static void startmenu_draw(void) {
    if (!sm_open) return;
    int x = sm_x(), y = sm_y(), w = SM_W, h = sm_h();
    if (!gfx_visible(x - 24, y - 20, w + 48, h + 52)) return;
    gfx_shadow(x, y, w, h, 4, 22, 130);
    gfx_round(x, y, w, h, 10, CORNER_ALL, theme.border, 255);
    gfx_round(x + 1, y + 1, w - 2, h - 2, 9, CORNER_ALL, theme.win_bg, 255);
    /* search */
    ui_field(x + 12, y + 12, w - 24, 36);
    gfx_circle(x + 30, y + 29, 6, theme.dim, 255);
    gfx_circle(x + 30, y + 29, 4, theme.field, 255);
    gfx_line(x + 34, y + 33, x + 38, y + 37, 28, theme.dim, 255);
    if (sm_q[0]) {
        int ex = gfx_text(&font_ui, x + 48, y + 21, sm_q, theme.text);
        if (g_blink) gfx_fill(ex + 1, y + 20, 1, 18, theme.text);
    } else gfx_text(&font_ui, x + 48, y + 21, "Type to search applications", theme.dim);
    gfx_text(&font_sm, x + 16, y + 58, sm_q[0] ? "Results" : "Applications", theme.dim);
    for (int i = sm_top; i < sm_n && i < sm_top + sm_vis(); i++) {
        R r = sm_row(i);
        const AppDesc *a = apps[sm_items[i]];
        if (i == sm_sel || i == sm_hover) gfx_round(r.x, r.y, r.w, r.h, 8, CORNER_ALL, i == sm_sel && sm_q[0] ? theme.accent_dk : theme.hover, 255);
        icon_draw(a->icon, r.x + 8, r.y + 7, 32);
        gfx_text(&font_uib, r.x + 54, r.y + 6, a->name, theme.text);
        gfx_text(&font_sm, r.x + 54, r.y + 25, a->desc, theme.dim);
    }
    if (sm_n == 0) gfx_text(&font_ui, x + 20, y + 90, "No matching applications", theme.dim);
    /* footer */
    int fy = y + h - 60;
    gfx_fill(x + 1, fy, w - 2, 1, theme.border);
    gfx_round(x + 1, fy + 1, w - 2, 58, 9, CORNER_BOTTOM, theme.win_alt, 255);
    gfx_circle(x + 36, fy + 30, 17, theme.accent, 255);
    { char ini[2] = { acct_name()[0] >= 'a' && acct_name()[0] <= 'z' ? (char)(acct_name()[0] - 32) : acct_name()[0], 0 };
      gfx_text_center(&font_uib, x + 19, fy + 13, 34, 34, ini, theme.accent_text); }
    gfx_text_fit(&font_uib, x + 62, fy + 11, 100, acct_name(), theme.text);
    gfx_text(&font_sm, x + 62, fy + 30, OS_NAME, theme.dim);
    { static const char *lbl[3] = { "Lock", "Restart", "Shut down" };
      for (int k = 0; k < 3; k++) { R b = sm_btn(k); ui_button(b.x, b.y + 2, b.w, b.h, lbl[k], sm_hover == 100 + k, k == 2); } }
    if (sm_n > sm_vis()) {                       /* scroll bar */
        int th = (sm_h() - 78 - 70) * sm_vis() / sm_n, ty = sm_y() + 78 + (sm_h() - 78 - 70 - th) * sm_top / k_max(1, sm_n - sm_vis());
        gfx_round(sm_x() + SM_W - 8, ty, 4, th, 2, CORNER_ALL, theme.dim, 255);
    }
}

static void launch_and_close_menu(int app) {
    sm_toggle();
    Window *w = app_launch(app, NULL);
    if (w) win_focus(w);
}

static void startmenu_click(int x, int y) {
    for (int i = 0; i < sm_n; i++) if (sm_row_ok(i)) { R r = sm_row(i); if (ui_inside(x, y, r.x, r.y, r.w, r.h)) { launch_and_close_menu(sm_items[i]); return; } }
    R b0 = sm_btn(0), b1 = sm_btn(1), b2 = sm_btn(2);
    if (ui_inside(x, y, b0.x, b0.y + 2, b0.w, b0.h)) { sm_toggle(); gui_lock(); return; }
    if (ui_inside(x, y, b1.x, b1.y + 2, b1.w, b1.h)) gui_restart();
    if (ui_inside(x, y, b2.x, b2.y + 2, b2.w, b2.h)) gui_shutdown();
}

/* ====================================================================== */
/*  context menu                                                           */
/* ====================================================================== */
static const char *cm_items[] = { "Open Terminal", "Files", "Text Editor", "Change Wallpaper", "Display Settings", "About this computer" };
#define CM_N 6
#define CM_W 220
#define CM_IH 32
static void cm_rect(int *x, int *y, int *w, int *h) { *x = cm_x; *y = cm_y; *w = CM_W; *h = CM_N * CM_IH + 12; }
static void ctxmenu_draw(void) {
    if (!cm_open) return;
    int x, y, w, h; cm_rect(&x, &y, &w, &h);
    if (!gfx_visible(x - 24, y - 20, w + 48, h + 52)) return;
    gfx_shadow(x, y, w, h, 3, 14, 110);
    gfx_round(x, y, w, h, 8, CORNER_ALL, theme.border, 255);
    gfx_round(x + 1, y + 1, w - 2, h - 2, 7, CORNER_ALL, theme.win_bg, 255);
    for (int i = 0; i < CM_N; i++) {
        int iy = y + 6 + i * CM_IH;
        if (i == cm_hover) gfx_round(x + 5, iy, w - 10, CM_IH - 2, 5, CORNER_ALL, theme.hover, 255);
        gfx_text(&font_ui, x + 16, iy + (CM_IH - 2 - font_ui.height) / 2, cm_items[i], theme.text);
    }
}
static void ctxmenu_close(void) {
    int x, y, w, h; cm_rect(&x, &y, &w, &h);
    damage(x - 24, y - 20, w + 48, h + 52);
    cm_open = 0; cm_hover = -1;
}
static void ctxmenu_action(int i) {
    ctxmenu_close();
    Window *w = NULL;
    switch (i) {
    case 0: w = app_launch(APP_TERM, NULL); break;
    case 1: w = app_launch(APP_FILES, NULL); break;
    case 2: w = app_launch(APP_EDIT, NULL); break;
    case 3: cfg_wall = (cfg_wall + 1) % N_WALLS; gui_damage_all(); break;
    case 4: w = app_launch(APP_SETTINGS, NULL); break;
    case 5: w = app_launch(APP_ABOUT, NULL); break;
    }
    if (w) win_focus(w);
}

/* ====================================================================== */
/*  calendar popup                                                         */
/* ====================================================================== */
static void cal_rect(int *x, int *y) { *x = gfx_w - 8 - CAL_W; *y = tb_top() - 8 - CAL_H; }
static void cal_rect_(int *x, int *y) { cal_rect(x, y); }
static int days_in(int y, int m) {
    static const int d[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) return 29;
    return d[m - 1];
}
int gui_dow(int y, int m, int d) {
    static const int t[12] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
    if (m < 3) y--;
    return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
}
static void calendar_draw(void) {
    if (!cal_open) return;
    int x, y; cal_rect(&x, &y);
    if (!gfx_visible(x - 24, y - 20, CAL_W + 48, CAL_H + 52)) return;
    gfx_shadow(x, y, CAL_W, CAL_H, 4, 22, 130);
    gfx_round(x, y, CAL_W, CAL_H, 10, CORNER_ALL, theme.border, 255);
    gfx_round(x + 1, y + 1, CAL_W - 2, CAL_H - 2, 9, CORNER_ALL, theme.win_bg, 255);
    char buf[48];
    k_snprintf(buf, sizeof buf, "%02d:%02d:%02d", g_time.hour, g_time.min, g_time.sec);
    gfx_text(&font_big, x + 18, y + 12, buf, theme.text);
    k_snprintf(buf, sizeof buf, "%s, %d %s %d", day_names[g_time.wday % 7], g_time.day, mon_full[(g_time.mon + 11) % 12], g_time.year);
    gfx_text(&font_ui, x + 18, y + 54, buf, theme.dim);
    gfx_fill(x + 1, y + 82, CAL_W - 2, 1, theme.border);
    k_snprintf(buf, sizeof buf, "%s %d", mon_full[(cal_mon + 11) % 12], cal_year);
    gfx_text(&font_uib, x + 18, y + 94, buf, theme.text);
    for (int b = 0; b < 2; b++) {
        int bx = x + CAL_W - 18 - 64 + b * 34, by = y + 88;
        if (cal_hover == b) gfx_round(bx, by, 30, 30, 6, CORNER_ALL, theme.hover, 255);
        int cx = bx + 15, cy = by + 15, d = b ? 1 : -1;
        gfx_line(cx - d * 2, cy - 5, cx + d * 3, cy, 28, theme.text, 255);
        gfx_line(cx + d * 3, cy, cx - d * 2, cy + 5, 28, theme.text, 255);
    }
    int gx = x + 18, gy = y + 130, cw = 40;
    for (int i = 0; i < 7; i++) gfx_text_center(&font_sm, gx + i * cw, gy, cw, 20, day_names[i], theme.dim);
    int first = gui_dow(cal_year, cal_mon, 1), nd = days_in(cal_year, cal_mon);
    for (int d = 1; d <= nd; d++) {
        int idx = first + d - 1, col = idx % 7, row = idx / 7;
        int cx = gx + col * cw, cy = gy + 26 + row * 34;
        int today = (cal_year == g_time.year && cal_mon == g_time.mon && d == g_time.day);
        if (today) gfx_round(cx + 3, cy, cw - 6, 30, 15, CORNER_ALL, theme.accent, 255);
        k_snprintf(buf, sizeof buf, "%d", d);
        gfx_text_center(&font_ui, cx, cy, cw, 30, buf, today ? theme.accent_text : theme.text);
    }
}
static void cal_toggle(void) {
    int x, y; cal_rect(&x, &y);
    if (cal_open) { cal_open = 0; damage(x - 24, y - 20, CAL_W + 48, CAL_H + 52); }
    else {
        if (sm_open) { sm_open = 0; damage(sm_x() - 24, sm_y() - 20, SM_W + 48, sm_h() + 52); }
        if (cm_open) ctxmenu_close();
        cal_open = 1; cal_mon = g_time.mon; cal_year = g_time.year;
        damage(x - 24, y - 20, CAL_W + 48, CAL_H + 52);
    }
    damage_taskbar();
}
static void calendar_click(int mx, int my) {
    int x, y; cal_rect(&x, &y);
    for (int b = 0; b < 2; b++) {
        int bx = x + CAL_W - 18 - 64 + b * 34, by = y + 88;
        if (ui_inside(mx, my, bx, by, 30, 30)) {
            cal_mon += b ? 1 : -1;
            if (cal_mon < 1) { cal_mon = 12; cal_year--; }
            if (cal_mon > 12) { cal_mon = 1; cal_year++; }
            damage(x, y, CAL_W, CAL_H);
        }
    }
}

/* ====================================================================== */
/*  login screen / first-boot account setup                                */
/* ====================================================================== */
enum { SES_SETUP, SES_LOGIN, SES_DESKTOP };
static int ses = SES_SETUP;
typedef struct { char t[40]; int n; } Field;
static Field lf[3];                 /* 0 username, 1 password, 2 confirm */
static int lfocus = 1, lg_hov = -1, lg_fails;
static char lerr[80];
static u32 lock_until;

static void lg_card(int *x, int *y, int *w, int *h) {
    *w = ses == SES_SETUP ? 440 : 400; *h = ses == SES_SETUP ? 516 : 372;
    *x = (gfx_w - *w) / 2; *y = k_max(14, (gfx_h - *h) / 2 - 8);
}
static void lg_field(int i, int *x, int *y, int *w, int *h) {
    int cx, cy, cw, ch; lg_card(&cx, &cy, &cw, &ch);
    *x = cx + 40; *w = cw - 80; *h = 40;
    *y = ses == SES_SETUP ? cy + 206 + i * 72 : cy + 206;
}
static void lg_button(int *x, int *y, int *w, int *h) {         /* setup: create account */
    int cx, cy, cw, ch; lg_card(&cx, &cy, &cw, &ch);
    *x = cx + 40; *y = cy + 440; *w = cw - 80; *h = 46;
}
static void lg_power(int i, int *x, int *y, int *w, int *h) { *w = i ? 100 : 90; *h = 36; *y = gfx_h - 56; *x = i ? gfx_w - 20 - 100 : gfx_w - 20 - 100 - 8 - 90; }

static int lg_hit(int mx, int my) {
    int x, y, w, h;
    if (ses == SES_SETUP) {
        for (int i = 0; i < 3; i++) { lg_field(i, &x, &y, &w, &h); if (ui_inside(mx, my, x, y, w, h)) return 1 + i; }
        lg_button(&x, &y, &w, &h); if (ui_inside(mx, my, x, y, w, h)) return 10;
    } else {
        lg_field(1, &x, &y, &w, &h);
        if (ui_inside(mx, my, x + w - 38, y + 4, 34, 32)) return 10;
        if (ui_inside(mx, my, x, y, w, h)) return 2;
    }
    for (int i = 0; i < 2; i++) { lg_power(i, &x, &y, &w, &h); if (ui_inside(mx, my, x, y, w, h)) return 20 + i; }
    return -1;
}

static void lg_draw_field(int i, const char *label, int pw, const char *ph) {
    int x, y, w, h; lg_field(i, &x, &y, &w, &h);
    int focused = (lfocus == i);
    if (label) gfx_text(&font_sm, x, y - 20, label, theme.dim);
    gfx_round_border(x, y, w, h, 8, theme.field, focused ? theme.accent : theme.border);
    int caret = x + 12;
    if (lf[i].n == 0) gfx_text(&font_ui, x + 12, y + (h - font_ui.height) / 2, ph, theme.dim);
    else if (pw) {
        int sp = k_min(14, (w - 60) / k_max(1, lf[i].n));
        for (int k = 0; k < lf[i].n; k++) gfx_circle(x + 18 + k * sp, y + h / 2, 4, theme.text, 255);
        caret = x + 18 + lf[i].n * sp - sp / 2 + 3;
    } else caret = gfx_text(&font_ui, x + 12, y + (h - font_ui.height) / 2, lf[i].t, theme.text);
    if (focused && !g_blink) gfx_fill(caret + 1, y + 9, 1, h - 18, theme.text);
}

static void login_draw(void) {
    gfx_fill_a(0, 0, gfx_w, gfx_h, 0x000000, 118);
    char b[48];
    k_snprintf(b, sizeof b, "%02d:%02d", g_time.hour, g_time.min);
    gfx_text_center(&font_big, 0, 36, gfx_w, 44, b, 0xFFFFFF);
    k_snprintf(b, sizeof b, "%s, %d %s", day_names[g_time.wday % 7], g_time.day, mon_full[(g_time.mon + 11) % 12]);
    gfx_text_center(&font_ui, 0, 84, gfx_w, 22, b, 0xE6E6E6);

    int cx, cy, cw, ch; lg_card(&cx, &cy, &cw, &ch);
    gfx_shadow(cx, cy, cw, ch, 6, 26, 150);
    gfx_round(cx, cy, cw, ch, 14, CORNER_ALL, theme.border, 255);
    gfx_round(cx + 1, cy + 1, cw - 2, ch - 2, 13, CORNER_ALL, theme.win_bg, 246);
    int x, y, w, h;
    if (ses == SES_SETUP) {
        icon_draw(ICON_LOGO, cx + cw / 2 - 32, cy + 20, 64);
        gfx_text_center(&font_h2, cx, cy + 96, cw, 28, "Create your account", theme.text);
        gfx_text_center(&font_ui, cx, cy + 128, cw, 20, "Choose a username and password for this computer.", theme.dim);
        if (persist_disk()) gfx_text_center(&font_sm, cx, cy + 152, cw, 16, "Your account and files are saved on this disk.", theme.accent);
        else gfx_text_center(&font_sm, cx, cy + 152, cw, 16, "Read-only boot media: the account will be forgotten at shutdown.", 0xE3B341);
        lg_draw_field(0, "Username", 0, "e.g. alex");
        lg_draw_field(1, "Password", 1, "At least 4 characters");
        lg_draw_field(2, "Confirm password", 1, "Type it again");
        gfx_text_center(&font_ui, cx, cy + 404, cw, 20, lerr, 0xE5484D);
        lg_button(&x, &y, &w, &h);
        ui_button(x, y, w, h, "Create account", lg_hov == 10, 1);
    } else {
        gfx_circle(cx + cw / 2, cy + 90, 46, theme.accent, 255);
        char ini[2] = { acct_name()[0] >= 'a' && acct_name()[0] <= 'z' ? (char)(acct_name()[0] - 32) : acct_name()[0], 0 };
        gfx_text_center(&font_big, cx + cw / 2 - 46, cy + 44, 92, 92, ini, theme.accent_text);
        gfx_text_center(&font_h2, cx, cy + 148, cw, 28, acct_name(), theme.text);
        lg_draw_field(1, NULL, 1, "Password");
        lg_field(1, &x, &y, &w, &h);
        gfx_round(x + w - 38, y + 4, 34, 32, 6, CORNER_ALL, lg_hov == 10 ? gfx_lerp(theme.accent, 0xFFFFFF, 40) : theme.accent, 255);
        gfx_line(x + w - 30, y + 20, x + w - 12, y + 20, 32, theme.accent_text, 255);
        gfx_line(x + w - 18, y + 13, x + w - 11, y + 20, 32, theme.accent_text, 255);
        gfx_line(x + w - 18, y + 27, x + w - 11, y + 20, 32, theme.accent_text, 255);
        gfx_text_center(&font_ui, cx, cy + 262, cw, 20, lerr, 0xE5484D);
        gfx_text_center(&font_sm, cx, cy + 322, cw, 16, "Press Enter to sign in", theme.dim);
    }
    for (int i = 0; i < 2; i++) { lg_power(i, &x, &y, &w, &h); ui_button(x, y, w, h, i ? "Shut down" : "Restart", lg_hov == 20 + i, 0); }
}

static void lg_clear(void) { k_memset(lf, 0, sizeof lf); lerr[0] = 0; }

static void lg_success(void) {
    lg_clear(); lg_fails = 0; ses = SES_DESKTOP; sel_icon = -1; lg_hov = -1;
    dicons_refresh(); theme_apply(); gui_damage_all();
}

static void lg_submit(void) {
    if (ses == SES_SETUP) {
        const char *u = lf[0].t, *p = lf[1].t;
        if (!u[0]) { k_strcpy(lerr, "Enter a username.", sizeof lerr); lfocus = 0; }
        else if (!((u[0] >= 'a' && u[0] <= 'z') || (u[0] >= 'A' && u[0] <= 'Z'))) { k_strcpy(lerr, "The username must start with a letter.", sizeof lerr); lfocus = 0; }
        else if (k_strlen(p) < ACCT_PASS_MIN) { k_strcpy(lerr, "The password needs at least 4 characters.", sizeof lerr); lfocus = 1; }
        else if (k_strcmp(p, lf[2].t) != 0) { k_strcpy(lerr, "The passwords do not match.", sizeof lerr); lf[2].n = 0; lf[2].t[0] = 0; lfocus = 2; }
        else if (acct_create(u, p) == 0) { lg_success(); return; }
        else k_strcpy(lerr, "Could not create the account.", sizeof lerr);
    } else {
        if ((int)(now_ms - lock_until) < 0) { k_strcpy(lerr, "Please wait a moment and try again.", sizeof lerr); }
        else if (acct_check(lf[1].t)) { lg_success(); return; }
        else {
            lg_fails++; lock_until = now_ms + (u32)k_min(4000, 700 * lg_fails);
            k_strcpy(lerr, "Incorrect password.", sizeof lerr); lf[1].n = 0; lf[1].t[0] = 0;
        }
    }
    gui_damage_all();
}

static void login_key(int key, int mods) {
    int nf = ses == SES_SETUP ? 3 : 1, first = ses == SES_SETUP ? 0 : 1;
    if (ses == SES_LOGIN) lfocus = 1;
    if (key == KEY_TAB || key == KEY_DOWN) { if (ses == SES_SETUP) lfocus = (lfocus + 1) % nf; }
    else if (key == KEY_UP) { if (ses == SES_SETUP) lfocus = (lfocus + nf - 1) % nf; }
    else if (key == KEY_ENTER) {
        if (ses == SES_SETUP && lfocus < 2) lfocus++; else lg_submit();
    } else if (key == KEY_ESC) lerr[0] = 0;
    else if (key == KEY_BACKSPACE) { Field *f = &lf[lfocus]; if (f->n > 0) f->t[--f->n] = 0; lerr[0] = 0; }
    else if (key >= 32 && key < 127 && !(mods & (MOD_CTRL | MOD_ALT))) {
        Field *f = &lf[lfocus];
        int ok = 1;
        if (ses == SES_SETUP && lfocus == 0) {
            ok = (key >= 'a' && key <= 'z') || (key >= 'A' && key <= 'Z') || (key >= '0' && key <= '9') || key == '_' || key == '-';
            if (f->n >= ACCT_NAME_MAX) ok = 0;
        } else if (f->n >= ACCT_PASS_MAX) ok = 0;
        if (ok) { f->t[f->n++] = (char)key; f->t[f->n] = 0; lerr[0] = 0; }
    } else return;
    (void)first;
    gui_damage_all();
}

static void login_hover(void) {
    int h = lg_hit(g_mx, g_my);
    if (h != lg_hov) { lg_hov = h; gui_damage_all(); }
}
static void login_press(void) {
    int h = lg_hit(g_mx, g_my);
    if (h >= 1 && h <= 3) { lfocus = h - 1; if (ses == SES_LOGIN) lfocus = 1; gui_damage_all(); }
    else if (h == 10) lg_submit();
    else if (h == 20) gui_restart();
    else if (h == 21) gui_shutdown();
}

void gui_lock(void) {
    sm_open = cal_open = cm_open = 0; drag_mode = DRAG_NONE; drag_win = NULL; cap_win = NULL;
    lg_clear(); lfocus = 1; ses = SES_LOGIN; gui_damage_all();
}
void gui_autologin(const char *user, const char *pass) {          /* test helper: skip the login screen */
    if (!acct_exists()) acct_create(user, pass);
    lg_success();
}
int win_is_active(Window *w) { return ses == SES_DESKTOP && w == active_win(); }
void win_invalidate_rect(Window *w, int x, int y, int cw, int ch) { int cx, cy, ww, hh; win_client(w, &cx, &cy, &ww, &hh); damage(cx + x, cy + y, cw, ch); }
int gui_test_window(int app, int *x, int *y, int *w, int *h) {      /* test hook: where is this app's window? */
    for (int i = 0; i < MAX_WIN; i++) if (wins[i].used && wins[i].app == app) { *x = wins[i].x; *y = wins[i].y; *w = wins[i].w; *h = wins[i].h; return 1; }
    return 0;
}
void gui_get_time(HwTime *t) { *t = g_time; }
void gui_apps_changed(void) { dicons_refresh(); if (sm_open) sm_refilter(); gui_damage_all(); }
void gui_close_app(int app) {
    Window *list[MAX_WIN]; int n = 0;
    for (int i = 0; i < MAX_WIN; i++) if (wins[i].used && wins[i].app == app) list[n++] = &wins[i];
    for (int i = 0; i < n; i++) win_close(list[i]);
}

/* ====================================================================== */
/*  scene composition                                                      */
/* ====================================================================== */
static void render_scene(void) {
    wallpaper_draw();
    if (ses != SES_DESKTOP) { login_draw(); return; }
    desktop_icons_draw();
    Window *act = active_win();
    for (int i = 0; i < nz; i++) if (!zs[i]->min) draw_window(zs[i], zs[i] == act);
    taskbar_draw();
    calendar_draw();
    startmenu_draw();
    ctxmenu_draw();
}

static void cursor_sync(void) {
    if (cur_drawn && (cur_x != g_mx || cur_y != g_my)) {
        gfx_present(cur_x, cur_y, CURSOR_W, CURSOR_H);
        cur_drawn = 0;
    }
    if (!cur_drawn) { gfx_cursor(g_mx, g_my); cur_drawn = 1; cur_x = g_mx; cur_y = g_my; }
}

void gui_render(void) {
    if (has_dmg) {
        Clip c = dmg; has_dmg = 0;
        gfx_clip_set(c);
        render_scene();
        gfx_clip_set((Clip){ 0, 0, gfx_w, gfx_h });
        gfx_present(c.x0, c.y0, c.x1 - c.x0, c.y1 - c.y0);
        if (cur_drawn && cur_x < c.x1 && cur_x + CURSOR_W > c.x0 && cur_y < c.y1 && cur_y + CURSOR_H > c.y0) {
            gfx_present(cur_x, cur_y, CURSOR_W, CURSOR_H);       /* restore the whole old sprite area, not just the damaged part */
            cur_drawn = 0;
        }
    }
    cursor_sync();
}

/* ====================================================================== */
/*  hover tracking                                                         */
/* ====================================================================== */
static void update_hover(void) {
    int n_task = -1, n_win = -1, n_wb = -1;
    if (g_my >= tb_top()) {
        R s = r_start(), c = r_clock(), sh = r_show(), nt = r_net();
        if (ui_inside(g_mx, g_my, s.x, s.y, s.w, s.h)) n_task = 0;
        else if (ui_inside(g_mx, g_my, nt.x, nt.y, nt.w, nt.h)) n_task = 3;
        else if (ui_inside(g_mx, g_my, c.x, c.y, c.w, c.h)) n_task = 1;
        else if (ui_inside(g_mx, g_my, sh.x, sh.y, sh.w, sh.h)) n_task = 2;
        else {
            Window *list[MAX_WIN]; int n = task_list(list);
            for (int i = 0; i < n; i++) { R r = r_task(i, n); if (ui_inside(g_mx, g_my, r.x, r.y, r.w, r.h)) n_task = 10 + i; }
        }
    } else if (!sm_open && !cm_open && !cal_open) {
        int part; Window *w = win_at(g_mx, g_my, &part);
        if (w && part >= P_MIN && part <= P_CLOSE) { n_win = (int)(w - wins); n_wb = part - P_MIN; }
    }
    if (n_task != hov_task) { hov_task = n_task; damage_taskbar(); }
    if (n_win != hov_wb_win || n_wb != hov_wb) {
        if (hov_wb_win >= 0) damage(wins[hov_wb_win].x, wins[hov_wb_win].y, wins[hov_wb_win].w, TB_H);
        hov_wb_win = n_win; hov_wb = n_wb;
        if (n_win >= 0) damage(wins[n_win].x, wins[n_win].y, wins[n_win].w, TB_H);
    }
    if (sm_open) {
        int h = -1;
        for (int i = 0; i < sm_n; i++) if (sm_row_ok(i)) { R r = sm_row(i); if (ui_inside(g_mx, g_my, r.x, r.y, r.w, r.h)) h = i; }
        for (int k = 0; k < 3; k++) { R b = sm_btn(k); if (ui_inside(g_mx, g_my, b.x, b.y + 2, b.w, b.h)) h = 100 + k; }
        if (h != sm_hover) { sm_hover = h; damage(sm_x(), sm_y(), SM_W, sm_h()); }
    }
    if (cm_open) {
        int x, y, w, h; cm_rect(&x, &y, &w, &h);
        int hv = -1;
        for (int i = 0; i < CM_N; i++) if (ui_inside(g_mx, g_my, x + 5, y + 6 + i * CM_IH, w - 10, CM_IH - 2)) hv = i;
        if (hv != cm_hover) { cm_hover = hv; damage(x, y, w, h); }
    }
    if (cal_open) {
        int x, y; cal_rect(&x, &y);
        int hv = -1;
        for (int b = 0; b < 2; b++) if (ui_inside(g_mx, g_my, x + CAL_W - 18 - 64 + b * 34, y + 88, 30, 30)) hv = b;
        if (hv != cal_hover) { cal_hover = hv; damage(x, y, CAL_W, CAL_H); }
    }
}

/* ====================================================================== */
/*  mouse                                                                  */
/* ====================================================================== */
static void forward_mouse(Window *w, int ev, int clicks) {
    int cx, cy, cw, ch; win_client(w, &cx, &cy, &cw, &ch);
    if (apps[w->app]->mouse) apps[w->app]->mouse(w, g_mx - cx, g_my - cy, ev, clicks);
}

static Window *hover_client;
static void handle_move(void) {
    if (drag_mode == DRAG_MOVE && drag_win) {
        Window *w = drag_win;
        damage_win(w);
        w->x = k_clamp(g_mx - drag_dx, 80 - w->w, gfx_w - 80);
        w->y = k_clamp(g_my - drag_dy, 0, tb_top() - TB_H);
        damage_win(w);
    } else if (drag_mode == DRAG_RESIZE && drag_win) {
        Window *w = drag_win;
        damage_win(w);
        if (resize_r) w->w = k_clamp(drag_ow + g_mx - drag_ox, apps[w->app]->minw, gfx_w - w->x);
        if (resize_b) w->h = k_clamp(drag_oh + g_my - drag_oy, apps[w->app]->minh, gfx_h - w->y);
        damage_win(w);
    } else if (cap_win) {
        forward_mouse(cap_win, EV_MOVE, 0);
    } else {
        Window *nw = NULL;
        if (!sm_open && !cm_open && !cal_open) {
            int part; Window *w = win_at(g_mx, g_my, &part);
            if (w && part == P_CLIENT) nw = w;
        }
        if (hover_client && hover_client != nw && hover_client->used && apps[hover_client->app]->mouse)
            apps[hover_client->app]->mouse(hover_client, -1000, -1000, EV_MOVE, 0);
        hover_client = nw;
        if (nw) forward_mouse(nw, EV_MOVE, 0);
    }
    update_hover();
}

static void handle_press(int clicks) {
    /* popups first */
    if (sm_open) {
        if (ui_inside(g_mx, g_my, sm_x(), sm_y(), SM_W, sm_h())) { startmenu_click(g_mx, g_my); return; }
        R s = r_start();
        sm_toggle();
        if (ui_inside(g_mx, g_my, s.x, s.y, s.w, s.h)) return;
    }
    if (cal_open) {
        int x, y; cal_rect(&x, &y);
        if (ui_inside(g_mx, g_my, x, y, CAL_W, CAL_H)) { calendar_click(g_mx, g_my); return; }
        R c = r_clock();
        cal_toggle();
        if (ui_inside(g_mx, g_my, c.x, c.y, c.w, c.h)) return;
    }
    if (cm_open) {
        int x, y, w, h; cm_rect(&x, &y, &w, &h);
        if (ui_inside(g_mx, g_my, x, y, w, h)) {
            for (int i = 0; i < CM_N; i++) if (ui_inside(g_mx, g_my, x + 5, y + 6 + i * CM_IH, w - 10, CM_IH - 2)) { ctxmenu_action(i); return; }
            return;
        }
        ctxmenu_close();
    }
    /* taskbar */
    if (g_my >= tb_top()) {
        R s = r_start(), c = r_clock(), sh = r_show(), nt = r_net();
        if (ui_inside(g_mx, g_my, s.x, s.y, s.w, s.h)) { sm_toggle(); return; }
        if (ui_inside(g_mx, g_my, nt.x, nt.y, nt.w, nt.h)) { Window *sw = app_launch(APP_SETTINGS, NULL); if (sw) win_focus(sw); return; }
        if (ui_inside(g_mx, g_my, c.x, c.y, c.w, c.h)) { cal_toggle(); return; }
        if (ui_inside(g_mx, g_my, sh.x, sh.y, sh.w, sh.h)) {
            int any = 0;
            for (int i = 0; i < nz; i++) if (!zs[i]->min) any = 1;
            for (int i = 0; i < nz; i++) zs[i]->min = any;
            gui_damage_all();
            return;
        }
        Window *list[MAX_WIN]; int n = task_list(list);
        for (int i = 0; i < n; i++) {
            R r = r_task(i, n);
            if (ui_inside(g_mx, g_my, r.x, r.y, r.w, r.h)) {
                if (list[i] == active_win()) win_minimize(list[i]); else win_focus(list[i]);
                return;
            }
        }
        return;
    }
    /* windows */
    int part; Window *w = win_at(g_mx, g_my, &part);
    if (w) {
        win_focus(w);
        if (sel_icon >= 0) { sel_icon = -1; gui_damage_all(); }
        switch (part) {
        case P_MIN: win_minimize(w); break;
        case P_MAX: win_toggle_max(w); break;
        case P_CLOSE: win_close(w); break;
        case P_TITLE:
            if (clicks >= 2) win_toggle_max(w);
            else if (!w->max) { drag_mode = DRAG_MOVE; drag_win = w; drag_dx = g_mx - w->x; drag_dy = g_my - w->y; }
            break;
        case P_RES_R: case P_RES_B: case P_RES_RB:
            drag_mode = DRAG_RESIZE; drag_win = w; drag_ox = g_mx; drag_oy = g_my; drag_ow = w->w; drag_oh = w->h;
            resize_r = (part != P_RES_B); resize_b = (part != P_RES_R);
            break;
        case P_CLIENT:
            cap_win = w;
            forward_mouse(w, EV_DOWN, clicks);
            break;
        }
        return;
    }
    /* desktop */
    int hit = -1;
    for (int i = 0; i < N_DICONS; i++) { int x, y; dicon_pos(i, &x, &y); if (ui_inside(g_mx, g_my, x, y, DI_W, DI_H - 6)) hit = i; }
    if (hit >= 0 && clicks >= 2) {
        Window *nw = app_launch(dic[hit], NULL);
        if (nw) win_focus(nw);
        sel_icon = -1; gui_damage_all();
    } else if (hit != sel_icon) {
        sel_icon = hit; gui_damage_all();
    }
}

static void handle_release(void) {
    drag_mode = DRAG_NONE; drag_win = NULL;
    if (cap_win) { Window *w = cap_win; cap_win = NULL; forward_mouse(w, EV_UP, 0); }
}

static void handle_rpress(void) {
    if (sm_open) { sm_toggle(); return; }
    if (cal_open) cal_toggle();
    if (cm_open) ctxmenu_close();
    if (g_my >= tb_top()) return;
    int part; Window *w = win_at(g_mx, g_my, &part);
    if (w) { win_focus(w); if (part == P_CLIENT) forward_mouse(w, EV_RDOWN, 1); return; }
    cm_open = 1;
    cm_x = k_min(g_mx, gfx_w - CM_W - 4);
    cm_y = k_min(g_my, tb_top() - (CM_N * CM_IH + 12) - 4);
    cm_hover = -1;
    if (sel_icon >= 0) { sel_icon = -1; gui_damage_all(); }
    { int x, y, w2, h2; cm_rect(&x, &y, &w2, &h2); damage(x - 24, y - 20, w2 + 48, h2 + 52); }
}

void gui_mouse(int x, int y, int btn, int wheel) {
    x = k_clamp(x, 0, gfx_w - 1); y = k_clamp(y, 0, gfx_h - 1);
    int moved = (x != g_mx || y != g_my);
    g_mx = x; g_my = y;
    if (moved) entropy_add((u32)(x * 7919 + y) ^ now_ms);
    if (ses != SES_DESKTOP) {
        int lp = (btn & 1) && !(prev_btn & 1);
        prev_btn = btn;
        if (moved) login_hover();
        if (lp) login_press();
        return;
    }
    int lpress = (btn & 1) && !(prev_btn & 1), lrel = !(btn & 1) && (prev_btn & 1), rpress = (btn & 2) && !(prev_btn & 2);
    prev_btn = btn;
    if (moved) handle_move();
    if (wheel && sm_open) { sm_top = k_clamp(sm_top + wheel, 0, k_max(0, sm_n - sm_vis())); damage(sm_x(), sm_y(), SM_W, sm_h()); }
    if (wheel && !sm_open) {
        int part; Window *w = cap_win ? cap_win : win_at(g_mx, g_my, &part);
        if (w) forward_mouse(w, EV_WHEEL, wheel);
    }
    if (lpress) {
        int clicks = 1;
        if (now_ms - last_click_ms < 450 && k_abs(g_mx - last_cx) < 6 && k_abs(g_my - last_cy) < 6) { clicks = 2; last_click_ms = 0; }
        else { last_click_ms = now_ms; last_cx = g_mx; last_cy = g_my; }
        handle_press(clicks);
        update_hover();
    }
    if (lrel) handle_release();
    if (rpress) { handle_rpress(); update_hover(); }
}

/* ====================================================================== */
/*  keyboard                                                               */
/* ====================================================================== */
void gui_key(int key, int mods) {
    entropy_add((u32)key ^ (now_ms << 3));
    if (ses != SES_DESKTOP) { login_key(key, mods); return; }
    if (key == 'l' && (mods & MOD_CTRL) && (mods & MOD_ALT)) { gui_lock(); return; }
    if (key == KEY_LGUI) { sm_toggle(); return; }
    if (key == 't' && (mods & MOD_CTRL) && (mods & MOD_ALT)) { Window *w = app_launch(APP_TERM, NULL); if (w) win_focus(w); return; }
    if (key == KEY_F4 && (mods & MOD_ALT)) { Window *a = active_win(); if (a) win_close(a); return; }
    if (key == KEY_TAB && (mods & MOD_ALT)) {
        Window *top = active_win();
        for (int i = 0; i < nz; i++) if (zs[i] != top) { win_focus(zs[i]); return; }
        return;
    }
    if (sm_open) {
        if (key == KEY_ESC) { sm_toggle(); return; }
        if (key == KEY_ENTER) { if (sm_n > 0) launch_and_close_menu(sm_items[sm_sel]); return; }
        if (key == KEY_DOWN) { if (sm_sel + 1 < sm_n) sm_sel++; sm_refilter(); }
        else if (key == KEY_UP) { if (sm_sel > 0) sm_sel--; sm_refilter(); }
        else if (key == KEY_BACKSPACE) { int l = k_strlen(sm_q); if (l) sm_q[l - 1] = 0; sm_refilter(); }
        else if (key >= 32 && key < 127 && !(mods & (MOD_CTRL | MOD_ALT))) { int l = k_strlen(sm_q); if (l < 30) { sm_q[l] = (char)key; sm_q[l + 1] = 0; } sm_sel = 0; sm_refilter(); }
        damage(sm_x(), sm_y(), SM_W, sm_h());
        return;
    }
    if (key == KEY_ESC && (cal_open || cm_open)) { if (cal_open) cal_toggle(); if (cm_open) ctxmenu_close(); return; }
    Window *a = active_win();
    if (a && apps[a->app]->key) apps[a->app]->key(a, key, mods);
}

/* ====================================================================== */
/*  time / init                                                            */
/* ====================================================================== */
void gui_tick(u32 ms) {
    now_ms = ms;
    persist_tick(ms);
    int blink = (ms / 530) & 1;
    Window *a = active_win();
    if (blink != g_blink) {
        g_blink = blink;
        if (ses != SES_DESKTOP) gui_damage_all();
        if (a && (a->app == APP_TERM || a->app == APP_EDIT)) win_invalidate(a);
        if (sm_open) damage(sm_x(), sm_y(), SM_W, 56);
    }
    if (ms - last_time_poll >= 400 || last_time_poll == 0) {
        last_time_poll = ms ? ms : 1;
        HwTime t; hw_time(&t);
        if (t.min != g_time.min || t.day != g_time.day) damage_taskbar();
        if (t.sec != g_time.sec && cal_open) { int x, y; cal_rect(&x, &y); damage(x, y, CAL_W, 90); }
        g_time = t;
    }
    for (int i = 0; i < MAX_WIN; i++)
        if (wins[i].used && apps[wins[i].app]->tick) apps[wins[i].app]->tick(&wins[i], ms);
}

const AppDesc *apps[APP_COUNT] = { &app_files, &app_browser, &app_store, &app_term, &app_edit, &app_calc, &app_settings, &app_about,
                                    &app_snake, &app_mines, &app_2048, &app_ttt, &app_paint, &app_clock };

void gui_init(u32 *scene, u32 *screen, int w, int h, int spitch) {
    gfx_init(scene, screen, w, h, spitch);
    persist_init();
    theme_apply();
    hw_time(&g_time);
    ses = acct_exists() ? SES_LOGIN : SES_SETUP;
    lfocus = (ses == SES_SETUP) ? 0 : 1;
    dicons_refresh();
    g_mx = w / 2; g_my = h / 2;
    cal_mon = g_time.mon; cal_year = g_time.year;
    gui_damage_all();
}
