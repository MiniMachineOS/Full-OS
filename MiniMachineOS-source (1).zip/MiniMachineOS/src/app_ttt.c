/* app_ttt.c - Tic-Tac-Toe against the computer (you are X) */
#include "app.h"
#include "klib.h"

static int wins, losses, draws;
static const int L8[8][3] = { {0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6} };

static int winner(const int *b) {
    for (int i = 0; i < 8; i++) if (b[L8[i][0]] && b[L8[i][0]] == b[L8[i][1]] && b[L8[i][1]] == b[L8[i][2]]) return b[L8[i][0]];
    for (int i = 0; i < 9; i++) if (!b[i]) return 0;
    return 3;                                          /* draw */
}
static int minimax(int *b, int turn, int depth) {      /* +10 = O wins; turn 1 = X, 2 = O */
    int w = winner(b);
    if (w == 2) return 10 - depth;
    if (w == 1) return depth - 10;
    if (w == 3) return 0;
    int best = turn == 2 ? -100 : 100;
    for (int i = 0; i < 9; i++) if (!b[i]) {
        b[i] = turn; int s = minimax(b, turn == 2 ? 1 : 2, depth + 1); b[i] = 0;
        if (turn == 2 ? s > best : s < best) best = s;
    }
    return best;
}
static void ai(TttState *t) {
    int cand[9], n = 0, best = -100;
    for (int i = 0; i < 9; i++) if (!t->b[i]) {
        int s;
        if (t->hard) { t->b[i] = 2; s = minimax(t->b, 1, 1); t->b[i] = 0; } else s = 0;
        if (s > best) { best = s; n = 0; }
        if (s == best) cand[n++] = i;
    }
    if (n) t->b[cand[k_rand() % (u32)n]] = 2;
}
static void new_game(TttState *t) { int h = t->hard; k_memset(t, 0, sizeof *t); t->hard = h; t->hot = -1; }
static void t_init(Window *w, const char *arg) { (void)arg; k_srand(gui_now() | 1); w->u.ttt.hard = 1; new_game(&w->u.ttt); }

#define BS 300
static int origin_x(int cw) { return (cw - BS) / 2; }
static void finish(TttState *t) {
    int w = winner(t->b);
    if (w) { t->over = 1; t->winner = w; if (w == 1) wins++; else if (w == 2) losses++; else draws++; }
}
static int hit(Window *w, int x, int y) {
    int cw = w->w - 2, bx = origin_x(cw), by = 110;
    if (ui_inside(x, y, 20, 14, 100, 32)) return 100;
    if (ui_inside(x, y, 128, 14, 100, 32)) return 101;
    if (ui_inside(x, y, cw - 120, 14, 100, 32)) return 102;
    if (x >= bx && y >= by && x < bx + BS && y < by + BS) return ((y - by) / (BS / 3)) * 3 + (x - bx) / (BS / 3);
    return -1;
}
static void t_mouse(Window *w, int x, int y, int ev, int clicks) {
    TttState *t = &w->u.ttt; (void)clicks;
    int h = hit(w, x, y);
    if (ev == EV_MOVE) { if (h != t->hot) { t->hot = h; win_invalidate(w); } return; }
    if (ev != EV_DOWN) return;
    if (h == 100) { t->hard = 0; new_game(t); }
    else if (h == 101) { t->hard = 1; new_game(t); }
    else if (h == 102) new_game(t);
    else if (h >= 0 && h < 9 && !t->over && !t->b[h]) {
        t->b[h] = 1; finish(t);
        if (!t->over) { ai(t); finish(t); }
    } else return;
    win_invalidate(w);
}

static void t_draw(Window *w, int x, int y, int cw, int ch) {
    TttState *t = &w->u.ttt;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    ui_button(x + 20, y + 14, 100, 32, "Easy", t->hot == 100, !t->hard);
    ui_button(x + 128, y + 14, 100, 32, "Hard", t->hot == 101, t->hard);
    ui_button(x + cw - 120, y + 14, 100, 32, "New game", t->hot == 102, 0);
    char b[80]; k_snprintf(b, sizeof b, "You %d     Computer %d     Draws %d", wins, losses, draws);
    gfx_text_center(&font_uib, x, y + 62, cw, 24, b, theme.text);
    const char *msg = t->over ? (t->winner == 1 ? "You win!" : t->winner == 2 ? "Computer wins" : "It's a draw") : "Your move (X)";
    gfx_text_center(&font_ui, x, y + 84, cw, 20, msg, t->over ? theme.accent : theme.dim);
    int bx = x + origin_x(cw), by = y + 110, c = BS / 3;
    for (int i = 1; i < 3; i++) {
        gfx_round(bx + i * c - 2, by + 8, 4, BS - 16, 2, CORNER_ALL, theme.border, 255);
        gfx_round(bx + 8, by + i * c - 2, BS - 16, 4, 2, CORNER_ALL, theme.border, 255);
    }
    for (int i = 0; i < 9; i++) {
        int cx = bx + (i % 3) * c, cy = by + (i / 3) * c, mx = cx + c / 2, my = cy + c / 2;
        if (!t->b[i] && t->hot == i && !t->over) gfx_round(cx + 8, cy + 8, c - 16, c - 16, 8, CORNER_ALL, theme.hover, 255);
        if (t->b[i] == 1) { gfx_line(mx - 26, my - 26, mx + 26, my + 26, 90, theme.accent, 255); gfx_line(mx - 26, my + 26, mx + 26, my - 26, 90, theme.accent, 255); }
        else if (t->b[i] == 2) { gfx_circle(mx, my, 30, theme.dark ? 0xE8EAED : 0x303338, 255); gfx_circle(mx, my, 23, theme.win_bg, 255); }
    }
    if (t->over && t->winner < 3)
        for (int i = 0; i < 8; i++) if (t->b[L8[i][0]] == t->winner && t->b[L8[i][1]] == t->winner && t->b[L8[i][2]] == t->winner) {
            int a = L8[i][0], z = L8[i][2];
            gfx_line(bx + (a % 3) * c + c / 2, by + (a / 3) * c + c / 2, bx + (z % 3) * c + c / 2, by + (z / 3) * c + c / 2, 70, 0xE5484D, 255);
        }
}

const AppDesc app_ttt = {
    "Tic-Tac-Toe", "Beat the computer", ICON_TTT, 400, 110 + BS + 30 + TB_H + 1, 400, 110 + BS + 30 + TB_H + 1,
    t_init, t_draw, t_mouse, NULL, NULL, 0, NULL, NULL, 2
};
