#ifndef NET_H
#define NET_H
#include "types.h"
/* Small non-blocking IPv4 stack: ARP, ICMP echo, UDP, DHCP client, DNS resolver, TCP client.
   IPv4 addresses are host-order u32 (a<<24|b<<16|c<<8|d). Call net_poll() often. */
enum { NET_NO_NIC, NET_WAIT_DHCP, NET_UP };
typedef struct { int status; u8 mac[6]; u32 ip, mask, gw, dns; } NetInfo;
void net_init(void);
void net_poll(void);
const NetInfo *net_info(void);
void net_renew(void);                         /* restart DHCP */
void ip_to_str(u32 ip, char *out, int max);
int  ip_parse(const char *s, u32 *ip);        /* dotted quad -> 1 on success */

int  dns_lookup(const char *name, u32 *ip);   /* 1 resolved, 0 pending, -1 failed */

enum { TCP_CLOSED, TCP_CONNECTING, TCP_OPEN, TCP_PEER_CLOSED, TCP_ERROR };
int  tcp_open(u32 ip, u16 port);              /* socket id or -1 */
int  tcp_state(int s);
int  tcp_send(int s, const void *d, int n);   /* bytes accepted (0 = busy, try again) */
int  tcp_recv(int s, void *buf, int max);     /* bytes copied */
void tcp_close(int s);                        /* socket id is invalid afterwards */

int  net_ping_start(u32 ip);
int  net_ping_poll(int *rtt_ms);              /* 1 reply, 0 waiting, -1 timeout */
#endif
