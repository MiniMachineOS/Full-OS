/* app_2048.c - 2048 */
#include "app.h"
#include "klib.h"

#define TS 90
#define GAP 10
static int best;

static void spawn(G2048State *g) {
    int empty[16], n = 0;
    for (int i = 0; i < 16; i++) if (!g->b[i]) empty[n++] = i;
    if (n) g->b[empty[k_rand() % (u32)n]] = (k_rand() % 10 == 0) ? 4 : 2;
}
static void reset(G2048State *g) { k_memset(g, 0, sizeof *g); spawn(g); spawn(g); }
static void g_init(Window *w, const char *arg) { (void)arg; k_srand(gui_now() | 1); reset(&w->u.g2048); }

static int idx(int dir, int line, int k) {            /* k-th cell counting from the edge tiles slide towards */
    switch (dir) {
    case 3: return line * 4 + k;                      /* left  */
    case 1: return line * 4 + (3 - k);                /* right */
    case 0: return k * 4 + line;                      /* up    */
    default: return (3 - k) * 4 + line;               /* down  */
    }
}
static int slide(G2048State *g, int dir) {
    int moved = 0;
    for (int line = 0; line < 4; line++) {
        int t[4], n = 0;
        for (int k = 0; k < 4; k++) { int v = g->b[idx(dir, line, k)]; if (v) t[n++] = v; }
        for (int k = 0; k + 1 < n; k++)
            if (t[k] == t[k + 1]) { t[k] *= 2; g->score += t[k]; if (t[k] == 2048) g->won = 1; for (int j = k + 1; j + 1 < n; j++) t[j] = t[j + 1]; n--; }
        for (int k = 0; k < 4; k++) { int nv = k < n ? t[k] : 0, *c = &g->b[idx(dir, line, k)]; if (*c != nv) moved = 1; *c = nv; }
    }
    return moved;
}
static int stuck(G2048State *g) {
    for (int i = 0; i < 16; i++) {
        if (!g->b[i]) return 0;
        if (i % 4 < 3 && g->b[i] == g->b[i + 1]) return 0;
        if (i < 12 && g->b[i] == g->b[i + 4]) return 0;
    }
    return 1;
}
static void g_key(Window *w, int key, int mods) {
    G2048State *g = &w->u.g2048; (void)mods;
    int d = -1;
    if (key == KEY_UP || key == 'w') d = 0; else if (key == KEY_RIGHT || key == 'd') d = 1;
    else if (key == KEY_DOWN || key == 's') d = 2; else if (key == KEY_LEFT || key == 'a') d = 3;
    if (key == 'r' || key == KEY_ENTER) { reset(g); win_invalidate(w); return; }
    if (d < 0 || g->over) return;
    if (slide(g, d)) { spawn(g); if (g->score > best) best = g->score; if (stuck(g)) g->over = 1; }
    win_invalidate(w);
}
static void g_mouse(Window *w, int x, int y, int ev, int clicks) {
    (void)clicks;
    if (ev == EV_DOWN && ui_inside(x, y, w->w - 2 - 130, 14, 114, 34)) { reset(&w->u.g2048); win_invalidate(w); }
}

static u32 tile_bg(int v) {
    switch (v) {
    case 2: return 0xEEE4DA; case 4: return 0xEDE0C8; case 8: return 0xF2B179; case 16: return 0xF59563;
    case 32: return 0xF67C5F; case 64: return 0xF65E3B; case 128: return 0xEDCF72; case 256: return 0xEDCC61;
    case 512: return 0xEDC850; case 1024: return 0xEDC53F; case 2048: return 0xEDC22E;
    }
    return 0x3C3A32;
}
static void g_draw(Window *w, int x, int y, int cw, int ch) {
    G2048State *g = &w->u.g2048;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    char b[32];
    gfx_text(&font_big, x + 20, y + 8, "2048", theme.text);
    k_snprintf(b, sizeof b, "Score %d   Best %d", g->score, best);
    gfx_text(&font_ui, x + 22, y + 48, b, theme.dim);
    ui_button(x + cw - 130, y + 14, 114, 34, "New game", 0, 1);
    int bw = 4 * TS + 5 * GAP, bx = x + (cw - bw) / 2, by = y + 78;
    gfx_round(bx, by, bw, bw, 10, CORNER_ALL, 0x8F7A66, 255);
    for (int i = 0; i < 16; i++) {
        int tx = bx + GAP + (i % 4) * (TS + GAP), ty = by + GAP + (i / 4) * (TS + GAP), v = g->b[i];
        gfx_round(tx, ty, TS, TS, 8, CORNER_ALL, v ? tile_bg(v) : 0xA89886, 255);
        if (v) { char t[12]; k_snprintf(t, sizeof t, "%d", v); gfx_text_center(v < 100 ? &font_big : &font_h2, tx, ty, TS, TS, t, v <= 4 ? 0x5B5048 : 0xFFFFFF); }
    }
    if (g->over) {
        gfx_round(bx, by, bw, bw, 10, CORNER_ALL, 0xFFFFFF, 130);
        gfx_text_center(&font_big, bx, by + bw / 2 - 40, bw, 50, "Game over", 0x4A4036);
        gfx_text_center(&font_ui, bx, by + bw / 2 + 10, bw, 24, "Press Enter to try again", 0x4A4036);
    } else if (g->won) gfx_text_center(&font_uib, x, by + bw + 12, cw, 24, "You made 2048! Keep going...", theme.accent);
    else gfx_text_center(&font_sm, x, by + bw + 14, cw, 20, "Arrow keys or WASD to slide tiles. R restarts.", theme.dim);
}

const AppDesc app_2048 = {
    "2048", "Merge tiles to reach 2048", ICON_2048, 4 * TS + 5 * GAP + 60, 78 + 4 * TS + 5 * GAP + 56 + TB_H + 1, 4 * TS + 5 * GAP + 60, 78 + 4 * TS + 5 * GAP + 56 + TB_H + 1,
    g_init, g_draw, g_mouse, g_key, NULL, 0, NULL, NULL, 2
};
