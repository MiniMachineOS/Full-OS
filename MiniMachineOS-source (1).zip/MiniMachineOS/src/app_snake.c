/* app_snake.c - Snake */
#include "app.h"
#include "klib.h"

#define CELL 20
#define HEAD 44
static int best;
static const int DX[4] = { 0, 1, 0, -1 }, DY[4] = { -1, 0, 1, 0 };

static void place_food(SnakeState *s) {
    for (int tries = 0; tries < 2000; tries++) {
        int x = (int)(k_rand() % SN_W), y = (int)(k_rand() % SN_H), clash = 0;
        for (int i = 0; i < s->len; i++) if (s->bx[i] == x && s->by[i] == y) { clash = 1; break; }
        if (!clash) { s->fx = x; s->fy = y; return; }
    }
}
static void reset(SnakeState *s) {
    s->len = 4; s->dir = s->ndir = 1; s->score = 0; s->alive = 1; s->paused = 0; s->started = 0;
    for (int i = 0; i < s->len; i++) { s->bx[i] = (u8)(8 - i); s->by[i] = SN_H / 2; }
    place_food(s);
}
static void sn_init(Window *w, const char *arg) { (void)arg; k_srand(gui_now() | 1); reset(&w->u.snake); }

static void step(SnakeState *s) {
    s->dir = s->ndir;
    int nx = s->bx[0] + DX[s->dir], ny = s->by[0] + DY[s->dir];
    if (nx < 0 || ny < 0 || nx >= SN_W || ny >= SN_H) { s->alive = 0; return; }
    int eat = (nx == s->fx && ny == s->fy), chk = eat ? s->len : s->len - 1;
    for (int i = 0; i < chk; i++) if (s->bx[i] == nx && s->by[i] == ny) { s->alive = 0; return; }
    int mv = eat ? s->len : s->len - 1;
    k_memmove(s->bx + 1, s->bx, (unsigned)mv); k_memmove(s->by + 1, s->by, (unsigned)mv);
    if (eat) s->len++;
    s->bx[0] = (u8)nx; s->by[0] = (u8)ny;
    if (eat) { s->score += 10; if (s->score > best) best = s->score; place_food(s); }
}

static void sn_tick(Window *w, u32 ms) {
    SnakeState *s = &w->u.snake;
    if (!s->alive || s->paused || !s->started || !win_is_active(w)) { s->last = ms; return; }
    int interval = k_max(55, 140 - (s->score / 10) * 4);
    if (ms - s->last >= (u32)interval) {
        s->last = ms; step(s);
        if (!s->alive && s->score > best) best = s->score;
        win_invalidate(w);
    }
}

static void sn_key(Window *w, int key, int mods) {
    SnakeState *s = &w->u.snake; (void)mods;
    int d = -1;
    if (key == KEY_UP || key == 'w') d = 0; else if (key == KEY_RIGHT || key == 'd') d = 1;
    else if (key == KEY_DOWN || key == 's') d = 2; else if (key == KEY_LEFT || key == 'a') d = 3;
    if (d >= 0 && s->alive) {
        if (((d + 2) & 3) != s->dir || s->len == 1) s->ndir = d;
        if (!s->started) { s->started = 1; s->last = gui_now(); }
        s->paused = 0;
    } else if (key == ' ' && s->alive && s->started) s->paused = !s->paused;
    else if (key == KEY_ENTER || key == 'r') reset(s);
    else return;
    win_invalidate(w);
}

static void sn_draw(Window *w, int x, int y, int cw, int ch) {
    SnakeState *s = &w->u.snake;
    gfx_fill(x, y, cw, ch, theme.win_bg);
    char b[64];
    k_snprintf(b, sizeof b, "Score %d", s->score); gfx_text(&font_uib, x + 16, y + 12, b, theme.text);
    k_snprintf(b, sizeof b, "Best %d", best); gfx_text_right(&font_ui, x + cw - 16, y + 13, b, theme.dim);
    int bx = x + (cw - SN_W * CELL) / 2, by = y + HEAD;
    gfx_round(bx - 4, by - 4, SN_W * CELL + 8, SN_H * CELL + 8, 8, CORNER_ALL, theme.border, 255);
    for (int j = 0; j < SN_H; j++) for (int i = 0; i < SN_W; i++)
        gfx_fill(bx + i * CELL, by + j * CELL, CELL, CELL, ((i + j) & 1) ? 0x1E2B22 : 0x22322A);
    gfx_circle(bx + s->fx * CELL + CELL / 2, by + s->fy * CELL + CELL / 2, 7, 0xE5484D, 255);
    gfx_line(bx + s->fx * CELL + CELL / 2, by + s->fy * CELL + 4, bx + s->fx * CELL + CELL / 2 + 3, by + s->fy * CELL + 1, 28, 0x7EE787, 255);
    for (int i = s->len - 1; i >= 0; i--) {
        u32 c = i == 0 ? gfx_lerp(theme.accent, 0xFFFFFF, 60) : gfx_lerp(theme.accent, 0x14301A, 40 + i * 2 > 160 ? 160 : 40 + i * 2);
        gfx_round(bx + s->bx[i] * CELL + 1, by + s->by[i] * CELL + 1, CELL - 2, CELL - 2, 6, CORNER_ALL, c, 255);
    }
    if (s->alive && s->started == 0) gfx_text_center(&font_uib, bx, by, SN_W * CELL, SN_H * CELL, "Press an arrow key to start", 0xFFFFFF);
    if (s->paused) gfx_text_center(&font_h2, bx, by, SN_W * CELL, SN_H * CELL, "Paused", 0xFFFFFF);
    if (!s->alive) {
        gfx_fill_a(bx, by, SN_W * CELL, SN_H * CELL, 0x000000, 150);
        gfx_text_center(&font_big, bx, by + 60, SN_W * CELL, 50, "Game over", 0xFFFFFF);
        k_snprintf(b, sizeof b, "Score %d", s->score);
        gfx_text_center(&font_uib, bx, by + 120, SN_W * CELL, 24, b, 0xE0E0E0);
        gfx_text_center(&font_ui, bx, by + 160, SN_W * CELL, 24, "Press Enter to play again", 0xC0C0C0);
    }
}

const AppDesc app_snake = {
    "Snake", "Eat, grow, don't crash", ICON_SNAKE, 502, 44 + SN_H * CELL + 16 + TB_H + 1, 502, 44 + SN_H * CELL + 16 + TB_H + 1,
    sn_init, sn_draw, NULL, sn_key, sn_tick, 0, NULL, NULL, 2
};
