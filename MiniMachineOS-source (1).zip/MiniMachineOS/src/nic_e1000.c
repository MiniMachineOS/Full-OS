/* nic_e1000.c - Intel PRO/1000 family: classic e1000 (QEMU/VirtualBox/VMware), e1000e (82574, I217/I218/I219 ...)
   and igb (82575/82576/I350/I210/I211) in legacy-descriptor mode. Polled, one queue. */
#include "nic.h"
#include "plat.h"
#include "klib.h"

enum { K_E1000, K_E1000E, K_IGB };
static const struct { u16 id; u8 kind; } ids[] = {
    {0x1000,0},{0x1001,0},{0x1004,0},{0x1008,0},{0x1009,0},{0x100C,0},{0x100D,0},{0x100E,0},{0x100F,0},{0x1010,0},{0x1011,0},{0x1012,0},
    {0x1013,0},{0x1014,0},{0x1015,0},{0x1016,0},{0x1017,0},{0x1018,0},{0x1019,0},{0x101A,0},{0x101D,0},{0x101E,0},{0x1026,0},{0x1027,0},
    {0x1028,0},{0x1075,0},{0x1076,0},{0x1077,0},{0x1078,0},{0x1079,0},{0x107A,0},{0x107B,0},{0x107C,0},{0x108A,0},{0x1099,0},{0x10B5,0},
    {0x105E,1},{0x105F,1},{0x1060,1},{0x107D,1},{0x107E,1},{0x107F,1},{0x10B9,1},{0x10BC,1},{0x10D3,1},{0x10F6,1},{0x1502,1},{0x1503,1},
    {0x153A,1},{0x153B,1},{0x1559,1},{0x155A,1},{0x15A0,1},{0x15A1,1},{0x15A2,1},{0x15A3,1},{0x156F,1},{0x1570,1},{0x15B7,1},{0x15B8,1},
    {0x15B9,1},{0x15BB,1},{0x15BC,1},{0x15BD,1},{0x15BE,1},{0x15D6,1},{0x15D7,1},{0x15D8,1},{0x15E3,1},
    {0x10A7,2},{0x10A9,2},{0x10C9,2},{0x10E6,2},{0x10E7,2},{0x10E8,2},{0x150A,2},{0x150E,2},{0x150F,2},{0x1510,2},{0x1511,2},{0x1516,2},
    {0x1521,2},{0x1522,2},{0x1523,2},{0x1524,2},{0x1533,2},{0x1534,2},{0x1535,2},{0x1536,2},{0x1537,2},{0x1538,2},{0x1539,2},
};
#define NIDS ((int)(sizeof ids / sizeof ids[0]))

#define R_CTRL 0x0000
#define R_STATUS 0x0008
#define R_EERD 0x0014
#define R_IMC 0x00D8
#define R_RCTL 0x0100
#define R_TCTL 0x0400
#define R_TIPG 0x0410
#define R_RDBAL 0x2800
#define R_RDBAH 0x2804
#define R_RDLEN 0x2808
#define R_RDH 0x2810
#define R_RDT 0x2818
#define R_RXDCTL 0x2828
#define R_TDBAL 0x3800
#define R_TDBAH 0x3804
#define R_TDLEN 0x3808
#define R_TDH 0x3810
#define R_TDT 0x3818
#define R_TXDCTL 0x3828
#define R_MTA 0x5200
#define R_RAL0 0x5400
#define R_RAH0 0x5404

#define NRX 32
#define NTX 16
typedef struct { u32 addr_lo, addr_hi; u16 length, csum; u8 status, errors; u16 special; } __attribute__((packed)) RxD;
typedef struct { u32 addr_lo, addr_hi; u16 length; u8 cso, cmd, status, css; u16 special; } __attribute__((packed)) TxD;
static RxD rxr[NRX] __attribute__((aligned(128)));
static TxD txr[NTX] __attribute__((aligned(128)));
static u8 rxbuf[NRX][2048] __attribute__((aligned(16)));
static u8 txbuf[NTX][2048] __attribute__((aligned(16)));
static u32 base;
static int ready, rx_cur, tx_tail, kind;

static u32 rd(int off) { return mm_in32(base + (u32)off); }
static void wr(int off, u32 v) { mm_out32(base + (u32)off, v); }

static int match(u16 v, u16 d) { if (v != 0x8086) return 0; for (int i = 0; i < NIDS; i++) if (ids[i].id == d) return 1; return 0; }

static int init(const PciInfo *p, u8 mac[6]) {
    kind = K_E1000;
    for (int i = 0; i < NIDS; i++) if (ids[i].id == p->device) kind = ids[i].kind;
    u32 bar0 = p->bar[0];
    if ((bar0 & 1) || (bar0 & ~0xFu) == 0) return 0;                  /* needs a memory BAR */
    base = bar0 & ~0xFu;

    wr(R_IMC, 0xFFFFFFFFu);
    wr(R_RCTL, 0); wr(R_TCTL, 0);
    wr(R_CTRL, rd(R_CTRL) | (1u << 26));                              /* global reset */
    delay_ms(20);
    for (int i = 0; i < 200 && (rd(R_CTRL) & (1u << 26)); i++) delay_ms(1);
    wr(R_IMC, 0xFFFFFFFFu);
    wr(R_CTRL, (rd(R_CTRL) | (1u << 6) | (1u << 5)) & ~((1u << 3) | (1u << 31) | (1u << 30)));   /* SLU | ASDE, no reset bits, no VLAN */

    u32 lo = rd(R_RAL0), hi = rd(R_RAH0);
    if ((lo | (hi & 0xFFFF)) == 0) {
        for (int w = 0; w < 3; w++) {
            wr(R_EERD, 1u | ((u32)w << 8));
            u32 v = 0; for (int i = 0; i < 100000; i++) { v = rd(R_EERD); if (v & 0x12) break; }
            u16 word = (u16)(v >> 16);
            if (w == 0) lo = word; else if (w == 1) lo |= (u32)word << 16; else hi = word;
        }
    }
    if ((lo | (hi & 0xFFFF)) == 0) return 0;
    mac[0] = (u8)lo; mac[1] = (u8)(lo >> 8); mac[2] = (u8)(lo >> 16); mac[3] = (u8)(lo >> 24); mac[4] = (u8)hi; mac[5] = (u8)(hi >> 8);
    wr(R_RAL0, lo); wr(R_RAH0, (hi & 0xFFFF) | (1u << 31));
    for (int i = 0; i < 128; i++) wr(R_MTA + i * 4, 0);

    k_memset(rxr, 0, sizeof rxr);
    for (int i = 0; i < NRX; i++) rxr[i].addr_lo = dma_addr(rxbuf[i]);
    wr(R_RDBAL, dma_addr(rxr)); wr(R_RDBAH, 0); wr(R_RDLEN, NRX * 16);
    wr(R_RDH, 0); wr(R_RDT, 0); rx_cur = 0;
    if (kind != K_E1000) wr(R_RXDCTL, rd(R_RXDCTL) | (1u << 25));     /* queue enable (e1000e / igb) */
    wr(R_RCTL, (1u << 1) | (1u << 15) | (1u << 26));                  /* EN | BAM | SECRC, 2 KiB buffers */
    wr(R_RDT, NRX - 1);

    k_memset(txr, 0, sizeof txr);
    wr(R_TDBAL, dma_addr(txr)); wr(R_TDBAH, 0); wr(R_TDLEN, NTX * 16);
    wr(R_TDH, 0); wr(R_TDT, 0); tx_tail = 0;
    wr(R_TIPG, 0x0060200A);
    if (kind != K_E1000) wr(R_TXDCTL, rd(R_TXDCTL) | (1u << 25));
    wr(R_TCTL, (1u << 1) | (1u << 3) | (0x0Fu << 4) | (0x40u << 12));
    ready = 1;
    return 1;
}

static int send(const u8 *f, int len) {
    if (!ready || len <= 0 || len > 1514) return 0;
    volatile TxD *d = &txr[tx_tail];
    for (int i = 0; i < 200000 && d->cmd && !(d->status & 1); i++) __asm__ volatile("pause");
    k_memcpy(txbuf[tx_tail], f, (unsigned)len);
    d->addr_lo = dma_addr(txbuf[tx_tail]); d->addr_hi = 0; d->length = (u16)len;
    d->cso = 0; d->css = 0; d->special = 0; d->status = 0;
    BARRIER();
    d->cmd = 0x0B;                                                    /* EOP | IFCS | RS */
    tx_tail = (tx_tail + 1) % NTX;
    BARRIER();
    wr(R_TDT, (u32)tx_tail);
    return 1;
}

static int recv(u8 *buf, int max) {
    if (!ready) return 0;
    volatile RxD *d = &rxr[rx_cur];
    if (!(d->status & 1)) return 0;
    int len = d->length, ok = (d->status & 2) && d->errors == 0;
    if (len > max) len = max;
    if (ok) k_memcpy(buf, rxbuf[rx_cur], (unsigned)len);
    d->status = 0;
    BARRIER();
    wr(R_RDT, (u32)rx_cur);
    rx_cur = (rx_cur + 1) % NRX;
    return ok ? len : 0;
}

const NicDrv drv_e1000 = { "Intel PRO/1000 (e1000/e1000e/igb)", match, init, send, recv };
