/* app_term.c - terminal with a small shell on top of the in-memory filesystem */
#include "app.h"
#include "gui.h"
#include "klib.h"
#include "hw.h"
#include "net.h"
#include "account.h"
#include "nic.h"

#define LH 20
#define PAD 10
enum { C_TEXT, C_ACCENT, C_DIM, C_ERR };

static void tline(TermState *t, const char *s, int col, int split) {
    if (t->n == TERM_LINES) {
        k_memmove(t->lines[0], t->lines[1], (TERM_LINES - 1) * TERM_COLS);
        k_memmove(t->lcol, t->lcol + 1, TERM_LINES - 1);
        k_memmove(t->lsplit, t->lsplit + 1, TERM_LINES - 1);
        t->n--;
    }
    k_strcpy(t->lines[t->n], s, TERM_COLS);
    t->lcol[t->n] = (u8)col; t->lsplit[t->n] = (u8)split;
    t->n++;
}
/* prints text that may contain newlines */
static void tprint(TermState *t, const char *s, int col) {
    char buf[TERM_COLS]; int l = 0;
    for (;; s++) {
        if (*s == '\n' || *s == 0) { buf[l] = 0; tline(t, buf, col, 0); l = 0; if (!*s) break; }
        else if (l < TERM_COLS - 1) buf[l++] = (*s == '\t') ? ' ' : *s;
    }
}

static void prompt_str(TermState *t, char *out, int max) {
    char p[96]; vfs_path(t->cwd, p, sizeof p);
    char home[40]; k_snprintf(home, sizeof home, "/home/%s", acct_name());
    char shown[100];
    int hl = k_strlen(home);
    if (k_strncmp(p, home, hl) == 0 && (p[hl] == 0 || p[hl] == '/')) { shown[0] = '~'; k_strcpy(shown + 1, p + hl, sizeof shown - 1); }
    else k_strcpy(shown, p, sizeof shown);
    k_snprintf(out, max, "%s@%s:%s$ ", acct_name(), OS_HOST, shown);
}

static void term_init(Window *w, const char *arg) {
    (void)arg;
    TermState *t = &w->u.term;
    t->cwd = vfs_home();
    tline(t, OS_NAME " " OS_VERSION " terminal. Type 'help' for a list of commands.", C_ACCENT, 0);
    tline(t, "", C_TEXT, 0);
}

static void neofetch(TermState *t) {
    char buf[TERM_COLS]; HwTime tm; hw_time(&tm);
    static const char *logo[] = {
        "      ___________      ",
        "     /  _     _  \\     ",
        "    /  | \\   / |  \\    ",
        "   |   |  \\ /  |   |   ",
        "   |   |   v   |   |   ",
        "    \\  |       |  /    ",
        "     \\_|_______|_/     ",
    };
    char cpu[64]; hw_cpu_brand(cpu, sizeof cpu);
    char info[7][64];
    k_snprintf(info[0], 64, "%s@%s", acct_name(), OS_HOST);
    k_snprintf(info[1], 64, "OS:      %s %s", OS_NAME, OS_VERSION);
    k_snprintf(info[2], 64, "Kernel:  x86 32-bit protected mode");
    u32 s = gui_now() / 1000;
    k_snprintf(info[3], 64, "Uptime:  %02d:%02d:%02d", (int)(s / 3600), (int)(s / 60 % 60), (int)(s % 60));
    k_snprintf(info[4], 64, "Display: %dx%d", gfx_w, gfx_h);
    k_snprintf(info[5], 64, "CPU:     %s", cpu);
    u32 kb = hw_mem_kb();
    if (kb) k_snprintf(info[6], 64, "Memory:  %d MB", (int)(kb / 1024)); else k_snprintf(info[6], 64, "Memory:  unknown");
    for (int i = 0; i < 7; i++) {
        k_snprintf(buf, sizeof buf, "%s %s", logo[i], info[i]);
        tline(t, buf, i == 0 ? C_ACCENT : C_TEXT, 0);
    }
}

static void ls_cmd(TermState *t, const char *path) {
    int d = path ? vfs_resolve(t->cwd, path) : t->cwd;
    if (d < 0) { tline(t, "ls: no such file or directory", C_ERR, 0); return; }
    if (!vfs_is_dir(d)) { tline(t, vfs_name(d), C_TEXT, 0); return; }
    int items[VFS_MAX]; int n = vfs_list(d, items, VFS_MAX);
    if (n == 0) tline(t, "(empty)", C_DIM, 0);
    for (int i = 0; i < n; i++) {
        char b[TERM_COLS];
        if (vfs_is_dir(items[i])) { k_snprintf(b, sizeof b, "%s/", vfs_name(items[i])); tline(t, b, C_ACCENT, 0); }
        else { k_snprintf(b, sizeof b, "%s  (%d bytes)", vfs_name(items[i]), vfs_size(items[i])); tline(t, b, C_TEXT, 0); }
    }
}

static const struct { const char *n, *d; } help_tab[] = {
    { "help", "show this list" }, { "clear", "clear the screen" }, { "echo <text>", "print text" },
    { "ls [dir]", "list files" }, { "cd [dir]", "change directory" }, { "pwd", "print working directory" },
    { "cat <file>", "show a file" }, { "mkdir <name>", "create a folder" }, { "touch <name>", "create an empty file" },
    { "rm <name>", "remove a file or empty folder" }, { "edit <file>", "open a file in the editor" },
    { "open <app>", "launch an app by name" }, { "date / uptime", "time information" },
    { "neofetch", "system summary" }, { "theme dark|light", "switch the colour theme" },
    { "net", "network status" }, { "lspci", "list PCI devices (shows your hardware ids)" }, { "ping <host>", "send 4 echo requests" }, { "browse [url]", "open the web browser" },
    { "reboot / shutdown", "power control" }, { "exit", "close this window" },
};

/* returns 1 if the window was closed */
static int run_cmd(Window *w, char *line) {
    TermState *t = &w->u.term;
    char pr[128]; prompt_str(t, pr, sizeof pr);
    char echo[TERM_COLS]; k_snprintf(echo, sizeof echo, "%s%s", pr, line);
    tline(t, echo, C_TEXT, k_strlen(pr));
    while (*line == ' ') line++;
    if (!*line) return 0;
    if (t->nhist == 0 || k_strcmp(t->hist[(t->nhist - 1) % 8], line) != 0) { k_strcpy(t->hist[t->nhist % 8], line, 160); t->nhist++; }
    t->hpos = t->nhist;

    char *argv[6]; int argc = 0; char *p = line;
    char *rest = NULL;
    while (*p && argc < 6) {
        while (*p == ' ') p++;
        if (!*p) break;
        argv[argc++] = p;
        if (argc == 2) rest = p;
        while (*p && *p != ' ') p++;
        if (*p) *p++ = 0;
    }
    if (argc == 0) return 0;
    const char *c = argv[0];
    if (!k_strcmp(c, "help")) {
        for (unsigned i = 0; i < sizeof help_tab / sizeof help_tab[0]; i++) {
            char b[TERM_COLS]; k_snprintf(b, sizeof b, "  %s", help_tab[i].n);
            int l = k_strlen(b); while (l < 22) b[l++] = ' '; b[l] = 0;
            k_strcat(b, help_tab[i].d, sizeof b);
            tline(t, b, C_TEXT, 0);
        }
    } else if (!k_strcmp(c, "clear")) { t->n = 0; }
    else if (!k_strcmp(c, "echo")) { tline(t, rest ? rest : "", C_TEXT, 0); }
    else if (!k_strcmp(c, "ver") || !k_strcmp(c, "version")) tline(t, OS_NAME " " OS_VERSION " (x86, 32-bit protected mode)", C_TEXT, 0);
    else if (!k_strcmp(c, "uname")) tline(t, OS_NAME " " OS_HOST " " OS_VERSION " i686", C_TEXT, 0);
    else if (!k_strcmp(c, "whoami")) tline(t, acct_name(), C_TEXT, 0);
    else if (!k_strcmp(c, "hostname")) tline(t, OS_HOST, C_TEXT, 0);
    else if (!k_strcmp(c, "date")) {
        HwTime tm; hw_time(&tm);
        static const char *dn[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
        static const char *mn[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
        char b[TERM_COLS];
        k_snprintf(b, sizeof b, "%s %s %d %02d:%02d:%02d %d", dn[tm.wday % 7], mn[(tm.mon + 11) % 12], tm.day, tm.hour, tm.min, tm.sec, tm.year);
        tline(t, b, C_TEXT, 0);
    } else if (!k_strcmp(c, "uptime")) {
        u32 s = gui_now() / 1000; char b[64];
        k_snprintf(b, sizeof b, "up %02d:%02d:%02d", (int)(s / 3600), (int)(s / 60 % 60), (int)(s % 60));
        tline(t, b, C_TEXT, 0);
    } else if (!k_strcmp(c, "pwd")) { char b[96]; vfs_path(t->cwd, b, sizeof b); tline(t, b, C_TEXT, 0); }
    else if (!k_strcmp(c, "ls")) ls_cmd(t, argc > 1 ? argv[1] : NULL);
    else if (!k_strcmp(c, "cd")) {
        int d = argc > 1 ? vfs_resolve(t->cwd, argv[1]) : vfs_home();
        if (d < 0) tline(t, "cd: no such directory", C_ERR, 0);
        else if (!vfs_is_dir(d)) tline(t, "cd: not a directory", C_ERR, 0);
        else t->cwd = d;
    } else if (!k_strcmp(c, "cat")) {
        if (argc < 2) tline(t, "usage: cat <file>", C_ERR, 0);
        else {
            int f = vfs_resolve(t->cwd, argv[1]);
            if (f < 0) tline(t, "cat: no such file", C_ERR, 0);
            else if (vfs_is_dir(f)) tline(t, "cat: is a directory", C_ERR, 0);
            else { int len; const char *d = vfs_data(f, &len); if (len) tprint(t, d, C_TEXT); }
        }
    } else if (!k_strcmp(c, "mkdir") || !k_strcmp(c, "touch")) {
        if (argc < 2) tline(t, "missing operand", C_ERR, 0);
        else if (vfs_create(t->cwd, argv[1], c[0] == 'm') < 0) tline(t, "cannot create (exists, too long, or filesystem full)", C_ERR, 0);
    } else if (!k_strcmp(c, "rm")) {
        if (argc < 2) tline(t, "missing operand", C_ERR, 0);
        else { int f = vfs_resolve(t->cwd, argv[1]); if (f <= 0 || vfs_remove(f) < 0) tline(t, "rm: cannot remove", C_ERR, 0); }
    } else if (!k_strcmp(c, "edit")) {
        char full[96];
        if (argc < 2) full[0] = 0;
        else {
            int f = vfs_resolve(t->cwd, argv[1]);
            if (f < 0) { f = vfs_create(t->cwd, argv[1], 0); }
            if (f <= 0 || vfs_is_dir(f)) { tline(t, "edit: cannot open", C_ERR, 0); return 0; }
            vfs_path(f, full, sizeof full);
        }
        app_launch(APP_EDIT, argc < 2 ? NULL : full);
    } else if (!k_strcmp(c, "open")) {
        int app = -1;
        if (argc > 1) for (int i = 0; i < APP_COUNT && app < 0; i++)
            if (k_stricmp_sub(apps[i]->name, argv[1]) || (k_strlen(argv[1]) > 3 && k_stricmp_sub(apps[i]->desc, argv[1]))) app = i;
        if (app < 0) tline(t, "usage: open <app name>   (e.g. open files, open snake)", C_ERR, 0);
        else if (!app_installed(app)) { char b[TERM_COLS]; k_snprintf(b, sizeof b, "%s is not installed - get it from the App Store.", apps[app]->name); tline(t, b, C_ERR, 0); }
        else app_launch(app, NULL);
    } else if (!k_strcmp(c, "neofetch")) neofetch(t);
    else if (!k_strcmp(c, "net")) {
        const NetInfo *ni = net_info(); char b[TERM_COLS], ip[20];
        if (ni->status == NET_NO_NIC) {
            tline(t, nic_status_text(), C_ERR, 0);
            if (nic_detail_text()[0]) tline(t, nic_detail_text(), C_DIM, 0);
            tline(t, "Run 'lspci' to see the network card's PCI id.", C_DIM, 0);
        }
        else {
            k_snprintf(b, sizeof b, "adapter  %s", hw_nic_name()); tline(t, b, C_TEXT, 0);
            k_snprintf(b, sizeof b, "mac      %02x:%02x:%02x:%02x:%02x:%02x", ni->mac[0], ni->mac[1], ni->mac[2], ni->mac[3], ni->mac[4], ni->mac[5]);
            tline(t, b, C_TEXT, 0);
            if (ni->status != NET_UP) tline(t, "status   waiting for DHCP...", C_DIM, 0);
            else {
                ip_to_str(ni->ip, ip, sizeof ip); k_snprintf(b, sizeof b, "address  %s", ip); tline(t, b, C_TEXT, 0);
                ip_to_str(ni->gw, ip, sizeof ip); k_snprintf(b, sizeof b, "gateway  %s", ip); tline(t, b, C_TEXT, 0);
                ip_to_str(ni->dns, ip, sizeof ip); k_snprintf(b, sizeof b, "dns      %s", ip); tline(t, b, C_TEXT, 0);
            }
        }
    } else if (!k_strcmp(c, "lspci")) {
        for (int i = 0; i < pci_count(); i++) {
            const PciInfo *p = pci_get(i); char b[TERM_COLS];
            const char *dr = ((p->cls >> 16) == 0x02) ? nic_driver_for(p->vendor, p->device) : NULL;
            k_snprintf(b, sizeof b, "%02x:%02x.%d  %04x:%04x  %s%s%s", p->bus, p->dev, p->fn, p->vendor, p->device, pci_class_name(p->cls),
                       ((p->cls >> 16) == 0x02) ? (dr ? "  -> " : "  -> no driver") : "", dr ? dr : "");
            tline(t, b, dr ? C_ACCENT : C_TEXT, 0);
        }
        if (pci_count() == 0) tline(t, "no PCI devices found", C_DIM, 0);
    } else if (!k_strcmp(c, "ping")) {
        if (argc < 2) tline(t, "usage: ping <host or ip>", C_ERR, 0);
        else if (net_info()->status != NET_UP) tline(t, "ping: network is not up", C_ERR, 0);
        else { t->ping_mode = 1; t->ping_n = 0; k_strcpy(t->ping_host, argv[1], sizeof t->ping_host); t->ping_t = gui_now(); }
    } else if (!k_strcmp(c, "browse")) app_launch(APP_BROWSER, argc > 1 ? argv[1] : NULL);
    else if (!k_strcmp(c, "theme")) {
        if (argc > 1 && !k_strcmp(argv[1], "dark")) { cfg_dark = 1; theme_apply(); gui_damage_all(); }
        else if (argc > 1 && !k_strcmp(argv[1], "light")) { cfg_dark = 0; theme_apply(); gui_damage_all(); }
        else tline(t, "usage: theme dark|light", C_ERR, 0);
    } else if (!k_strcmp(c, "reboot")) gui_restart();
    else if (!k_strcmp(c, "shutdown") || !k_strcmp(c, "poweroff")) gui_shutdown();
    else if (!k_strcmp(c, "exit")) { win_close(w); return 1; }
    else { char b[TERM_COLS]; k_snprintf(b, sizeof b, "%s: command not found", c); tline(t, b, C_ERR, 0); }
    return 0;
}

static void term_key(Window *w, int key, int mods) {
    TermState *t = &w->u.term;
    int changed = 1;
    if (mods & MOD_CTRL) {
        if (key == 'l') t->n = 0;
        else if (key == 'u') { t->ilen = t->icur = 0; t->in[0] = 0; }
        else if (key == 'c') {
            char pr[128], b[TERM_COLS]; prompt_str(t, pr, sizeof pr);
            k_snprintf(b, sizeof b, "%s%s^C", pr, t->in); tline(t, b, C_TEXT, k_strlen(pr));
            t->ilen = t->icur = 0; t->in[0] = 0;
        } else changed = 0;
    } else if (key == KEY_ENTER) {
        char line[160]; k_strcpy(line, t->in, sizeof line);
        t->ilen = t->icur = 0; t->in[0] = 0; t->scroll = 0;
        if (run_cmd(w, line)) return;
    } else if (key == KEY_BACKSPACE) {
        if (t->icur > 0) { k_memmove(t->in + t->icur - 1, t->in + t->icur, (unsigned)(t->ilen - t->icur + 1)); t->icur--; t->ilen--; }
    } else if (key == KEY_DEL) {
        if (t->icur < t->ilen) { k_memmove(t->in + t->icur, t->in + t->icur + 1, (unsigned)(t->ilen - t->icur)); t->ilen--; }
    } else if (key == KEY_LEFT) { if (t->icur > 0) t->icur--; }
    else if (key == KEY_RIGHT) { if (t->icur < t->ilen) t->icur++; }
    else if (key == KEY_HOME) t->icur = 0;
    else if (key == KEY_END) t->icur = t->ilen;
    else if (key == KEY_UP || key == KEY_DOWN) {
        if (key == KEY_UP && t->hpos > 0 && t->hpos > t->nhist - 8) t->hpos--;
        else if (key == KEY_DOWN && t->hpos < t->nhist) t->hpos++;
        if (t->hpos < t->nhist) k_strcpy(t->in, t->hist[t->hpos % 8], sizeof t->in); else t->in[0] = 0;
        t->ilen = t->icur = k_strlen(t->in);
    } else if (key == KEY_PGUP) t->scroll += 8;
    else if (key == KEY_PGDN) t->scroll = k_max(0, t->scroll - 8);
    else if (key >= 32 && key < 127 && !(mods & MOD_ALT)) {
        if (t->ilen < 150) {
            k_memmove(t->in + t->icur + 1, t->in + t->icur, (unsigned)(t->ilen - t->icur + 1));
            t->in[t->icur++] = (char)key; t->ilen++;
        }
        t->scroll = 0;
    } else changed = 0;
    if (changed) win_invalidate(w);
}

static void term_mouse(Window *w, int x, int y, int ev, int clicks) {
    (void)x; (void)y; (void)clicks;
    if (ev == EV_WHEEL) { w->u.term.scroll = k_max(0, w->u.term.scroll - clicks * 3); win_invalidate(w); }
}

static void term_draw(Window *w, int x, int y, int cw, int ch) {
    TermState *t = &w->u.term;
    gfx_fill(x, y, cw, ch, 0x17191C);
    int vis = (ch - 2 * PAD + 4) / LH; if (vis < 1) vis = 1;
    int total = t->n + 1;
    int maxscroll = k_max(0, total - vis);
    if (t->scroll > maxscroll) t->scroll = maxscroll;
    int start = k_max(0, total - vis - t->scroll);
    u32 cols[4] = { 0xD7DAE0, gfx_lerp(theme.accent, 0xFFFFFF, 70), 0x7F8791, 0xFF7B72 };
    u32 prc = gfx_lerp(theme.accent, 0xFFFFFF, 70);
    for (int r = 0; r < vis && start + r < total; r++) {
        int li = start + r, ty = y + PAD + r * LH;
        if (li < t->n) {
            int sp = t->lsplit[li];
            if (sp) {
                gfx_text_n(&font_mono, x + PAD, ty, t->lines[li], sp, prc);
                gfx_text(&font_mono, x + PAD + sp * 9, ty, t->lines[li] + sp, cols[C_TEXT]);
            } else gfx_text(&font_mono, x + PAD, ty, t->lines[li], cols[t->lcol[li]]);
        } else {
            char pr[128]; prompt_str(t, pr, sizeof pr);
            int pl = k_strlen(pr);
            gfx_text(&font_mono, x + PAD, ty, pr, prc);
            gfx_text(&font_mono, x + PAD + pl * 9, ty, t->in, cols[C_TEXT]);
            if (!g_blink || t->scroll) {
                int cx = x + PAD + (pl + t->icur) * 9;
                gfx_fill(cx, ty + 1, 9, LH - 2, 0xD7DAE0);
                char one = t->in[t->icur];
                if (one) gfx_text_n(&font_mono, cx, ty, &one, 1, 0x17191C);
            }
        }
    }
}

static void term_tick(Window *w, u32 ms) {
    TermState *t = &w->u.term;
    if (!t->ping_mode) return;
    char b[TERM_COLS], ip[20];
    if (t->ping_mode == 1) {                                   /* resolving */
        int r = dns_lookup(t->ping_host, &t->ping_ip);
        if (r == 1) {
            ip_to_str(t->ping_ip, ip, sizeof ip);
            k_snprintf(b, sizeof b, "PING %s (%s)", t->ping_host, ip); tline(t, b, C_TEXT, 0);
            t->ping_mode = 2; t->ping_n = 0; t->ping_t = 0; win_invalidate(w);
        } else if (r < 0 || ms - t->ping_t > 8000) {
            tline(t, "ping: cannot resolve host", C_ERR, 0); t->ping_mode = 0; win_invalidate(w);
        }
    } else if (t->ping_mode == 2) {                            /* send + wait */
        if (t->ping_t == 0 || ms - t->ping_t > 1000) {
            if (t->ping_n >= 4) { t->ping_mode = 0; return; }
            if (t->ping_t != 0 && t->ping_n > 0) { /* previous one timed out */ }
            net_ping_start(t->ping_ip); t->ping_n++; t->ping_t = ms ? ms : 1;
        }
        int rtt; int r = net_ping_poll(&rtt);
        if (r == 1) {
            ip_to_str(t->ping_ip, ip, sizeof ip);
            k_snprintf(b, sizeof b, "reply from %s: seq=%d time=%d ms", ip, t->ping_n, rtt); tline(t, b, C_TEXT, 0);
            if (t->ping_n >= 4) t->ping_mode = 0; else t->ping_t = ms - 600;
            win_invalidate(w);
        } else if (r < 0 && t->ping_t && ms - t->ping_t > 3000) {
            k_snprintf(b, sizeof b, "seq=%d: request timed out", t->ping_n); tline(t, b, C_ERR, 0);
            if (t->ping_n >= 4) t->ping_mode = 0; else t->ping_t = 0;
            win_invalidate(w);
        }
    }
}

const AppDesc app_term = {
    "Terminal", "Command line", ICON_TERM, 700, 440, 360, 200,
    term_init, term_draw, term_mouse, term_key, term_tick
};
