/* gfx.c - software 2D renderer: clipping, alpha blending, AA shapes, text */
#include "gfx.h"
#include "klib.h"

u32 *gfx_scene, *gfx_screen;
int gfx_w, gfx_h, gfx_spitch;
static Clip clip;

static inline void fill32(u32 *p, u32 v, int n) {
#if defined(__i386__) || defined(__x86_64__)
    __asm__ volatile("rep stosl" : "+D"(p), "+c"(n) : "a"(v) : "memory");
#else
    while (n-- > 0) *p++ = v;
#endif
}

void gfx_init(u32 *scene, u32 *screen, int w, int h, int spitch) {
    gfx_scene = scene; gfx_screen = screen;
    gfx_w = w; gfx_h = h; gfx_spitch = spitch;
    clip.x0 = 0; clip.y0 = 0; clip.x1 = w; clip.y1 = h;
}

Clip gfx_clip_get(void) { return clip; }
void gfx_clip_set(Clip c) {
    if (c.x0 < 0) c.x0 = 0;
    if (c.y0 < 0) c.y0 = 0;
    if (c.x1 > gfx_w) c.x1 = gfx_w;
    if (c.y1 > gfx_h) c.y1 = gfx_h;
    clip = c;
}
Clip gfx_clip_push(int x, int y, int w, int h) {
    Clip old = clip, n;
    n.x0 = k_max(clip.x0, x);     n.y0 = k_max(clip.y0, y);
    n.x1 = k_min(clip.x1, x + w); n.y1 = k_min(clip.y1, y + h);
    if (n.x1 < n.x0) n.x1 = n.x0;
    if (n.y1 < n.y0) n.y1 = n.y0;
    clip = n;
    return old;
}
int gfx_visible(int x, int y, int w, int h) {
    return x < clip.x1 && x + w > clip.x0 && y < clip.y1 && y + h > clip.y0;
}

/* ---- colour maths ---------------------------------------------------- */
u32 gfx_blend(u32 d, u32 s, u32 a) {
    if (a >= 255) return s;
    if (a == 0) return d;
    u32 ia = 255 - a;
    u32 rb = (d & 0xFF00FF) * ia + (s & 0xFF00FF) * a + 0x800080;
    rb = ((rb + ((rb >> 8) & 0x00FF00FF)) >> 8) & 0x00FF00FF;
    u32 g = (d & 0x00FF00) * ia + (s & 0x00FF00) * a + 0x008000;
    g = ((g + (g >> 8)) >> 8) & 0x00FF00;
    return rb | g;
}
u32 gfx_lerp(u32 a, u32 b, int t) {           /* t: 0..256 */
    if (t <= 0) return a;
    if (t >= 256) return b;
    return gfx_blend(a, b, (u32)(t > 255 ? 255 : t));
}

static u32 isqrt(u32 n) {
    u32 r = 0, b = 1u << 30;
    while (b > n) b >>= 2;
    while (b) {
        if (n >= r + b) { n -= r + b; r = (r >> 1) + b; } else r >>= 1;
        b >>= 2;
    }
    return r;
}

static inline void put(int x, int y, u32 c, int a) {      /* assumes inside clip */
    u32 *p = gfx_scene + y * gfx_w + x;
    *p = (a >= 255) ? c : gfx_blend(*p, c, (u32)a);
}

/* ---- rectangles ------------------------------------------------------ */
void gfx_fill(int x, int y, int w, int h, u32 c) {
    int x1 = x + w, y1 = y + h;
    if (x < clip.x0) x = clip.x0;
    if (y < clip.y0) y = clip.y0;
    if (x1 > clip.x1) x1 = clip.x1;
    if (y1 > clip.y1) y1 = clip.y1;
    if (x >= x1 || y >= y1) return;
    for (int j = y; j < y1; j++) fill32(gfx_scene + j * gfx_w + x, c, x1 - x);
}

void gfx_fill_a(int x, int y, int w, int h, u32 c, int a) {
    if (a >= 255) { gfx_fill(x, y, w, h, c); return; }
    if (a <= 0) return;
    int x1 = x + w, y1 = y + h;
    if (x < clip.x0) x = clip.x0;
    if (y < clip.y0) y = clip.y0;
    if (x1 > clip.x1) x1 = clip.x1;
    if (y1 > clip.y1) y1 = clip.y1;
    for (int j = y; j < y1; j++) {
        u32 *p = gfx_scene + j * gfx_w + x;
        for (int i = x; i < x1; i++, p++) *p = gfx_blend(*p, c, (u32)a);
    }
}

void gfx_rect_a(int x, int y, int w, int h, u32 c, int a) {
    gfx_fill_a(x, y, w, 1, c, a);
    gfx_fill_a(x, y + h - 1, w, 1, c, a);
    gfx_fill_a(x, y + 1, 1, h - 2, c, a);
    gfx_fill_a(x + w - 1, y + 1, 1, h - 2, c, a);
}
void gfx_rect(int x, int y, int w, int h, u32 c) { gfx_rect_a(x, y, w, h, c, 255); }

void gfx_vgrad(int x, int y, int w, int h, u32 top, u32 bot) {
    for (int j = 0; j < h; j++) gfx_fill(x, y + j, w, 1, gfx_lerp(top, bot, h > 1 ? j * 256 / (h - 1) : 0));
}

/* coverage (0..16) of pixel (px,py) by a circle at corner-coords (cx,cy), radius r */
static int circ_cov(int px, int py, int cx, int cy, int r) {
    int dx = 2 * px + 1 - 2 * cx, dy = 2 * py + 1 - 2 * cy;
    int d16 = (int)isqrt((u32)(dx * dx + dy * dy) * 64u);
    int cv = r * 16 - d16 + 8;
    return cv < 0 ? 0 : cv > 16 ? 16 : cv;
}

static void span(int y, int xa, int xb, u32 c, int a) {
    if (y < clip.y0 || y >= clip.y1) return;
    if (xa < clip.x0) xa = clip.x0;
    if (xb > clip.x1) xb = clip.x1;
    if (xa >= xb) return;
    u32 *p = gfx_scene + y * gfx_w + xa;
    if (a >= 255) fill32(p, c, xb - xa);
    else for (int i = xa; i < xb; i++, p++) *p = gfx_blend(*p, c, (u32)a);
}

void gfx_round(int x, int y, int w, int h, int r, int corners, u32 c, int a) {
    if (w <= 0 || h <= 0 || a <= 0) return;
    if (r * 2 > w) r = w / 2;
    if (r * 2 > h) r = h / 2;
    if (r <= 0 || corners == 0) { gfx_fill_a(x, y, w, h, c, a); return; }
    int ys = k_max(y, clip.y0), ye = k_min(y + h, clip.y1);
    for (int j = ys; j < ye; j++) {
        int rel = j - y;
        int top = rel < r, bot = rel >= h - r;
        if (!top && !bot) { span(j, x, x + w, c, a); continue; }
        int cy = top ? y + r : y + h - r;
        int lflag = top ? (corners & CORNER_TL) : (corners & CORNER_BL);
        int rflag = top ? (corners & CORNER_TR) : (corners & CORNER_BR);
        int xl = x, xr = x + w;
        if (lflag) {
            for (int i = x; i < x + r; i++) {
                if (i < clip.x0 || i >= clip.x1) continue;
                int cv = circ_cov(i, j, x + r, cy, r);
                if (cv) put(i, j, c, (cv * a) >> 4);
            }
            xl = x + r;
        }
        if (rflag) {
            for (int i = x + w - r; i < x + w; i++) {
                if (i < clip.x0 || i >= clip.x1) continue;
                int cv = circ_cov(i, j, x + w - r, cy, r);
                if (cv) put(i, j, c, (cv * a) >> 4);
            }
            xr = x + w - r;
        }
        span(j, xl, xr, c, a);
    }
}

void gfx_round_border(int x, int y, int w, int h, int r, u32 fill, u32 border) {
    gfx_round(x, y, w, h, r, CORNER_ALL, border, 255);
    gfx_round(x + 1, y + 1, w - 2, h - 2, r > 0 ? r - 1 : 0, CORNER_ALL, fill, 255);
}

void gfx_circle(int cx, int cy, int r, u32 c, int a) {
    int ys = k_max(cy - r - 1, clip.y0), ye = k_min(cy + r + 1, clip.y1);
    int xs = k_max(cx - r - 1, clip.x0), xe = k_min(cx + r + 1, clip.x1);
    for (int j = ys; j < ye; j++)
        for (int i = xs; i < xe; i++) {
            int cv = circ_cov(i, j, cx, cy, r);
            if (cv) put(i, j, c, (cv * a) >> 4);
        }
}

/* AA line between pixel centres; w16 is thickness in 1/16 px. Keep lines <= ~90 px. */
void gfx_line(int x0, int y0, int x1, int y1, int w16, u32 c, int a) {
    int ax = x0 * 16 + 8, ay = y0 * 16 + 8, bx = x1 * 16 + 8, by = y1 * 16 + 8;
    int vx = bx - ax, vy = by - ay, len2 = vx * vx + vy * vy;
    int pad = w16 / 32 + 2;
    int xs = k_max(k_min(x0, x1) - pad, clip.x0), xe = k_min(k_max(x0, x1) + pad + 1, clip.x1);
    int ys = k_max(k_min(y0, y1) - pad, clip.y0), ye = k_min(k_max(y0, y1) + pad + 1, clip.y1);
    int hw = w16 / 2;
    for (int j = ys; j < ye; j++)
        for (int i = xs; i < xe; i++) {
            int qx = i * 16 + 8 - ax, qy = j * 16 + 8 - ay;
            int t = 0;
            if (len2 > 0) {
                int dot = qx * vx + qy * vy;
                if (dot <= 0) t = 0;
                else if (dot >= len2) t = 256;
                else t = dot * 256 / len2;
            }
            int dx = qx - vx * t / 256, dy = qy - vy * t / 256;
            int d16 = (int)isqrt((u32)(dx * dx + dy * dy));
            int cv = hw - d16 + 8;
            cv = cv < 0 ? 0 : cv > 16 ? 16 : cv;
            if (cv) put(i, j, c, (cv * a) >> 4);
        }
}

/* soft drop shadow ring around the rect (x,y,w,h); the rect itself is not touched */
void gfx_shadow(int x, int y, int w, int h, int dy_off, int size, int maxa) {
    static u8 tab[40 * 40 + 1];
    static int tab_size = 0, tab_max = 0;
    if (size > 38) size = 38;
    if (tab_size != size || tab_max != maxa) {
        for (int d2 = 0; d2 <= size * size; d2++) {
            int d = (int)isqrt((u32)d2 * 256) ;           /* d * 16 */
            int t = 256 - d * 256 / (size * 16);          /* 256 .. 0 */
            if (t < 0) t = 0;
            tab[d2] = (u8)(((t * t >> 8) * maxa) >> 8);
        }
        tab_size = size; tab_max = maxa;
    }
    int x0 = x - size, y0 = y - size, x1 = x + w + size, y1 = y + h + size + dy_off;
    int ys = k_max(y0, clip.y0), ye = k_min(y1, clip.y1);
    int xs = k_max(x0, clip.x0), xe = k_min(x1, clip.x1);
    int sy = y + dy_off;                                   /* shadow caster is shifted down */
    for (int j = ys; j < ye; j++) {
        int dy = j < sy ? sy - j : (j >= sy + h ? j - (sy + h) + 1 : 0);
        int inrow = (j >= y && j < y + h);
        for (int i = xs; i < xe; i++) {
            if (inrow && i >= x && i < x + w) { i = x + w - 1; continue; }   /* window interior */
            int dx = i < x ? x - i : (i >= x + w ? i - (x + w) + 1 : 0);
            int d2 = dx * dx + dy * dy;
            if (d2 > size * size) continue;
            int al = tab[d2];
            if (al) put(i, j, 0x000000, al);
        }
    }
}

/* ---- text ------------------------------------------------------------ */
static const Glyph *glyph(const Font *f, unsigned ch) {
    if (ch < 32 || ch > 127) ch = '?';
    return &f->g[ch - 32];
}

int gfx_text_w(const Font *f, const char *s) {
    int w = 0;
    for (; *s; s++) w += glyph(f, (u8)*s)->adv;
    return w;
}

int gfx_text_n(const Font *f, int x, int y, const char *s, int n, u32 col) {
    int by = y + f->ascent;
    int visible_y = !(y + f->height <= clip.y0 || y >= clip.y1);
    for (int k = 0; k < n && s[k]; k++) {
        const Glyph *g = glyph(f, (u8)s[k]);
        if (visible_y && g->w && x + g->xoff < clip.x1 && x + g->xoff + g->w > clip.x0) {
            const u8 *bm = f->bits + g->off;
            for (int gy = 0; gy < g->h; gy++) {
                int py = by + g->yoff + gy;
                if (py < clip.y0 || py >= clip.y1) continue;
                for (int gx = 0; gx < g->w; gx++) {
                    int px = x + g->xoff + gx;
                    if (px < clip.x0 || px >= clip.x1) continue;
                    int a = bm[gy * g->w + gx];
                    if (a) put(px, py, col, a);
                }
            }
        }
        x += g->adv;
    }
    return x;
}
int gfx_text(const Font *f, int x, int y, const char *s, u32 c) { return gfx_text_n(f, x, y, s, 0x7fffffff, c); }

void gfx_text_fit(const Font *f, int x, int y, int maxw, const char *s, u32 c) {
    if (gfx_text_w(f, s) <= maxw) { gfx_text(f, x, y, s, c); return; }
    int dots = glyph(f, '.')->adv * 2, w = 0, n = 0;
    while (s[n]) {
        int a = glyph(f, (u8)s[n])->adv;
        if (w + a + dots > maxw) break;
        w += a; n++;
    }
    int ex = gfx_text_n(f, x, y, s, n, c);
    gfx_text(f, ex, y, "..", c);
}

void gfx_text_center(const Font *f, int x, int y, int w, int h, const char *s, u32 c) {
    int tw = gfx_text_w(f, s);
    gfx_text(f, x + (w - tw) / 2, y + (h - f->height) / 2, s, c);
}
void gfx_text_right(const Font *f, int rx, int y, const char *s, u32 c) {
    gfx_text(f, rx - gfx_text_w(f, s), y, s, c);
}

/* ---- screen output --------------------------------------------------- */
void gfx_present(int x, int y, int w, int h) {
    int x1 = x + w, y1 = y + h;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x1 > gfx_w) x1 = gfx_w;
    if (y1 > gfx_h) y1 = gfx_h;
    if (x >= x1 || y >= y1) return;
    for (int j = y; j < y1; j++) {
        const u32 *s = gfx_scene + j * gfx_w + x;
        u32 *d = gfx_screen + j * gfx_spitch + x;
        int n = x1 - x;
#if defined(__i386__) || defined(__x86_64__)
        __asm__ volatile("rep movsl" : "+D"(d), "+S"(s), "+c"(n) : : "memory");
#else
        while (n-- > 0) *d++ = *s++;
#endif
    }
}

static const char *cursor_art[CURSOR_H] = {
    "X           ",
    "XX          ",
    "X.X         ",
    "X..X        ",
    "X...X       ",
    "X....X      ",
    "X.....X     ",
    "X......X    ",
    "X.......X   ",
    "X........X  ",
    "X.........X ",
    "X......XXXXX",
    "X...X..X    ",
    "X..X X..X   ",
    "X.X  X..X   ",
    "XX    X..X  ",
    "X     X..X  ",
    "       X..X ",
    "       XXX  ",
};

void gfx_cursor(int cx, int cy) {
    for (int j = 0; j < CURSOR_H; j++) {
        int py = cy + j;
        if (py < 0 || py >= gfx_h) continue;
        for (int i = 0; i < CURSOR_W; i++) {
            char ch = cursor_art[j][i];
            int px = cx + i;
            if (ch == ' ' || px < 0 || px >= gfx_w) continue;
            gfx_screen[py * gfx_spitch + px] = (ch == 'X') ? 0x000000 : 0xFFFFFF;
        }
    }
}
