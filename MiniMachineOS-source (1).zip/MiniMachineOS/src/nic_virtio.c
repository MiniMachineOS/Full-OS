/* nic_virtio.c - virtio-net over the legacy (transitional) PCI interface: QEMU/KVM `-nic model=virtio-net-pci`,
   VirtualBox "Paravirtualized Network". Modern-only (virtio 1.0) devices, id 1041, are not handled yet. */
#include "nic.h"
#include "plat.h"
#include "klib.h"

#define QSZ_MAX 256
#define HDR 10
typedef struct { u32 addr_lo, addr_hi; u32 len; u16 flags, next; } __attribute__((packed)) VDesc;
typedef struct { u8 mem[16384]; } QMem;
static QMem rxq_mem __attribute__((aligned(4096)));
static QMem txq_mem __attribute__((aligned(4096)));
static u8 rxb[32][2048] __attribute__((aligned(16)));
static u8 txb[8][2048] __attribute__((aligned(16)));
static u16 io, rqs, tqs;
static int ready;
static u16 rx_last, rx_avail, tx_avail, tx_inflight_last;

static VDesc *desc(QMem *q) { return (VDesc *)q->mem; }
static volatile u16 *avail_idx(QMem *q, int n) { return (volatile u16 *)(q->mem + 16 * n + 2); }
static volatile u16 *avail_ring(QMem *q, int n, int i) { (void)n; return (volatile u16 *)(q->mem + 16 * n + 4 + 2 * i); }
static u32 used_off(int n) { return (u32)((16 * n + 6 + 2 * n + 4095) & ~4095); }
static volatile u16 *used_idx(QMem *q, int n) { return (volatile u16 *)(q->mem + used_off(n) + 2); }
static volatile u32 *used_elem(QMem *q, int n, int i) { return (volatile u32 *)(q->mem + used_off(n) + 4 + 8 * i); }

static int match(u16 v, u16 d) { return v == 0x1AF4 && d == 0x1000; }

static int setup_queue(int idx, QMem *q, u16 *size) {
    io_out16((u16)(io + 0x0E), (u16)idx);
    u16 n = io_in16((u16)(io + 0x0C));
    if (n == 0 || n > QSZ_MAX || (n & (n - 1))) return 0;
    k_memset(q->mem, 0, sizeof q->mem);
    *size = n;
    io_out32((u16)(io + 0x08), dma_addr(q->mem) >> 12);
    return 1;
}

static int init(const PciInfo *p, u8 mac[6]) {
    u32 bar = p->bar[0];
    if (!(bar & 1)) return 0;
    io = (u16)(bar & ~3u);
    io_out8((u16)(io + 0x12), 0);                                     /* reset */
    io_out8((u16)(io + 0x12), 1);                                     /* ACKNOWLEDGE */
    io_out8((u16)(io + 0x12), 3);                                     /* + DRIVER */
    u32 feat = io_in32(io);
    io_out32((u16)(io + 0x04), feat & (1u << 5));                     /* accept only VIRTIO_NET_F_MAC */
    if (!setup_queue(0, &rxq_mem, &rqs) || !setup_queue(1, &txq_mem, &tqs)) { io_out8((u16)(io + 0x12), 0x80); return 0; }
    for (int i = 0; i < 6; i++) mac[i] = io_in8((u16)(io + 0x14 + i));
    if ((mac[0] | mac[1] | mac[2] | mac[3] | mac[4] | mac[5]) == 0) { mac[0] = 0x02; mac[1] = 0x4D; mac[2] = 0x4D; mac[3] = 0x4F; mac[4] = 0x53; mac[5] = 0x01; }
    /* post receive buffers */
    int nb = rqs < 32 ? rqs : 32;
    for (int i = 0; i < nb; i++) {
        VDesc *d = &desc(&rxq_mem)[i];
        d->addr_lo = dma_addr(rxb[i]); d->addr_hi = 0; d->len = 2048; d->flags = 2; d->next = 0;
        *avail_ring(&rxq_mem, rqs, i) = (u16)i;
    }
    BARRIER();
    rx_avail = (u16)nb; *avail_idx(&rxq_mem, rqs) = rx_avail; rx_last = 0;
    io_out8((u16)(io + 0x12), 7);                                     /* + DRIVER_OK */
    io_out16((u16)(io + 0x10), 0);                                    /* notify rx queue */
    tx_avail = 0; tx_inflight_last = 0; ready = 1;
    return 1;
}

static int send(const u8 *f, int len) {
    if (!ready || len <= 0 || len > 1514) return 0;
    for (int i = 0; i < 200000 && (u16)(tx_avail - *used_idx(&txq_mem, tqs)) >= 8; i++) __asm__ volatile("pause");
    if ((u16)(tx_avail - *used_idx(&txq_mem, tqs)) >= 8) return 0;
    int slot = tx_avail & 7;
    k_memset(txb[slot], 0, HDR);
    k_memcpy(txb[slot] + HDR, f, (unsigned)len);
    VDesc *d = &desc(&txq_mem)[slot];
    d->addr_lo = dma_addr(txb[slot]); d->addr_hi = 0; d->len = (u32)(HDR + len); d->flags = 0; d->next = 0;
    *avail_ring(&txq_mem, tqs, tx_avail % tqs) = (u16)slot;
    BARRIER();
    tx_avail++; *avail_idx(&txq_mem, tqs) = tx_avail;
    BARRIER();
    io_out16((u16)(io + 0x10), 1);                                    /* notify tx queue */
    return 1;
}

static int recv(u8 *buf, int max) {
    if (!ready) return 0;
    if (rx_last == *used_idx(&rxq_mem, rqs)) return 0;
    volatile u32 *e = used_elem(&rxq_mem, rqs, rx_last % rqs);
    u32 id = e[0], len = e[1];
    int n = 0;
    if (id < 32 && len > HDR) { n = (int)len - HDR; if (n > max) n = max; k_memcpy(buf, rxb[id] + HDR, (unsigned)n); }
    rx_last++;
    if (id < 32) {                                                    /* give the buffer back */
        *avail_ring(&rxq_mem, rqs, rx_avail % rqs) = (u16)id;
        BARRIER();
        rx_avail++; *avail_idx(&rxq_mem, rqs) = rx_avail;
        BARRIER();
        io_out16((u16)(io + 0x10), 0);
    }
    return n;
}

const NicDrv drv_virtio = { "virtio-net (legacy)", match, init, send, recv };
