/* app_edit.c - plain text editor (saves into the in-memory filesystem) */
#include "app.h"
#include "klib.h"

#define LH 20
#define CW 9
#define TOOL_H 44
#define STAT_H 26
#define PAD 12

static void update_title(Window *w) {
    EditState *e = &w->u.edit;
    char t[48]; const char *n = "Untitled";
    if (e->node > 0) n = vfs_name(e->node);
    k_snprintf(t, sizeof t, "%s%s - Editor", n, e->modified ? "*" : "");
    win_set_title(w, t);
}

static void ed_init(Window *w, const char *arg) {
    EditState *e = &w->u.edit;
    e->node = -1; e->follow = 1; e->hot = 0;
    if (arg && arg[0]) {
        int n = vfs_resolve(0, arg);
        if (n > 0 && !vfs_is_dir(n)) {
            int len; const char *d = vfs_data(n, &len);
            if (len > ED_MAX) len = ED_MAX;
            k_memcpy(e->text, d, (unsigned)len);
            e->len = len; e->node = n;
            vfs_path(n, e->path, sizeof e->path);
        }
    }
    e->text[e->len] = 0;
    update_title(w);
}

static int cols_of(int cw) { return k_max(8, (cw - 2 * PAD) / CW); }
static int rows_of(int ch) { return k_max(1, (ch - TOOL_H - STAT_H - 2 * 8) / LH); }

/* line/column of index `at`; also total lines */
static void locate(EditState *e, int cols, int at, int *ol, int *oc, int *total) {
    int line = 0, col = 0, cl = 0, cc = 0, found = 0;
    for (int i = 0; i <= e->len; i++) {
        if (i == at) { cl = line; cc = col; if (cc >= cols) { cl++; cc = 0; } found = 1; }
        if (i == e->len) break;
        char c = e->text[i];
        if (c == '\n') { line++; col = 0; continue; }
        if (col >= cols) { line++; col = 0; }
        col++;
    }
    if (!found) { cl = line; cc = col; }
    if (ol) *ol = cl;
    if (oc) *oc = cc;
    if (total) *total = line + 1;
}

static int idx_from_pos(EditState *e, int cols, int tl, int tc) {
    int line = 0, col = 0, i = 0;
    for (;;) {
        if (i < e->len && e->text[i] != '\n' && col >= cols) { line++; col = 0; }
        if (line > tl) return i;
        if (line == tl && col >= tc) return i;
        if (i >= e->len) return i;
        if (e->text[i] == '\n') { if (line == tl) return i; line++; col = 0; i++; continue; }
        col++; i++;
    }
}

static void save(Window *w) {
    EditState *e = &w->u.edit;
    if (e->node <= 0) {
        int dir = vfs_home();
        char name[VFS_NAME];
        for (int i = 1; i < 100; i++) {
            if (i == 1) k_snprintf(name, sizeof name, "Untitled.txt"); else k_snprintf(name, sizeof name, "Untitled %d.txt", i);
            if (vfs_find(dir, name) < 0) break;
        }
        e->node = vfs_create(dir, name, 0);
        if (e->node > 0) vfs_path(e->node, e->path, sizeof e->path);
    }
    if (e->node > 0 && vfs_write(e->node, e->text, e->len) == 0) {
        e->modified = 0; k_snprintf(e->msg, sizeof e->msg, "Saved to %s", e->path);
    } else k_strcpy(e->msg, "Save failed (filesystem full?)", sizeof e->msg);
    update_title(w);
}

static void new_doc(Window *w) {
    EditState *e = &w->u.edit;
    e->len = e->cur = e->top = 0; e->text[0] = 0; e->node = -1; e->path[0] = 0; e->modified = 0; e->follow = 1;
    k_strcpy(e->msg, "New document", sizeof e->msg);
    update_title(w);
}

static void insert(Window *w, const char *s, int n) {
    EditState *e = &w->u.edit;
    if (e->len + n > ED_MAX) return;
    k_memmove(e->text + e->cur + n, e->text + e->cur, (unsigned)(e->len - e->cur + 1));
    k_memcpy(e->text + e->cur, s, (unsigned)n);
    e->cur += n; e->len += n; e->modified = 1; e->msg[0] = 0;
    update_title(w);
}

static void ed_key(Window *w, int key, int mods) {
    EditState *e = &w->u.edit;
    int cols = cols_of(w->w - 2), rows = rows_of(w->h - TB_H - 1);
    e->follow = 1;
    if (mods & MOD_CTRL) {
        if (key == 's') save(w);
        else if (key == 'n') new_doc(w);
        else return;
        win_invalidate(w); return;
    }
    if (key == KEY_ENTER) insert(w, "\n", 1);
    else if (key == KEY_TAB) insert(w, "    ", 4);
    else if (key == KEY_BACKSPACE) {
        if (e->cur > 0) { k_memmove(e->text + e->cur - 1, e->text + e->cur, (unsigned)(e->len - e->cur + 1)); e->cur--; e->len--; e->modified = 1; update_title(w); }
    } else if (key == KEY_DEL) {
        if (e->cur < e->len) { k_memmove(e->text + e->cur, e->text + e->cur + 1, (unsigned)(e->len - e->cur)); e->len--; e->modified = 1; update_title(w); }
    } else if (key == KEY_LEFT) { if (e->cur > 0) e->cur--; }
    else if (key == KEY_RIGHT) { if (e->cur < e->len) e->cur++; }
    else if (key == KEY_UP || key == KEY_DOWN || key == KEY_PGUP || key == KEY_PGDN) {
        int l, c; locate(e, cols, e->cur, &l, &c, NULL);
        int d = (key == KEY_UP) ? -1 : (key == KEY_DOWN) ? 1 : (key == KEY_PGUP) ? -rows : rows;
        l = k_max(0, l + d);
        e->cur = idx_from_pos(e, cols, l, c);
    } else if (key == KEY_HOME) { while (e->cur > 0 && e->text[e->cur - 1] != '\n') e->cur--; }
    else if (key == KEY_END) { while (e->cur < e->len && e->text[e->cur] != '\n') e->cur++; }
    else if (key >= 32 && key < 127 && !(mods & MOD_ALT)) { char c = (char)key; insert(w, &c, 1); }
    else return;
    win_invalidate(w);
}

static int btn_hit(int x, int y) {
    if (ui_inside(x, y, 10, 7, 64, 30)) return 1;
    if (ui_inside(x, y, 80, 7, 64, 30)) return 2;
    return 0;
}

static void ed_mouse(Window *w, int x, int y, int ev, int clicks) {
    EditState *e = &w->u.edit;
    int cw = w->w - 2, ch = w->h - TB_H - 1;
    if (ev == EV_MOVE) {
        int h = (y >= 0 && y < TOOL_H) ? btn_hit(x, y) : 0;
        if (h != e->hot) { e->hot = h; win_invalidate(w); }
    } else if (ev == EV_WHEEL) {
        int total; locate(e, cols_of(cw), e->cur, NULL, NULL, &total);
        e->top = k_clamp(e->top + clicks * 3, 0, k_max(0, total - 1)); e->follow = 0; win_invalidate(w);
    } else if (ev == EV_DOWN) {
        if (y < TOOL_H) {
            int b = btn_hit(x, y);
            if (b == 1) new_doc(w); else if (b == 2) save(w);
            win_invalidate(w);
        } else if (y < ch - STAT_H) {
            int tl = e->top + (y - TOOL_H - 8) / LH, tc = (x - PAD + CW / 2) / CW;
            e->cur = idx_from_pos(e, cols_of(cw), k_max(0, tl), k_max(0, tc));
            e->follow = 1; (void)clicks; win_invalidate(w);
        }
    }
}

static void ed_draw(Window *w, int x, int y, int cw, int ch) {
    EditState *e = &w->u.edit;
    int cols = cols_of(cw), rows = rows_of(ch);
    /* toolbar */
    gfx_fill(x, y, cw, TOOL_H, theme.win_alt);
    gfx_fill(x, y + TOOL_H - 1, cw, 1, theme.border);
    ui_button(x + 10, y + 7, 64, 30, "New", e->hot == 1, 0);
    ui_button(x + 80, y + 7, 64, 30, "Save", e->hot == 2, 1);
    char pathbuf[100]; k_snprintf(pathbuf, sizeof pathbuf, "%s", e->path[0] ? e->path : "Untitled (not saved yet)");
    gfx_text_fit(&font_ui, x + 160, y + (TOOL_H - font_ui.height) / 2, cw - 170, pathbuf, theme.dim);
    /* text area */
    int ty = y + TOOL_H, th = ch - TOOL_H - STAT_H;
    gfx_fill(x, ty, cw, th, theme.field);
    int cl, cc, total; locate(e, cols, e->cur, &cl, &cc, &total);
    if (e->follow) {
        if (cl < e->top) e->top = cl;
        if (cl >= e->top + rows) e->top = cl - rows + 1;
        e->follow = 0;
    }
    if (e->top > total - 1) e->top = k_max(0, total - 1);
    int line = 0, col = 0;
    for (int i = 0; i < e->len; i++) {
        char c = e->text[i];
        if (c == '\n') { line++; col = 0; continue; }
        if (col >= cols) { line++; col = 0; }
        if (line >= e->top && line < e->top + rows && c != ' ')
            gfx_text_n(&font_mono, x + PAD + col * CW, ty + 8 + (line - e->top) * LH, &e->text[i], 1, theme.text);
        col++;
        if (line >= e->top + rows) break;
    }
    if (cl >= e->top && cl < e->top + rows && !g_blink)
        gfx_fill(x + PAD + cc * CW, ty + 8 + (cl - e->top) * LH + 1, 2, LH - 2, theme.accent);
    /* status bar */
    int sy = y + ch - STAT_H;
    gfx_fill(x, sy, cw, STAT_H, theme.win_alt);
    gfx_fill(x, sy, cw, 1, theme.border);
    char b[96];
    k_snprintf(b, sizeof b, "Ln %d, Col %d    %d chars%s", cl + 1, cc + 1, e->len, e->modified ? "    Modified" : "");
    gfx_text(&font_sm, x + 12, sy + (STAT_H - font_sm.height) / 2, b, theme.dim);
    if (e->msg[0]) gfx_text_right(&font_sm, x + cw - 12, sy + (STAT_H - font_sm.height) / 2, e->msg, theme.accent);
}

const AppDesc app_edit = {
    "Text Editor", "Write and edit notes", ICON_EDIT, 640, 460, 360, 240,
    ed_init, ed_draw, ed_mouse, ed_key, NULL
};
