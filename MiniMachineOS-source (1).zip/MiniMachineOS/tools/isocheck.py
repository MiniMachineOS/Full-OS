#!/usr/bin/env python3
"""Independent structural check of the ISO: re-parses it from scratch and verifies the El Torito boot path."""
import sys, struct
iso = open(sys.argv[1], "rb").read(); kern = open(sys.argv[2], "rb").read(); stage2 = open(sys.argv[3], "rb").read()
S = 2048
def sec(n): return iso[n*S:(n+1)*S]
ok = True
def check(c, m):
    global ok; print(("PASS " if c else "FAIL ") + m); ok &= bool(c)
pvd = sec(16)
check(pvd[0] == 1 and pvd[1:6] == b"CD001" and pvd[6] == 1, "primary volume descriptor present")
check(struct.unpack("<H", pvd[128:130])[0] == 2048 == struct.unpack(">H", pvd[130:132])[0], "logical block size 2048 (both-endian)")
vs_le, vs_be = struct.unpack("<I", pvd[80:84])[0], struct.unpack(">I", pvd[84:88])[0]
check(vs_le == vs_be and vs_le * S <= len(iso), f"volume size {vs_le} sectors fits in file")
br = sec(17)
check(br[0] == 0 and br[1:6] == b"CD001" and br[7:30] == b"EL TORITO SPECIFICATION", "El Torito boot record descriptor")
check(sec(18)[0] == 255 and sec(18)[1:6] == b"CD001", "volume descriptor terminator")
cat_lba = struct.unpack("<I", br[0x47:0x4B])[0]; cat = sec(cat_lba)
check(cat[0] == 1 and cat[30:32] == b"\x55\xaa" and sum(struct.unpack("<16H", cat[:32])) & 0xFFFF == 0, f"boot catalog @LBA {cat_lba}: validation entry checksum OK")
check(cat[32] == 0x88 and cat[36] == 0, "default entry bootable, no emulation")
seg = struct.unpack("<H", cat[34:36])[0]; cnt = struct.unpack("<H", cat[38:40])[0]; lba = struct.unpack("<I", cat[40:44])[0]
load = (seg or 0x7C0) * 16
check(load == 0x7C00, f"load address {load:#x}")
img = iso[lba*S: lba*S + cnt*512]
check(len(img) == cnt * 512, f"boot image {cnt} sectors readable at LBA {lba}")
check(img[510:512] == b"\x55\xaa" and img[0] == 0xFA and img[1] == 0xEA, "boot sector: signature + cli/far-jmp")
check(struct.unpack("<HH", img[2:6]) == (0x7E00, 0), "far jump target 0000:7E00")
check(img[512:512+len(stage2)] == stage2, "stage 2 sits at 0x7E00")
ko = 0x10000 - load
check(img[ko:ko+len(kern)] == kern, "kernel sits at 0x10000 inside the loaded image")
check(all(b == 0 for b in img[512+len(stage2):ko]), "gap between stage 2 and kernel is zero padding")
# directory walk
root_lba = struct.unpack("<I", pvd[158:162])[0]; rd = sec(root_lba); names = []; o = 0
while o < S and rd[o]:
    l = rd[o]; nl = rd[o+32]; names.append((rd[o+33:o+33+nl], struct.unpack("<I", rd[o+2:o+6])[0], struct.unpack("<I", rd[o+10:o+14])[0])); o += l
check(any(n[0] == b"BOOT.IMG;1" and n[1] == lba for n in names), f"BOOT.IMG;1 listed in root directory at the boot LBA ({[n[0].decode('latin1') for n in names]})")
print("\nALL CHECKS PASSED" if ok else "\nSOME CHECKS FAILED"); sys.exit(0 if ok else 1)
