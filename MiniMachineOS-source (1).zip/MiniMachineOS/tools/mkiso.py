#!/usr/bin/env python3
"""Build a bootable ISO9660 image with an El Torito no-emulation boot image (no external tools needed).
   usage: mkiso.py <stage1_iso.S> <stage2.bin> <kernel.bin> <outdir> <name.iso>
The boot image is laid out so that, loaded contiguously at 0x7C00, stage 2 sits at 0x7E00 and the kernel at 0x10000."""
import sys, os, struct, subprocess, math, datetime
s1src, s2bin, kbin, out, isoname = sys.argv[1:6]
SEC = 2048
KERNEL_OFF = 0x10000 - 0x7C00            # offset of the kernel inside the boot image
s2 = open(s2bin, "rb").read(); k = open(kbin, "rb").read()
assert 512 + len(s2) <= KERNEL_OFF, "stage 2 too large for the ISO layout"
o1 = os.path.join(out, "stage1_iso.o"); b1 = os.path.join(out, "stage1_iso.bin")
subprocess.check_call(["as", "--32", "-o", o1, s1src])
subprocess.check_call(["ld", "-m", "elf_i386", "-Ttext=0x7C00", "--oformat", "binary", "-o", b1, o1])
s1 = open(b1, "rb").read(); assert len(s1) == 512 and s1[510:] == b"\x55\xaa"
img = s1 + s2
img = img.ljust(KERNEL_OFF, b"\0") + k
boot_sectors512 = math.ceil(len(img) / 512)
assert boot_sectors512 < 65536
img = img.ljust(math.ceil(len(img) / SEC) * SEC, b"\0")

readme = (b"MiniMachineOS bootable CD\r\n\r\nBoot this disc in a BIOS/CSM virtual machine or PC.\r\n"
          b"QEMU: qemu-system-i386 -cdrom MiniMachineOS.iso -m 128 -vga std\r\n")

def both32(v): return struct.pack("<I", v) + struct.pack(">I", v)
def both16(v): return struct.pack("<H", v) + struct.pack(">H", v)
def dirrec(lba, size, flags, name):
    nl = len(name); l = 33 + nl; pad = l % 2; l += pad
    d = datetime.datetime(2026, 11, 4, 12, 0, 0)
    rec = bytes([l, 0]) + both32(lba) + both32(size) + bytes([d.year - 1900, d.month, d.day, d.hour, d.minute, d.second, 0])
    rec += bytes([flags, 0, 0]) + both16(1) + bytes([nl]) + name + (b"\0" if pad else b"")
    assert len(rec) == l
    return rec
def pad(b, n): return b.ljust(n, b" ")

# ---- layout (in 2048-byte sectors)
LBA_PVD, LBA_BR, LBA_TERM, LBA_CAT, LBA_PTL, LBA_PTM, LBA_ROOT = 16, 17, 18, 19, 20, 21, 22
LBA_BOOT = 23
LBA_README = LBA_BOOT + len(img) // SEC
total = LBA_README + 1

root = (dirrec(LBA_ROOT, SEC, 2, b"\0") + dirrec(LBA_ROOT, SEC, 2, b"\1") +
        dirrec(LBA_BOOT, len(img), 0, b"BOOT.IMG;1") + dirrec(LBA_README, len(readme), 0, b"README.TXT;1"))
assert len(root) <= SEC
pt = lambda order: struct.pack(order + "BBIH", 1, 0, LBA_ROOT, 1) + b"\0\0"
ptl, ptm = pt("<"), pt(">")
ptl = bytes([1, 0]) + struct.pack("<I", LBA_ROOT) + struct.pack("<H", 1) + b"\0\0"
ptm = bytes([1, 0]) + struct.pack(">I", LBA_ROOT) + struct.pack(">H", 1) + b"\0\0"

now = "2026110412000000"
pvd = bytearray(SEC)
pvd[0] = 1; pvd[1:6] = b"CD001"; pvd[6] = 1
pvd[8:40] = pad(b"MINIMACHINEOS", 32); pvd[40:72] = pad(b"MINIMACHINEOS", 32)
pvd[80:88] = both32(total); pvd[120:124] = both16(1); pvd[124:128] = both16(1); pvd[128:132] = both16(SEC)
pvd[132:140] = both32(len(ptl)); pvd[140:144] = struct.pack("<I", LBA_PTL); pvd[148:152] = struct.pack(">I", LBA_PTM)
pvd[156:190] = dirrec(LBA_ROOT, SEC, 2, b"\0")
for off, ln in ((190, 128), (318, 128), (446, 128), (574, 128)): pvd[off:off+ln] = b" " * ln
pvd[574:574+40] = pad(b"MINIMACHINEOS BUILD TOOL", 40)
for off in (702, 739, 776): pvd[off:off+37] = b" " * 37
for off in (813, 830, 864): pvd[off:off+17] = now.encode() + b"\0"
pvd[847:864] = b"0" * 16 + b"\0"
pvd[881] = 1

br = bytearray(SEC); br[0] = 0; br[1:6] = b"CD001"; br[6] = 1; br[7:39] = pad(b"EL TORITO SPECIFICATION", 32)
br[0x47:0x4B] = struct.pack("<I", LBA_CAT)
term = bytearray(SEC); term[0] = 255; term[1:6] = b"CD001"; term[6] = 1

cat = bytearray(SEC)
cat[0] = 1; cat[1] = 0                       # validation entry: header id 1, platform 0 = x86
cat[4:28] = pad(b"MiniMachineOS", 24)
cat[30] = 0x55; cat[31] = 0xAA
words = struct.unpack("<16H", bytes(cat[:32])); cat[28:30] = struct.pack("<H", (-sum(words)) & 0xFFFF)
cat[32] = 0x88; cat[33] = 0                  # default entry: bootable, no emulation
cat[34:36] = struct.pack("<H", 0)            # load segment 0 -> 0x07C0
cat[36] = 0
cat[38:40] = struct.pack("<H", boot_sectors512)   # sectors to load (512-byte units)
cat[40:44] = struct.pack("<I", LBA_BOOT)

iso = bytearray(SEC * 16)
for blk in (pvd, br, term, cat):
    iso += blk
iso += ptl.ljust(SEC, b"\0") + ptm.ljust(SEC, b"\0") + root.ljust(SEC, b"\0")
iso += img + readme.ljust(SEC, b"\0")
assert len(iso) == total * SEC, (len(iso), total * SEC)
iso += b"\0" * (SEC * 4)                       # a little tail padding
open(os.path.join(out, isoname), "wb").write(bytes(iso))
print(f"{isoname}: {len(iso)} bytes, boot image {len(img)} bytes ({boot_sectors512} x 512-byte sectors) at LBA {LBA_BOOT}")
