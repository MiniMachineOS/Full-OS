#!/usr/bin/env python3
"""Assemble the final disk image.
   usage: mkimage.py <stage1.S> <stage2.bin> <kernel.bin> <outdir> [image name]"""
import sys, os, subprocess, math
s1src, s2bin, kbin, out = sys.argv[1:5]
imgname = sys.argv[5] if len(sys.argv) > 5 else "os.img"
SECTOR = 512
s2 = open(s2bin, "rb").read()
k = open(kbin, "rb").read()
s2n = math.ceil(len(s2) / SECTOR)
kn = math.ceil(len(k) / SECTOR)
if 0x7E00 + s2n * SECTOR > 0x9000:
    sys.exit(f"stage 2 too large ({len(s2)} bytes): would overlap the VBE buffers at 0x9000")
if 1 + s2n + kn > 2040:
    sys.exit(f"kernel too large ({len(k)} bytes): it would run into the persistent-data area at LBA 2048")
if kn * SECTOR > 0x70000 - 0x1000:
    sys.exit(f"kernel too large ({len(k)} bytes)")
o1 = os.path.join(out, "stage1.o")
subprocess.check_call(["as", "--32", "-o", o1,
    f"--defsym=STAGE2_SECTORS={s2n}", f"--defsym=KERNEL_LBA={1 + s2n}", f"--defsym=KERNEL_SECTORS={kn}", s1src])
b1 = os.path.join(out, "boot.bin")
subprocess.check_call(["ld", "-m", "elf_i386", "-Ttext=0x7C00", "--oformat", "binary", "-o", b1, o1])
boot = open(b1, "rb").read()
assert len(boot) == 512 and boot[510:] == b"\x55\xaa", f"bad boot sector (size {len(boot)})"
img = boot + s2.ljust(s2n * SECTOR, b"\0") + k.ljust(kn * SECTOR, b"\0")
img = img.ljust(max(len(img), 2 * 1024 * 1024), b"\0")
img = img.ljust((len(img) + 1048575) // 1048576 * 1048576, b"\0")
open(os.path.join(out, imgname), "wb").write(img)
print(f"stage1 512 B | stage2 {len(s2)} B ({s2n} sectors) | kernel {len(k)} B ({kn} sectors) | {imgname} {len(img)} B")
