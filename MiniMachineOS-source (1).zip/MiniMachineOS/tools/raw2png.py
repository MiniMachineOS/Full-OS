#!/usr/bin/env python3
import sys, numpy as np
from PIL import Image
raw, w, h, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
a = np.fromfile(raw, dtype=np.uint32).reshape(h, w)
rgb = np.stack([(a >> 16) & 255, (a >> 8) & 255, a & 255], axis=-1).astype(np.uint8)
Image.fromarray(rgb).save(out)
