#!/usr/bin/env python3
"""Virtual network for the host test harness: speaks raw Ethernet frames over stdin/stdout
(2-byte little-endian length + frame). Provides ARP, ICMP echo, DHCP, DNS and an HTTP/TCP server
(with windowing + retransmission) so the real net.c + browser can be tested without hardware.
Env: VNET_DROP_S2C=N drops every Nth server data segment; VNET_DROP_C2S=1 drops the first client data segment."""
import os, sys, struct, select, time, random

GW_IP, DNS_IP, GUEST_IP = bytes([10,0,2,2]), bytes([10,0,2,3]), bytes([10,0,2,15])
def mac_for(ip): return bytes([0x52,0x55,ip[0],ip[1],ip[2],ip[3]])
HOSTS = {"web.test": bytes([10,0,2,100]), "alias.test": None, "refuse.test": bytes([10,0,2,150])}
DROP_S2C = int(os.environ.get("VNET_DROP_S2C", "0")); DROP_C2S = int(os.environ.get("VNET_DROP_C2S", "0"))
s2c_count = 0; c2s_dropped = False
out = sys.stdout.buffer
def send_frame(f):
    out.write(struct.pack("<H", len(f)) + f); out.flush()

def csum(d, s=0):
    if len(d) % 2: d += b"\0"
    for i in range(0, len(d), 2): s += (d[i] << 8) | d[i+1]
    while s >> 16: s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF
def ip_pkt(src, dst, proto, payload):
    h = struct.pack(">BBHHHBBH4s4s", 0x45, 0, 20+len(payload), random.randrange(65536), 0x4000, 64, proto, 0, src, dst)
    h = h[:10] + struct.pack(">H", csum(h)) + h[12:]
    return h + payload
def eth(dst, src, typ, payload): return dst + src + struct.pack(">H", typ) + payload

# ------------------------------------------------------------- pages
LOREM = "The quick brown fox jumps over the lazy dog while the five boxing wizards jump quickly. "
def page(title, body): return f"<!DOCTYPE html><html><head><title>{title}</title><style>p{{color:red}}</style><script>var x='<b>no</b>';</script></head><body>{body}</body></html>"
HOME = page("Test Home", """
<h1>MiniMachineOS Test Page</h1>
<p>This is a <b>bold</b> statement with <i>emphasis</i>, a <a href="/sub/page.html">relative link</a>, an
<a href="http://web.test/text">absolute link</a> and some entities: &amp; &lt;tag&gt; &quot;quoted&quot; &copy; 2026 &mdash; caf&eacute; &#8364;5 &#x41;.</p>
<h2>Lists</h2>
<ul><li>First item</li><li>Second item with a much longer line of text that should wrap around when the window is not wide enough to hold it all</li><li>Third<ul><li>Nested one</li></ul></li></ul>
<ol><li>Alpha</li><li>Beta</li><li>Gamma</li></ol>
<h3>Preformatted</h3>
<pre>def hello():
    print("hi")   # code block
</pre>
<hr>
<table><tr><th>Name</th><th>Value</th></tr><tr><td>alpha</td><td>1</td></tr><tr><td>beta</td><td>2</td></tr></table>
<p>An image: <img src="x.png" alt="logo"> and a button <input type="submit" value="Go"> follow.<br>Line after break. Unicode: \u201cquotes\u201d \u2013 dash \u2026</p>
<p><a href="/big">A big page</a> | <a href="/old">Redirect</a> | <a href="/missing">404</a> | <a href="/img.png">Image</a> | <a href="/chunked">Chunked</a> | <a href="https://secure.test/">HTTPS</a></p>
""")
SUB = page("Sub Page", '<h1>Sub page</h1><p><a href="../">Up to home</a> &bull; <a href="./other.html">same dir</a> &bull; <a href="?q=1">query</a></p><p>You arrived through a 302 redirect.</p>')
BIG = page("Big Page", "<h1>Big page</h1>" + "".join(f"<p><b>Paragraph {i}.</b> " + LOREM * 6 + "</p>" for i in range(140)) + "<p>THE END</p>")
TEXT = "Plain text file\nline two\n\n    indented line\nlast line\n"

def respond(host, path):
    hdr = lambda code, reason, ctype, extra="": f"HTTP/1.1 {code} {reason}\r\nServer: vnet\r\nContent-Type: {ctype}\r\n{extra}Connection: close\r\n"
    def full(code, reason, ctype, body, extra=""):
        b = body if isinstance(body, bytes) else body.encode()
        return (hdr(code, reason, ctype, extra) + f"Content-Length: {len(b)}\r\n\r\n").encode() + b
    if path == "/": return full(200, "OK", "text/html; charset=utf-8", HOME)
    if path == "/big": return full(200, "OK", "text/html", BIG)
    if path == "/old": return full(302, "Found", "text/html", "moved", "Location: /sub/page.html\r\n")
    if path == "/sub/page.html": return full(200, "OK", "text/html", SUB)
    if path == "/text": return full(200, "OK", "text/plain", TEXT)
    if path == "/img.png": return full(200, "OK", "image/png", b"\x89PNG\r\n\x1a\n" + bytes(300))
    if path == "/chunked":
        body = HOME.encode(); chunks = b""
        for i in range(0, len(body), 700):
            c = body[i:i+700]; chunks += f"{len(c):x}\r\n".encode() + c + b"\r\n"
        return (hdr(200, "OK", "text/html") + "Transfer-Encoding: chunked\r\n\r\n").encode() + chunks + b"0\r\n\r\n"
    return full(404, "Not Found", "text/html", page("404", "<h1>404 Not Found</h1><p>No such page: " + path + "</p>"))

# ------------------------------------------------------------- TCP server
conns = {}
class Conn:
    def __init__(s, key, cseq, mss=1460):
        s.key = key; s.iss = random.randrange(1 << 31); s.snd_una = s.snd_nxt = (s.iss + 1) & 0xFFFFFFFF
        s.rcv_nxt = (cseq + 1) & 0xFFFFFFFF; s.req = b""; s.out = b""; s.off = 0; s.fin_sent = False; s.cfin = False
        s.win = 32768; s.dup = 0; s.t_ack = time.time(); s.responded = False; s.done = False
def tcp_seg(c, flags, seq, payload=b"", opts=b""):
    cip, cport, sip, sport = c.key
    hl = 20 + len(opts)
    h = struct.pack(">HHIIBBHHH", sport, cport, seq & 0xFFFFFFFF, c.rcv_nxt if flags & 16 else 0, (hl//4) << 4, flags, 65535, 0, 0) + opts
    ps = sip + cip + struct.pack(">BBH", 0, 6, hl + len(payload))
    ck = csum(ps + h + payload)
    h = h[:16] + struct.pack(">H", ck) + h[18:]
    send_frame(eth(GUEST_MAC, mac_for(sip), 0x0800, ip_pkt(sip, cip, 6, h + payload)))
def pump(c):
    global s2c_count
    limit = min(c.win, 8 * 1460)
    while c.off < len(c.out) and ((c.snd_nxt - c.snd_una) & 0xFFFFFFFF) < limit:
        seg = c.out[c.off:c.off+1460]
        seq = (c.iss + 1 + c.off) & 0xFFFFFFFF
        s2c_count += 1
        if not (DROP_S2C and s2c_count % DROP_S2C == 0): tcp_seg(c, 0x18, seq, seg)
        c.off += len(seg); c.snd_nxt = (seq + len(seg)) & 0xFFFFFFFF
    if c.responded and c.off >= len(c.out) and not c.fin_sent:
        tcp_seg(c, 0x11, c.snd_nxt); c.snd_nxt = (c.snd_nxt + 1) & 0xFFFFFFFF; c.fin_sent = True
def go_back(c):                                      # go-back-N retransmission from the first unacked byte
    c.off = min(len(c.out), (c.snd_una - (c.iss + 1)) & 0xFFFFFFFF)
    c.snd_nxt = c.snd_una; c.fin_sent = False
    pump(c)
GUEST_MAC = bytes(6)
def tcp_in(cip, sip, p):
    global c2s_dropped
    sport, dport, seq, ack, off, fl, win = struct.unpack(">HHIIBBH", p[:16])
    hl = (off >> 4) * 4; data = p[hl:]
    key = (cip, sport, sip, dport); c = conns.get(key)
    if os.environ.get("VNET_DEBUG"):
        sys.stderr.write("[tcp<-] fl=%02x seq=%d ack=%d len=%d win=%d known=%s\n" % (fl, seq, ack, len(data), win, c is not None))
    if fl & 2 and not fl & 16:
        if dport != 80:
            fake = Conn(key, seq); fake.snd_nxt = 0; tcp_seg(fake, 0x14, 0); return
        c = conns[key] = Conn(key, seq)
        tcp_seg(c, 0x12, c.iss, opts=b"\x02\x04\x05\xb4"); return
    if not c: return
    if fl & 4: conns.pop(key, None); return
    c.win = win
    if data and DROP_C2S and not c2s_dropped: c2s_dropped = True; return
    if fl & 16:
        d = (ack - c.snd_una) & 0xFFFFFFFF
        if 0 < d <= ((c.snd_nxt - c.snd_una) & 0xFFFFFFFF): c.snd_una = ack; c.dup = 0; c.t_ack = time.time()
        elif ack == c.snd_una and not data and not fl & 1 and c.snd_una != c.snd_nxt:
            c.dup += 1
            if c.dup == 3: c.dup = 0; go_back(c); return
    need_ack = False
    if data:
        if seq == c.rcv_nxt: c.req += data; c.rcv_nxt = (c.rcv_nxt + len(data)) & 0xFFFFFFFF
        need_ack = True
    if fl & 1 and ((seq + len(data)) & 0xFFFFFFFF) == c.rcv_nxt and not c.cfin:
        c.cfin = True; c.rcv_nxt = (c.rcv_nxt + 1) & 0xFFFFFFFF; need_ack = True
    if need_ack: tcp_seg(c, 0x10, c.snd_nxt)
    if not c.responded and b"\r\n\r\n" in c.req:
        lines = c.req.decode("latin1").split("\r\n"); path = lines[0].split(" ")[1]
        host = next((l.split(":", 1)[1].strip() for l in lines if l.lower().startswith("host:")), "")
        c.out = respond(host.split(":")[0], path); c.responded = True; c.t_ack = time.time()
        sys.stderr.write(f"[vnet] GET {host}{path} -> {len(c.out)} bytes\n")
    pump(c)
    if c.fin_sent and c.snd_una == c.snd_nxt and c.cfin: conns.pop(key, None)

# ------------------------------------------------------------- UDP services
def udp_reply(src_ip, dst_ip, sport, dport, payload, dst_mac):
    u = struct.pack(">HHHH", sport, dport, 8 + len(payload), 0) + payload
    send_frame(eth(dst_mac, mac_for(src_ip), 0x0800, ip_pkt(src_ip, dst_ip, 17, u)))
def dhcp_in(p, src_mac):
    if len(p) < 240 or p[0] != 1: return
    xid = p[4:8]; opts = p[240:]; typ = None; i = 0
    while i < len(opts) and opts[i] != 255:
        if opts[i] == 0: i += 1; continue
        if opts[i] == 53: typ = opts[i+2]
        i += 2 + opts[i+1]
    if typ not in (1, 3): return
    r = bytearray(300); r[0] = 2; r[1] = 1; r[2] = 6; r[4:8] = xid; r[10:12] = b"\x80\x00"; r[16:20] = GUEST_IP; r[20:24] = GW_IP
    r[28:34] = p[28:34]; r[236:240] = b"\x63\x82\x53\x63"
    o = bytes([53, 1, 2 if typ == 1 else 5, 54, 4]) + GW_IP + bytes([1, 4, 255, 255, 255, 0, 3, 4]) + GW_IP + bytes([6, 4]) + DNS_IP + bytes([51, 4, 0, 1, 81, 128, 255])
    r[240:240+len(o)] = o
    udp_reply(GW_IP, bytes([255]*4), 67, 68, bytes(r[:240+len(o)]), b"\xff"*6)
    sys.stderr.write(f"[vnet] DHCP {'offer' if typ == 1 else 'ack'}\n")
def enc_name(n): return b"".join(bytes([len(x)]) + x.encode() for x in n.split(".")) + b"\0"
def dns_in(p, src_mac, sport):
    if len(p) < 12: return
    labels = []; i = 12
    while p[i]: labels.append(p[i+1:i+1+p[i]].decode()); i += p[i] + 1
    name = ".".join(labels); qend = i + 5
    sys.stderr.write(f"[vnet] DNS {name}\n")
    ans = b""; rcode = 0; cnt = 0
    if name in HOSTS:
        ip = HOSTS[name]
        if ip is None:                                   # CNAME -> web.test, then the A record
            cn = enc_name("web.test"); ans += b"\xc0\x0c" + struct.pack(">HHIH", 5, 1, 60, len(cn)) + cn; cnt += 1; ip = HOSTS["web.test"]
        ans += b"\xc0\x0c" + struct.pack(">HHIH", 1, 1, 60, 4) + ip; cnt += 1
    else: rcode = 3
    r = p[:2] + struct.pack(">HHHHH", 0x8180 | rcode, 1, cnt, 0, 0) + p[12:qend] + ans
    udp_reply(DNS_IP, GUEST_IP, 53, sport, r, src_mac)

# ------------------------------------------------------------- frame dispatch
def handle(f):
    global GUEST_MAC
    if len(f) < 14: return
    dst, src, typ = f[:6], f[6:12], struct.unpack(">H", f[12:14])[0]
    if src != bytes(6): GUEST_MAC = src
    if typ == 0x0806:
        op = struct.unpack(">H", f[20:22])[0]; sip = f[28:32]; tip = f[38:42]
        if op == 1 and tip[:3] == bytes([10,0,2]) and tip != GUEST_IP:
            a = struct.pack(">HHBBH", 1, 0x0800, 6, 4, 2) + mac_for(tip) + tip + src + sip
            send_frame(eth(src, mac_for(tip), 0x0806, a))
    elif typ == 0x0800:
        ihl = (f[14] & 15) * 4; tot = struct.unpack('>H', f[16:18])[0]; proto = f[23]; sip, dip = f[26:30], f[30:34]; p = f[14+ihl:14+tot]
        if proto == 1 and p[0] == 8:
            r = b"\0\0\0\0" + p[4:]; r = r[:2] + struct.pack(">H", csum(r)) + r[4:]
            send_frame(eth(src, mac_for(dip), 0x0800, ip_pkt(dip, sip, 1, r)))
        elif proto == 17:
            sp, dp = struct.unpack(">HH", p[:4]); data = p[8:]
            if dp == 67: dhcp_in(data, src)
            elif dp == 53 and dip == DNS_IP: dns_in(data, src, sp)
        elif proto == 6: tcp_in(sip, dip, p)

buf = b""
last_rto = time.time()
while True:
    r, _, _ = select.select([0], [], [], 0.05)
    if r:
        d = os.read(0, 65536)
        if not d: break
        buf += d
        while len(buf) >= 2:
            n = struct.unpack("<H", buf[:2])[0]
            if len(buf) < 2 + n: break
            handle(buf[2:2+n]); buf = buf[2+n:]
    now = time.time()
    for c in list(conns.values()):
        if c.responded and c.snd_una != c.snd_nxt and now - c.t_ack > 0.3:
            c.t_ack = now; c.dup = 0; go_back(c)
