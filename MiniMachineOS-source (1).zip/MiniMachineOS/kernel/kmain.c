/* kmain.c - hardware layer: framebuffer hand-off, PS/2 keyboard+mouse, PIT, RTC, power */
#include "../src/types.h"
#include "../src/gui.h"
#include "../src/hw.h"
#include "../src/app.h"
#include "../src/klib.h"
#include "../src/net.h"

static volatile u32 *bootinfo(void) {            /* BootInfo block written by stage 2 at 0x600 */
    volatile u32 *p = (volatile u32 *)0x600;
    __asm__("" : "+r"(p));                        /* stop gcc treating a low constant address as NULL */
    return p;
}
#define BOOTINFO (bootinfo())
#define BI_MAGIC 0x4F594D53u
#define MAX_PIXELS (1280 * 1024)
static u32 scene[MAX_PIXELS];

static inline void outb(u16 p, u8 v) { __asm__ volatile("outb %0, %1" : : "a"(v), "Nd"(p)); }
static inline void outw(u16 p, u16 v) { __asm__ volatile("outw %0, %1" : : "a"(v), "Nd"(p)); }
static inline u8 inb(u16 p) { u8 v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }

/* ---------------------------------------------------------------- timer */
static u32 pit_last, ms_total, ms_rem;
static void pit_init(void) {
    outb(0x43, 0x34);              /* channel 0, lo/hi, mode 2 (rate generator), binary */
    outb(0x40, 0); outb(0x40, 0);  /* reload value 65536 */
    outb(0x43, 0x00);
    u32 lo = inb(0x40), hi = inb(0x40);
    pit_last = (hi << 8) | lo;
}
u32 hw_ms(void) {
    outb(0x43, 0x00);
    u32 lo = inb(0x40), hi = inb(0x40);
    u32 cur = (hi << 8) | lo;
    u32 delta = (pit_last - cur) & 0xFFFF;
    pit_last = cur;
    ms_rem += delta * 1000;
    ms_total += ms_rem / 1193182;
    ms_rem %= 1193182;
    return ms_total;
}

/* ------------------------------------------------------------------ RTC */
static u8 cmos(u8 r) { outb(0x70, r); return inb(0x71); }
static int bcd(int v) { return (v & 0x0F) + (v >> 4) * 10; }
void hw_time(HwTime *t) {
    u8 s, m, h, d, mo, y, c, rb;
    for (int tries = 0; tries < 3; tries++) {
        for (int i = 0; i < 100000 && (cmos(0x0A) & 0x80); i++) { }
        s = cmos(0); m = cmos(2); h = cmos(4); d = cmos(7); mo = cmos(8); y = cmos(9); c = cmos(0x32);
        if (cmos(0) == s && cmos(2) == m) break;
    }
    rb = cmos(0x0B);
    int pm = h & 0x80;
    h &= 0x7F;
    int S = s, M = m, H = h, D = d, MO = mo, Y = y, C = c;
    if (!(rb & 4)) { S = bcd(S); M = bcd(M); H = bcd(H); D = bcd(D); MO = bcd(MO); Y = bcd(Y); C = bcd(C); }
    if (!(rb & 2)) { if (H == 12) H = 0; if (pm) H += 12; }
    int year = (C >= 19 && C <= 21) ? C * 100 + Y : 2000 + Y;
    if (MO < 1 || MO > 12) MO = 1;
    if (D < 1 || D > 31) D = 1;
    t->sec = S % 60; t->min = M % 60; t->hour = H % 24; t->day = D; t->mon = MO; t->year = year;
    t->wday = gui_dow(year, MO, D);
}

/* ---------------------------------------------------------------- power */
void hw_poweroff(void) {
    outw(0x604, 0x2000);     /* QEMU (newer) / ACPI PM1a default */
    outw(0xB004, 0x2000);    /* Bochs / older QEMU */
    outw(0x4004, 0x3400);    /* VirtualBox */
    outw(0x600, 0x34);       /* Cloud Hypervisor */
}
void hw_reboot(void) {
    for (int i = 0; i < 100000 && (inb(0x64) & 2); i++) { }
    outb(0x64, 0xFE);        /* pulse CPU reset line via keyboard controller */
    for (int i = 0; i < 1000000; i++) __asm__ volatile("pause");
    struct { u16 limit; u32 base; } __attribute__((packed)) idt = { 0, 0 };
    __asm__ volatile("lidt %0; int3" : : "m"(idt));      /* triple fault as last resort */
    for (;;) __asm__ volatile("hlt");
}

/* ------------------------------------------------------------ CPU / RAM */
void hw_cpu_brand(char *out, int max) {
    u32 a, b, c, d;
    __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "0"(0x80000000u));
    char buf[49]; int n = 0;
    if (a >= 0x80000004u) {
        for (u32 leaf = 0x80000002u; leaf <= 0x80000004u; leaf++) {
            __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "0"(leaf));
            u32 r[4] = { a, b, c, d };
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) buf[n++] = (char)(r[i] >> (8 * j));
        }
    } else {
        __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "0"(0u));
        u32 r[3] = { b, d, c };
        for (int i = 0; i < 3; i++) for (int j = 0; j < 4; j++) buf[n++] = (char)(r[i] >> (8 * j));
    }
    buf[n] = 0;
    const char *p = buf; while (*p == ' ') p++;
    k_strcpy(out, p, max);
}
u32 hw_mem_kb(void) { return BOOTINFO[5]; }

/* ---------------------------------------------------------------- PS/2 */
static int wait_write(void) { for (int i = 0; i < 200000; i++) if (!(inb(0x64) & 2)) return 1; return 0; }
static int wait_read(void)  { for (int i = 0; i < 200000; i++) if (inb(0x64) & 1) return 1; return 0; }
static int mouse_write(u8 b) {
    if (!wait_write()) return 0;
    outb(0x64, 0xD4);
    if (!wait_write()) return 0;
    outb(0x60, b);
    if (!wait_read()) return 0;
    return inb(0x60) == 0xFA;
}
static int ms_len = 3, ms_cycle, ms_pkt[4];
static int m_x, m_y, m_btn, m_wheel, m_dirty;
static int k_shift, k_ctrl, k_alt, k_caps, k_e0;

static void ps2_init(void) {
    for (int i = 0; i < 64 && (inb(0x64) & 1); i++) inb(0x60);
    if (wait_write()) outb(0x64, 0xA8);                       /* enable mouse port */
    if (wait_write()) outb(0x64, 0x20);
    u8 cfg = wait_read() ? inb(0x60) : 0x45;
    cfg |= 0x02; cfg &= (u8)~0x20;
    if (wait_write()) outb(0x64, 0x60);
    if (wait_write()) outb(0x60, cfg);
    mouse_write(0xF6);
    mouse_write(0xF3); mouse_write(200);                      /* IntelliMouse wheel unlock sequence */
    mouse_write(0xF3); mouse_write(100);
    mouse_write(0xF3); mouse_write(80);
    if (mouse_write(0xF2) && wait_read()) { if (inb(0x60) == 3) ms_len = 4; }
    mouse_write(0xF3); mouse_write(100);
    mouse_write(0xF4);                                         /* start streaming */
    m_x = gfx_w / 2; m_y = gfx_h / 2;
}

static void mouse_byte(u8 b) {
    if (ms_cycle == 0 && !(b & 0x08)) return;                  /* out of sync: wait for a valid first byte */
    ms_pkt[ms_cycle++] = b;
    if (ms_cycle < ms_len) return;
    ms_cycle = 0;
    int f = ms_pkt[0];
    if (!(f & 0xC0)) {
        int dx = ms_pkt[1] - ((f << 4) & 0x100), dy = ms_pkt[2] - ((f << 3) & 0x100);
        m_x = k_clamp(m_x + dx, 0, gfx_w - 1);
        m_y = k_clamp(m_y - dy, 0, gfx_h - 1);
    }
    m_btn = f & 3;
    if (ms_len == 4) { int z = ms_pkt[3] & 0x0F; if (z & 8) z -= 16; m_wheel += z; }
    m_dirty = 1;
}

static const char sc_norm[] = "\0\x1b" "1234567890-=" "\b\t" "qwertyuiop[]" "\n\0" "asdfghjkl;'`" "\0\\" "zxcvbnm,./" "\0*\0 ";
static const char sc_shift[] = "\0\x1b" "!@#$%^&*()_+" "\b\t" "QWERTYUIOP{}" "\n\0" "ASDFGHJKL:\"~" "\0|" "ZXCVBNM<>?" "\0*\0 ";

static void key_event(int key) {
    int mods = (k_shift ? MOD_SHIFT : 0) | (k_ctrl ? MOD_CTRL : 0) | (k_alt ? MOD_ALT : 0);
    gui_key(key, mods);
}

static void kbd_byte(u8 b) {
    if (b == 0xE0) { k_e0 = 1; return; }
    if (b == 0xE1) return;
    int rel = b & 0x80; u8 sc = b & 0x7F;
    int e0 = k_e0; k_e0 = 0;
    if (sc == 0x2A || sc == 0x36) { k_shift = !rel; return; }
    if (sc == 0x1D) { k_ctrl = !rel; return; }
    if (sc == 0x38) { k_alt = !rel; return; }
    if (rel) return;
    if (sc == 0x3A) { k_caps = !k_caps; return; }
    if (e0 && (sc == 0x5B || sc == 0x5C)) { key_event(KEY_LGUI); return; }
    int key = 0;
    if (e0 || (sc >= 0x47 && sc <= 0x53 && sc != 0x4A && sc != 0x4E)) {
        switch (sc) {
        case 0x48: key = KEY_UP; break;   case 0x50: key = KEY_DOWN; break;
        case 0x4B: key = KEY_LEFT; break; case 0x4D: key = KEY_RIGHT; break;
        case 0x47: key = KEY_HOME; break; case 0x4F: key = KEY_END; break;
        case 0x49: key = KEY_PGUP; break; case 0x51: key = KEY_PGDN; break;
        case 0x53: key = KEY_DEL; break;
        case 0x1C: key = KEY_ENTER; break;
        case 0x35: key = '/'; break;
        default: return;
        }
    } else if (sc == 0x3C) key = KEY_F2;
    else if (sc == 0x3E) key = KEY_F4;
    else if (sc == 0x3F) key = KEY_F5;
    else if (sc < sizeof(sc_norm) - 1) {
        char n = sc_norm[sc];
        if (!n) return;
        int letter = (n >= 'a' && n <= 'z');
        int shifted = k_shift ^ (letter && k_caps);
        key = (u8)(shifted ? sc_shift[sc] : n);
        if (k_ctrl && letter) key = n;                          /* Ctrl+letter -> lowercase letter + MOD_CTRL */
        if (key == '\n') key = KEY_ENTER;
        if (key == '\b') key = KEY_BACKSPACE;
        if (key == '\t') key = KEY_TAB;
        if (key == 0x1b) key = KEY_ESC;
    } else return;
    key_event(key);
}

static void poll_input(void) {
    for (int guard = 0; guard < 128; guard++) {
        u8 st = inb(0x64);
        if (!(st & 1)) break;
        u8 d = inb(0x60);
        if (st & 0x20) mouse_byte(d); else kbd_byte(d);
    }
    if (m_dirty || m_wheel) {
        gui_mouse(m_x, m_y, m_btn, m_wheel);
        m_wheel = 0; m_dirty = 0;
    }
}

void kmain(void) {
    u32 fb = BOOTINFO[0], pitch = BOOTINFO[1], w = BOOTINFO[2], h = BOOTINFO[3];
    if (BOOTINFO[6] != BI_MAGIC || !fb || w * h > MAX_PIXELS || w < 640 || h < 400) for (;;) __asm__ volatile("cli; hlt");
    pit_init();
    gfx_w = (int)w; gfx_h = (int)h;                              /* needed by ps2_init before gui_init */
    ps2_init();
    gui_init(scene, (u32 *)fb, (int)w, (int)h, (int)(pitch / 4));
    gui_tick(hw_ms());
    gui_render();
    net_init();
    for (;;) {
        poll_input();
        net_poll();
        gui_tick(hw_ms());
        gui_render();
        __asm__ volatile("pause");
    }
}
