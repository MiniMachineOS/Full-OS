/* plat.c - port I/O, MMIO, PCI configuration and delays for the NIC drivers */
#include "../src/types.h"
#include "../src/plat.h"
#include "../src/hw.h"

u8 io_in8(u16 p) { u8 v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }
u16 io_in16(u16 p) { u16 v; __asm__ volatile("inw %1, %0" : "=a"(v) : "Nd"(p)); return v; }
u32 io_in32(u16 p) { u32 v; __asm__ volatile("inl %1, %0" : "=a"(v) : "Nd"(p)); return v; }
void io_out8(u16 p, u8 v) { __asm__ volatile("outb %0, %1" : : "a"(v), "Nd"(p)); }
void io_out16(u16 p, u16 v) { __asm__ volatile("outw %0, %1" : : "a"(v), "Nd"(p)); }
void io_out32(u16 p, u32 v) { __asm__ volatile("outl %0, %1" : : "a"(v), "Nd"(p)); }
void io_ins16(u16 p, void *buf, int words) { __asm__ volatile("rep insw" : "+D"(buf), "+c"(words) : "d"(p) : "memory"); }
void io_outs16(u16 p, const void *buf, int words) { __asm__ volatile("rep outsw" : "+S"(buf), "+c"(words) : "d"(p) : "memory"); }
u8 mm_in8(u32 a) { return *(volatile u8 *)(unsigned long)a; }
u16 mm_in16(u32 a) { return *(volatile u16 *)(unsigned long)a; }
u32 mm_in32(u32 a) { return *(volatile u32 *)(unsigned long)a; }
void mm_out8(u32 a, u8 v) { *(volatile u8 *)(unsigned long)a = v; }
void mm_out16(u32 a, u16 v) { *(volatile u16 *)(unsigned long)a = v; }
void mm_out32(u32 a, u32 v) { *(volatile u32 *)(unsigned long)a = v; }
u32 pci_read32(int bus, int dev, int fn, int off) {
    io_out32(0xCF8, 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | ((u32)fn << 8) | (u32)(off & 0xFC));
    return io_in32(0xCFC);
}
void pci_write32(int bus, int dev, int fn, int off, u32 v) {
    io_out32(0xCF8, 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | ((u32)fn << 8) | (u32)(off & 0xFC));
    io_out32(0xCFC, v);
}
u32 dma_addr(const void *p) { return (u32)(unsigned long)p; }
void delay_ms(u32 ms) { u32 t = hw_ms(); while (hw_ms() - t < ms) __asm__ volatile("pause"); }
