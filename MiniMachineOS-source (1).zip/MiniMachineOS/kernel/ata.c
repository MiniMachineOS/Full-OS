/* ata.c - ATA PIO driver (LBA28) for the primary IDE channel, master drive. Used only for persistence.
   Every wait has a timeout, so a missing/odd controller just means "no disk" and never hangs the boot. */
#include "../src/types.h"
#include "../src/hw.h"

#define DATA 0x1F0
#define ERR 0x1F1
#define COUNT 0x1F2
#define LBA0 0x1F3
#define LBA1 0x1F4
#define LBA2 0x1F5
#define DRIVE 0x1F6
#define STATUS 0x1F7
#define CMD 0x1F7
#define CTRL 0x3F6
#define ST_ERR 0x01
#define ST_DRQ 0x08
#define ST_DF 0x20
#define ST_BSY 0x80

static inline void outb(u16 p, u8 v) { __asm__ volatile("outb %0, %1" : : "a"(v), "Nd"(p)); }
static inline u8 inb(u16 p) { u8 v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(p)); return v; }
static int present;

static void delay400(void) { for (int i = 0; i < 4; i++) inb(CTRL); }
static int wait_not_busy(void) { for (int i = 0; i < 2000000; i++) { if (!(inb(STATUS) & ST_BSY)) return 1; } return 0; }
static int wait_drq(void) {
    for (int i = 0; i < 2000000; i++) {
        u8 s = inb(STATUS);
        if (s & (ST_ERR | ST_DF)) return 0;
        if (!(s & ST_BSY) && (s & ST_DRQ)) return 1;
    }
    return 0;
}
static void insw(u16 port, void *buf, int words) { __asm__ volatile("rep insw" : "+D"(buf), "+c"(words) : "d"(port) : "memory"); }
static void outsw(u16 port, const void *buf, int words) { __asm__ volatile("rep outsw" : "+S"(buf), "+c"(words) : "d"(port) : "memory"); }

int hw_disk_init(u32 *sectors) {
    present = 0;
    outb(CTRL, 0x02);                       /* no interrupts */
    outb(DRIVE, 0xA0); delay400();
    u8 st = inb(STATUS);
    if (st == 0xFF || st == 0x00) return 0;                       /* floating bus / no drive */
    if (!wait_not_busy()) return 0;
    outb(COUNT, 0); outb(LBA0, 0); outb(LBA1, 0); outb(LBA2, 0);
    outb(CMD, 0xEC);                                              /* IDENTIFY */
    delay400();
    if (inb(STATUS) == 0) return 0;
    if (!wait_not_busy()) return 0;
    if (inb(LBA1) || inb(LBA2)) return 0;                         /* ATAPI / SATA signature: not a plain ATA disk */
    if (!wait_drq()) return 0;
    u16 id[256]; insw(DATA, id, 256);
    if (!(id[49] & 0x0200)) return 0;                             /* no LBA support */
    u32 n = (u32)id[60] | ((u32)id[61] << 16);
    if (n == 0) return 0;
    *sectors = n; present = 1;
    return 1;
}

static int setup(u32 lba, int n, u8 cmd) {
    if (!wait_not_busy()) return 0;
    outb(DRIVE, (u8)(0xE0 | ((lba >> 24) & 0x0F)));
    outb(COUNT, (u8)n); outb(LBA0, (u8)lba); outb(LBA1, (u8)(lba >> 8)); outb(LBA2, (u8)(lba >> 16));
    outb(CMD, cmd);
    return 1;
}

int hw_disk_read(u32 lba, int n, void *buf) {
    if (!present) return 0;
    u8 *p = buf;
    while (n > 0) {
        int c = n > 128 ? 128 : n;
        if (!setup(lba, c, 0x20)) return 0;
        for (int i = 0; i < c; i++) { if (!wait_drq()) return 0; insw(DATA, p, 256); p += 512; }
        lba += (u32)c; n -= c;
    }
    return 1;
}

int hw_disk_write(u32 lba, int n, const void *buf) {
    if (!present) return 0;
    const u8 *p = buf;
    while (n > 0) {
        int c = n > 128 ? 128 : n;
        if (!setup(lba, c, 0x30)) return 0;
        for (int i = 0; i < c; i++) { if (!wait_drq()) return 0; outsw(DATA, p, 256); p += 512; }
        if (!wait_not_busy()) return 0;
        if (inb(STATUS) & (ST_ERR | ST_DF)) return 0;
        lba += (u32)c; n -= c;
    }
    outb(CMD, 0xE7);                        /* flush cache */
    return wait_not_busy();
}
