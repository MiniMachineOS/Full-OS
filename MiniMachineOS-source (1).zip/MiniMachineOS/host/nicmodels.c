/* nicmodels.c - software models of network cards for testing the real NIC drivers on the host.
   Included by host.c. A model reacts to the driver's port/MMIO accesses and DMA descriptors exactly as the
   hardware would (as understood from the datasheets), and moves Ethernet frames to/from tools/vnet.py.
   Select with env NICMODEL=e1000|rtl8139|rtl8168|virtio|unsupported (default e1000). */
#include "../src/plat.h"
#include "../src/nic.h"

enum { M_NONE, M_E1000, M_RTL8139, M_RTL8168, M_VIRTIO, M_UNSUPPORTED };
static int model_kind;
static int to_py = -1, from_py = -1;
static u8 inbuf[32768]; static int inlen;
static u8 pend[1600]; static int pend_len;
static u32 pci_cmd;

#define MMIO_E1000 0x30000000u
#define MMIO_RTL   0x30100000u
#define IO_RTL8168 0xC000
#define IO_RTL8139 0xC100
#define IO_VIRTIO  0xC200
static const u8 MAC[6] = { 0x52, 0x54, 0x00, 0x12, 0x34, 0x56 };

/* ------------------------------------------------------------ frame transport (vnet.py) */
static void net_tx(const u8 *f, int len) {
    unsigned short l = (unsigned short)len;
    if (write(to_py, &l, 2) != 2 || write(to_py, f, (size_t)len) != len) { }
}
static int net_rx(u8 *buf) {                                      /* next frame from the peer or 0 */
    ssize_t n = read(from_py, inbuf + inlen, sizeof inbuf - (size_t)inlen);
    if (n > 0) inlen += (int)n;
    if (inlen >= 2) {
        int l = inbuf[0] | (inbuf[1] << 8);
        if (inlen >= 2 + l) { memcpy(buf, inbuf + 2, (size_t)l); memmove(inbuf, inbuf + 2 + l, (size_t)(inlen - 2 - l)); inlen -= 2 + l; return l; }
    }
    return 0;
}
static int have_frame(void) { if (!pend_len) pend_len = net_rx(pend); return pend_len; }

/* ------------------------------------------------------------ e1000 */
static u32 e_reg[0x6000 / 4];
static void e_reset(void) {
    memset(e_reg, 0, sizeof e_reg);
    e_reg[0x5400 / 4] = (u32)MAC[0] | (u32)MAC[1] << 8 | (u32)MAC[2] << 16 | (u32)MAC[3] << 24;
    e_reg[0x5404 / 4] = (u32)MAC[4] | (u32)MAC[5] << 8 | 0x80000000u;
}
static void e_tx(void) {
    u32 n = e_reg[0x3808 / 4] / 16;
    if (!(e_reg[0x400 / 4] & 2) || !n) return;
    while (e_reg[0x3810 / 4] != e_reg[0x3818 / 4]) {
        u8 *d = (u8 *)(unsigned long)(e_reg[0x3800 / 4] + e_reg[0x3810 / 4] * 16);
        u32 addr; memcpy(&addr, d, 4); u16 len; memcpy(&len, d + 8, 2);
        net_tx((u8 *)(unsigned long)addr, len);
        if (d[11] & 8) d[12] |= 1;                                /* RS -> DD */
        e_reg[0x3810 / 4] = (e_reg[0x3810 / 4] + 1) % n;
    }
}
static void e_pump(void) {
    u32 n = e_reg[0x2808 / 4] / 16;
    if (!(e_reg[0x100 / 4] & 2) || !n) return;
    while (e_reg[0x2810 / 4] != e_reg[0x2818 / 4] && have_frame()) {
        u8 *d = (u8 *)(unsigned long)(e_reg[0x2800 / 4] + e_reg[0x2810 / 4] * 16);
        u32 addr; memcpy(&addr, d, 4);
        memcpy((void *)(unsigned long)addr, pend, (size_t)pend_len);
        u16 len = (u16)pend_len; memcpy(d + 8, &len, 2); d[12] = 3; d[13] = 0; pend_len = 0;
        e_reg[0x2810 / 4] = (e_reg[0x2810 / 4] + 1) % n;
    }
}
static u32 e_read(u32 off) { return off < sizeof e_reg ? e_reg[off / 4] : 0; }
static void e_write(u32 off, u32 v) {
    if (off >= sizeof e_reg) return;
    if (off == 0 && (v & (1u << 26))) { e_reset(); return; }
    e_reg[off / 4] = v;
    if (off == 0x3818) e_tx();
}

/* ------------------------------------------------------------ RTL8139 */
static u8 r39_reg[0x100];
static u32 r39_rx_wr; static u16 r39_capr;
static u8 *r39_ring(void) { u32 a; memcpy(&a, r39_reg + 0x30, 4); return (u8 *)(unsigned long)a; }
static void r39_reset(void) {
    memset(r39_reg, 0, sizeof r39_reg); memcpy(r39_reg, MAC, 6);
    for (int i = 0; i < 4; i++) { u32 v = 1u << 13; memcpy(r39_reg + 0x10 + 4 * i, &v, 4); }
    r39_rx_wr = 0; r39_capr = 0xFFF0;
}
static u32 r39_rdptr(void) { return ((u32)r39_capr + 16) & 0xFFFF; }
static void r39_pump(void) {
    if (!(r39_reg[0x37] & 8) || !r39_ring()) return;
    while (have_frame()) {
        u32 total = ((u32)pend_len + 4 + 4 + 3) & ~3u, rd = r39_rdptr() % 8192;
        u32 used = (r39_rx_wr + 8192 - rd) % 8192;
        if (used + total + 16 > 8192) return;
        u8 *p = r39_ring() + r39_rx_wr;
        u16 st = 1, len = (u16)(pend_len + 4);
        memcpy(p, &st, 2); memcpy(p + 2, &len, 2); memcpy(p + 4, pend, (size_t)pend_len); memset(p + 4 + pend_len, 0, 4);
        r39_rx_wr = (r39_rx_wr + total) % 8192 ; pend_len = 0;
    }
}
static u32 r39_read(u32 off, int size) {
    if (off == 0x37) { u8 v = r39_reg[0x37] & ~1; if (r39_rx_wr == r39_rdptr() % 8192) v |= 1; return v; }
    if (off == 0x3A) return r39_rx_wr;
    u32 v = 0; memcpy(&v, r39_reg + off, (size_t)size); return v;
}
static void r39_write(u32 off, u32 v, int size) {
    if (off == 0x37) { if (v & 0x10) { r39_reset(); r39_reg[0x37] = 0; return; } r39_reg[0x37] = (u8)v; return; }
    if (off == 0x38) { r39_capr = (u16)v; return; }
    if (off >= 0x10 && off < 0x20 && size == 4) {                 /* TSD: start transmit */
        int i = (int)(off - 0x10) / 4; u32 len = v & 0x1FFF, addr; memcpy(&addr, r39_reg + 0x20 + 4 * i, 4);
        net_tx((u8 *)(unsigned long)addr, (int)len);
        v = len | (1u << 13) | (1u << 15);
    }
    memcpy(r39_reg + off, &v, (size_t)size);
}

/* ------------------------------------------------------------ RTL8168 */
static u8 r68_reg[0x100];
static int r68_tx_idx, r68_rx_idx;
static void r68_reset(void) { memset(r68_reg, 0, sizeof r68_reg); memcpy(r68_reg, MAC, 6); r68_tx_idx = r68_rx_idx = 0; }
static u32 rd32m(const void *p) { u32 v; memcpy(&v, p, 4); return v; }
static void r68_tx(void) {
    u32 base = rd32m(r68_reg + 0x20);
    if (!(r68_reg[0x37] & 4) || !base) return;
    for (int guard = 0; guard < 64; guard++) {
        u8 *d = (u8 *)(unsigned long)(base + (u32)r68_tx_idx * 16);
        u32 o1 = rd32m(d);
        if (!(o1 & 0x80000000u)) break;
        net_tx((u8 *)(unsigned long)rd32m(d + 8), (int)(o1 & 0xFFFF));
        o1 &= ~0x80000000u; memcpy(d, &o1, 4);
        r68_tx_idx = (o1 & 0x40000000u) ? 0 : r68_tx_idx + 1;
    }
}
static void r68_pump(void) {
    u32 base = rd32m(r68_reg + 0xE4);
    if (!(r68_reg[0x37] & 8) || !base) return;
    while (have_frame()) {
        u8 *d = (u8 *)(unsigned long)(base + (u32)r68_rx_idx * 16);
        u32 o1 = rd32m(d);
        if (!(o1 & 0x80000000u)) return;
        memcpy((void *)(unsigned long)rd32m(d + 8), pend, (size_t)pend_len);
        u32 n = (u32)pend_len + 4;
        o1 = (o1 & 0x40000000u) | (1u << 29) | (1u << 28) | n;   /* OWN cleared, FS | LS, length incl. CRC */
        memcpy(d, &o1, 4); pend_len = 0;
        r68_rx_idx = (o1 & 0x40000000u) ? 0 : r68_rx_idx + 1;
    }
}
static u32 r68_read(u32 off, int size) { u32 v = 0; if (off + (u32)size <= sizeof r68_reg) memcpy(&v, r68_reg + off, (size_t)size); return v; }
static void r68_write(u32 off, u32 v, int size) {
    if (off + (u32)size > sizeof r68_reg) return;
    if (off == 0x37) { if (v & 0x10) { r68_reset(); return; } r68_reg[0x37] = (u8)v; return; }
    if (off == 0x60) { v &= 0x7FFFFFFFu; }                         /* PHY write completes instantly */
    memcpy(r68_reg + off, &v, (size_t)size);
    if (off == 0x38 && (v & 0x40)) r68_tx();
}

/* ------------------------------------------------------------ virtio-net (legacy) */
static struct { u32 pfn[2]; u16 sel, status; u32 gfeat; u16 rx_last_avail, tx_last_avail; } vio;
#define VQ 256
static u8 *vq_mem(int q) { return (u8 *)(((unsigned long)vio.pfn[q]) << 12); }
static u32 vq_used_off(void) { return (u32)((16 * VQ + 6 + 2 * VQ + 4095) & ~4095); }
static u16 vq_avail_idx(int q) { u16 v; memcpy(&v, vq_mem(q) + 16 * VQ + 2, 2); return v; }
static u16 vq_avail_ring(int q, int i) { u16 v; memcpy(&v, vq_mem(q) + 16 * VQ + 4 + 2 * i, 2); return v; }
static void vq_put_used(int q, u32 id, u32 len) {
    u8 *u = vq_mem(q) + vq_used_off(); u16 idx; memcpy(&idx, u + 2, 2);
    memcpy(u + 4 + 8 * (idx % VQ), &id, 4); memcpy(u + 8 + 8 * (idx % VQ), &len, 4);
    idx++; memcpy(u + 2, &idx, 2);
}
static void vio_tx(void) {
    if (!vio.pfn[1]) return;
    while (vio.tx_last_avail != vq_avail_idx(1)) {
        u16 head = vq_avail_ring(1, vio.tx_last_avail % VQ);
        u8 *d = vq_mem(1) + 16 * head; u32 addr = rd32m(d), len = rd32m(d + 8);
        if (len > 10) net_tx((u8 *)(unsigned long)addr + 10, (int)len - 10);
        vq_put_used(1, head, 0); vio.tx_last_avail++;
    }
}
static void vio_pump(void) {
    if (!vio.pfn[0] || !(vio.status & 4)) return;
    while (vio.rx_last_avail != vq_avail_idx(0) && have_frame()) {
        u16 head = vq_avail_ring(0, vio.rx_last_avail % VQ);
        u8 *d = vq_mem(0) + 16 * head; u8 *buf = (u8 *)(unsigned long)rd32m(d);
        memset(buf, 0, 10); memcpy(buf + 10, pend, (size_t)pend_len);
        vq_put_used(0, head, (u32)pend_len + 10); vio.rx_last_avail++; pend_len = 0;
    }
}
static u32 vio_read(u32 off, int size) {
    switch (off) {
    case 0x00: return 1u << 5;
    case 0x0C: return VQ;
    case 0x0E: return vio.sel;
    case 0x12: return vio.status;
    case 0x13: return 0;
    }
    if (off >= 0x14 && off < 0x1A) return MAC[off - 0x14];
    (void)size; return 0;
}
static void vio_write(u32 off, u32 v, int size) {
    (void)size;
    switch (off) {
    case 0x04: vio.gfeat = v; break;
    case 0x08: vio.pfn[vio.sel & 1] = v; break;
    case 0x0E: vio.sel = (u16)v; break;
    case 0x10: if (v == 1) vio_tx(); break;
    case 0x12: if (v == 0) memset(&vio, 0, sizeof vio); else vio.status = (u16)v; break;
    }
}

/* ------------------------------------------------------------ plat.h implementation */
static int in_io(u32 port, u32 base, u32 len) { return port >= base && port < base + len; }
static u32 io_read(u16 port, int size) {
    if (model_kind == M_RTL8168 && in_io(port, IO_RTL8168, 0x100)) return r68_read(port - IO_RTL8168, size);
    if (model_kind == M_RTL8139 && in_io(port, IO_RTL8139, 0x100)) return r39_read(port - IO_RTL8139, size);
    if (model_kind == M_VIRTIO && in_io(port, IO_VIRTIO, 0x40)) return vio_read(port - IO_VIRTIO, size);
    return 0xFFFFFFFFu;
}
static void io_write(u16 port, u32 v, int size) {
    if (model_kind == M_RTL8168 && in_io(port, IO_RTL8168, 0x100)) r68_write(port - IO_RTL8168, v, size);
    else if (model_kind == M_RTL8139 && in_io(port, IO_RTL8139, 0x100)) r39_write(port - IO_RTL8139, v, size);
    else if (model_kind == M_VIRTIO && in_io(port, IO_VIRTIO, 0x40)) vio_write(port - IO_VIRTIO, v, size);
}
u8 io_in8(u16 p) { return (u8)io_read(p, 1); }
u16 io_in16(u16 p) { return (u16)io_read(p, 2); }
u32 io_in32(u16 p) { return io_read(p, 4); }
void io_out8(u16 p, u8 v) { io_write(p, v, 1); }
void io_out16(u16 p, u16 v) { io_write(p, v, 2); }
void io_out32(u16 p, u32 v) { io_write(p, v, 4); }
void io_ins16(u16 p, void *b, int w) { (void)p; (void)b; (void)w; }
void io_outs16(u16 p, const void *b, int w) { (void)p; (void)b; (void)w; }
static u32 mm_read(u32 a, int size) {
    if (model_kind == M_E1000 && a >= MMIO_E1000 && a < MMIO_E1000 + 0x20000) return e_read(a - MMIO_E1000);
    if (model_kind == M_RTL8168 && a >= MMIO_RTL && a < MMIO_RTL + 0x1000) return r68_read(a - MMIO_RTL, size);
    return 0xFFFFFFFFu;
}
static void mm_write(u32 a, u32 v, int size) {
    if (model_kind == M_E1000 && a >= MMIO_E1000 && a < MMIO_E1000 + 0x20000) e_write(a - MMIO_E1000, v);
    else if (model_kind == M_RTL8168 && a >= MMIO_RTL && a < MMIO_RTL + 0x1000) r68_write(a - MMIO_RTL, v, size);
}
u8 mm_in8(u32 a) { return (u8)mm_read(a, 1); }
u16 mm_in16(u32 a) { return (u16)mm_read(a, 2); }
u32 mm_in32(u32 a) { return mm_read(a, 4); }
void mm_out8(u32 a, u8 v) { mm_write(a, v, 1); }
void mm_out16(u32 a, u16 v) { mm_write(a, v, 2); }
void mm_out32(u32 a, u32 v) { mm_write(a, v, 4); }
u32 dma_addr(const void *p) { return (u32)(unsigned long)p; }
void delay_ms(u32 ms) { fake_ms += ms; }

/* fake PCI: 00:00.0 host bridge, 00:01.0 ISA-ish filler, 00:03.0 the NIC under test */
u32 pci_read32(int bus, int dev, int fn, int off) {
    if (bus != 0 || fn != 0) return 0xFFFFFFFFu;
    if (dev == 0) { switch (off) { case 0: return 0x12378086u; case 8: return 0x06000002u; case 0x0C: return 0; default: return 0; } }
    if (dev != 3 || !model_kind) return 0xFFFFFFFFu;
    u16 ven = 0x8086, did = 0x100E; u32 bar0 = MMIO_E1000, bar2 = 0;
    switch (model_kind) {
    case M_RTL8139: ven = 0x10EC; did = 0x8139; bar0 = IO_RTL8139 | 1; break;
    case M_RTL8168: ven = 0x10EC; did = 0x8168; bar0 = IO_RTL8168 | 1; bar2 = MMIO_RTL | 4; break;   /* 64-bit memory BAR2 */
    case M_VIRTIO: ven = 0x1AF4; did = 0x1000; bar0 = IO_VIRTIO | 1; break;
    case M_UNSUPPORTED: ven = 0x10EC; did = 0x8125; bar0 = MMIO_RTL; break;
    }
    switch (off) {
    case 0: return (u32)ven | ((u32)did << 16);
    case 4: return pci_cmd;
    case 8: return 0x02000001u;
    case 0x0C: return 0;
    case 0x10: return bar0;
    case 0x18: return bar2;
    case 0x1C: return 0;
    }
    return 0;
}
void pci_write32(int bus, int dev, int fn, int off, u32 v) { if (bus == 0 && dev == 3 && fn == 0 && off == 4) pci_cmd = v & 0xFFFF; }

static void model_pump(void) {
    if (!model_kind) return;
    switch (model_kind) { case M_E1000: e_pump(); break; case M_RTL8139: r39_pump(); break; case M_RTL8168: r68_pump(); break; case M_VIRTIO: vio_pump(); break; }
}
static void model_start(const char *name) {
    model_kind = !strcmp(name, "rtl8139") ? M_RTL8139 : !strcmp(name, "rtl8168") ? M_RTL8168 : !strcmp(name, "virtio") ? M_VIRTIO :
                 !strcmp(name, "unsupported") ? M_UNSUPPORTED : M_E1000;
    e_reset(); r39_reset(); r68_reset(); memset(&vio, 0, sizeof vio);
    int a[2], b[2];
    if (pipe(a) || pipe(b)) return;
    if (fork() == 0) {
        dup2(a[0], 0); dup2(b[1], 1); close(a[1]); close(b[0]);
        execlp("python3", "python3", "tools/vnet.py", (char *)NULL); _exit(1);
    }
    close(a[0]); close(b[1]); to_py = a[1]; from_py = b[0];
    fcntl(from_py, F_SETFL, O_NONBLOCK);
}
